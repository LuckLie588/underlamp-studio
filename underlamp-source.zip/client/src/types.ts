export interface User {
  id: string;
  email: string;
  displayName: string;
  createdAt: number;
}

export interface UserStats {
  projects: number;
  words: number;
  skills: number;
}

export interface MeResponse {
  user: User | null;
  stats?: UserStats;
  providerCount?: number;
  isDemo?: boolean;
  demoEnabled?: boolean;
  registrationOpen?: boolean;
}

export interface ProjectSummary {
  id: string;
  title: string;
  subtitle: string;
  genre: string;
  premise: string;
  styleGuide: string;
  status: 'writing' | 'paused' | 'done' | 'idea';
  accent: string;
  createdAt: number;
  updatedAt: number;
  chapters: number;
  words: number;
  lastChapter: string;
  lastChapterId?: string | null;
  targetWords?: number;
  pov?: string;
  structure?: string;
  updateCadence?: string;
  genrePackId?: string;
}

export interface Bible {
  world: string;
  characters: string;
  outline: string;
  foreshadowing?: string;
  style?: string;
  rules: string;
  themes: string;
  updatedAt: number;
}

export type CodexKind = 'character' | 'location' | 'faction' | 'item' | 'concept';

export interface CodexRelation {
  name: string;
  label: string;
  note?: string;
}

export interface CodexEntry {
  id: string;
  projectId: string;
  kind: CodexKind;
  name: string;
  aliases: string[];
  role: string;
  summary: string;
  details: string;
  desire: string;
  fear: string;
  secret: string;
  voice: string;
  state: string;
  relationships: CodexRelation[];
  tags: string[];
  pinned: boolean;
  firstChapterId: string | null;
  lastChapterId: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface TimelineEvent {
  id: string;
  projectId: string;
  storyTime: string;
  title: string;
  description: string;
  participants: string[];
  chapterId: string | null;
  consequences: string;
  createdAt: number;
  updatedAt: number;
}

export interface StyleVersion {
  id: string;
  projectId: string;
  content: string;
  source: 'manual' | 'extract';
  model?: string;
  providerLabel?: string;
  sampleChapters?: string[];
  promptVersion?: string;
  createdAt: number;
}

export interface ReportSnapshot {
  id: string;
  projectId: string;
  name?: string;
  report: any;
  createdAt: number;
}

export interface DeletedSnapshot {
  id: string;
  projectId: string;
  snapshot: ReportSnapshot;
  deletedAt: number;
}

export interface RecoveryPoint {
  key: string;
  createdAt: number;
  data: any;
}

export interface CodexBundle {
  entries: CodexEntry[];
  timeline: TimelineEvent[];
}

export interface ChapterMeta {
  id: string;
  projectId: string;
  title: string;
  summary: string;
  beats?: string;
  status: 'draft' | 'final' | 'outline';
  sort: number;
  wordCount: number;
  targetWords?: number;
  createdAt: number;
  updatedAt: number;
}

export interface Chapter extends ChapterMeta {
  content: string;
}

export interface ProjectDetail {
  project: ProjectSummary;
  bible: Bible;
  chapters: ChapterMeta[];
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  tags: string[];
  kind: 'skill' | 'reference';
  collection?: string;
  sourceFilename: string;
  builtin: boolean;
  enabled: boolean;
  chars: number;
  preview: string;
  createdAt: number;
  updatedAt: number;
  content?: string;
}

export interface ProviderModel {
  id: string;
  label: string;
}

export interface Provider {
  id: string;
  label: string;
  kind: 'openai' | 'anthropic' | 'gemini';
  presetId: string;
  baseUrl: string;
  models: ProviderModel[];
  isDefault: boolean;
  hasKey: boolean;
  keyHint: string;
  createdAt: number;
  updatedAt: number;
}

export interface PresetModel {
  id: string;
  label: string;
}

export interface Preset {
  id: string;
  label: string;
  kind: 'openai' | 'anthropic' | 'gemini';
  baseUrl: string;
  blurb: string;
  models: PresetModel[];
}

export interface AiStats {
  systemChars: number;
  userChars: number;
  contextChars: number;
  skills: Array<{ id: string; name: string; kind: string; chars: number }>;
  codex?: Array<{ id: string; name: string; kind: string }>;
  genrePack?: string;
  truncated: Array<{ label: string; dropped: number }>;
  chaptersBefore?: number;
}

export interface AiMeta {
  action: string;
  actionLabel: string;
  model: string;
  provider: { id: string; label: string; kind: string };
  stats: AiStats;
  startedAt: number;
}

export interface AiDone {
  usage: { input: number | null; output: number | null } | null;
  outputChars: number;
  elapsedMs: number;
  finishedAt: number;
}

export interface AiStreamPayload {
  providerId: string;
  model: string;
  action: string;
  projectId: string;
  chapterId?: string | null;
  instruction?: string;
  selection?: string;
  skillIds?: string[];
  history?: Array<{ role: 'user' | 'assistant'; content: string }>;
  contextChars?: number;
}

export interface AgentResult {
  text: string;
  reasoning?: string;
  usage?: { input: number | null; output: number | null } | null;
  latencyMs: number;
  model: string;
}

export interface ContextPreview {
  action: string;
  actionLabel: string;
  project: { id: string; title: string };
  chapter: { id: string; title: string } | null;
  system: string;
  user: string;
  messages: Array<{ role: string; content: string }>;
  stats: AiStats;
  contextChars: number;
  estimatedTokens: number;
}

export interface VersionInfo {
  id: string;
  wordCount: number;
  createdAt: number;
  preview: string;
}

export interface WritingDay {
  day: string;
  words: number;
}

export interface WritingStats {
  today: string;
  todayWords: number;
  yesterdayWords: number;
  streak: number;
  total: number;
  span: number;
  totalInSpan: number;
  days: WritingDay[];
}

export interface SearchResult {
  chapterId: string;
  title: string;
  chapterNumber: number;
  sort: number;
  field: 'title' | 'content' | 'summary' | 'beats';
  snippet: string;
  status: 'draft' | 'final' | 'outline';
  wordCount: number;
}
