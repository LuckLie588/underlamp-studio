import { useState } from 'react';
import { ArrowUpRight, BookMarked, Search, X } from 'lucide-react';
import type { CodexEntry } from '../types';

const kindLabel: Record<string, string> = {
  character: '人物',
  location: '地点',
  faction: '势力',
  item: '物品',
  concept: '设定',
};

export function CodexSidebar({
  open,
  entries,
  mentions,
  onClose,
  onOpenFull,
}: {
  open: boolean;
  entries: CodexEntry[];
  mentions: CodexEntry[];
  onClose: () => void;
  onOpenFull: () => void;
}) {
  const [query, setQuery] = useState('');
  if (!open) return null;
  const ids = new Set(mentions.map((entry) => entry.id));
  const shown = entries.filter((entry) => {
    if (!query.trim()) return ids.has(entry.id) || entry.pinned;
    const text = `${entry.name} ${entry.aliases.join(' ')} ${entry.summary}`.toLowerCase();
    return text.includes(query.trim().toLowerCase());
  });
  return (
    <>
      <button type="button" className="codex-side-scrim" aria-label="关闭本章资料" onClick={onClose} />
      <aside className="codex-side">
        <header>
          <div>
            <span className="section-kicker">本章资料</span>
            <h3>写到谁，就看见谁。</h3>
          </div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="关闭"><X size={16} /></button>
        </header>
        <label className="codex-side-search">
          <Search size={13} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜人物、地点、别名" />
        </label>
        <div className="codex-side-list">
          {shown.length === 0 ? (
            <div className="codex-side-empty"><BookMarked size={22} /><p>这一章还没有提到资料。到资料库加一条，或把人物设为置顶。</p></div>
          ) : shown.map((entry) => (
            <div key={entry.id} className="codex-side-row">
              <span className={`codex-side-kind kind-${entry.kind}`}>{kindLabel[entry.kind] || '条目'}</span>
              <div>
                <strong>{entry.name}{entry.pinned ? <em>置顶</em> : null}</strong>
                <p>{entry.summary || entry.aliases.join('、') || '还没有摘要'}</p>
              </div>
            </div>
          ))}
        </div>
        <footer>
          <button type="button" className="btn btn-primary btn-block btn-sm" onClick={onOpenFull}>
            <BookMarked size={14} />
            打开完整资料库
            <ArrowUpRight size={13} />
          </button>
          <p>只显示置顶和本章提到的条目。没有自动改稿。</p>
        </footer>
      </aside>
    </>
  );
}
