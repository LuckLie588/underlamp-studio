import { useEffect, useState, type FormEvent } from 'react';
import { Trash2 } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import type { ProjectSummary } from '../types';

const accents = [
  { id: 'tide', label: '潮汐' },
  { id: 'amber', label: '灯黄' },
  { id: 'moss', label: '苔绿' },
  { id: 'ink', label: '墨蓝' },
  { id: 'plum', label: '梅紫' },
  { id: 'clay', label: '陶土' },
];

const povOptions = ['第三人称限知', '第一人称', '多视角', '先不定'];
const structureOptions = ['单主角 + 少量支线', '群像多线', '双主角', '单元剧', '先不定'];
const cadenceOptions = ['日更连载', '周更', '写完再发', '不限'];

export function ProjectSettingsModal({
  open,
  project,
  onClose,
  onSaved,
  onDelete,
}: {
  open: boolean;
  project: ProjectSummary;
  onClose: () => void;
  onSaved: (project: ProjectSummary) => void;
  onDelete: () => void;
}) {
  const toast = useToast();
  const [title, setTitle] = useState(project.title);
  const [subtitle, setSubtitle] = useState(project.subtitle);
  const [genre, setGenre] = useState(project.genre);
  const [premise, setPremise] = useState(project.premise);
  const [styleGuide, setStyleGuide] = useState(project.styleGuide);
  const [status, setStatus] = useState(project.status);
  const [accent, setAccent] = useState(project.accent);
  const [targetWords, setTargetWords] = useState(project.targetWords || 0);
  const [pov, setPov] = useState(project.pov || '');
  const [structure, setStructure] = useState(project.structure || '');
  const [updateCadence, setUpdateCadence] = useState(project.updateCadence || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setTitle(project.title);
    setSubtitle(project.subtitle);
    setGenre(project.genre);
    setPremise(project.premise);
    setStyleGuide(project.styleGuide);
    setStatus(project.status);
    setAccent(project.accent);
    setTargetWords(project.targetWords || 0);
    setPov(project.pov || '');
    setStructure(project.structure || '');
    setUpdateCadence(project.updateCadence || '');
    setError('');
  }, [open, project]);

  async function save(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const data = await api.patch<{ project: ProjectSummary }>(`/api/projects/${project.id}`, {
        title,
        subtitle,
        genre,
        premise,
        styleGuide,
        status,
        accent,
        targetWords,
        pov,
        structure,
        updateCadence,
      });
      onSaved(data.project);
      toast.success('作品资料已更新');
      onClose();
    } catch (err) {
      setError((err as Error).message || '没有保存成功');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="作品资料"
      description="这些信息会随每次生成一起带给模型。文风约定尤其有用。"
      size="lg"
      footer={
        <>
          <button type="button" className="btn btn-danger-quiet" onClick={onDelete}>
            <Trash2 size={15} />
            删除这本书
          </button>
          <span className="modal-foot-spacer" />
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>取消</button>
          <button type="button" className="btn btn-primary" onClick={save} disabled={busy || !title.trim()}>
            {busy ? <Spinner size={15} /> : null}
            {busy ? '保存中…' : '保存'}
          </button>
        </>
      }
    >
      <form className="project-settings-form" onSubmit={save}>
        <div className="editor-row">
          <label className="field">
            <span>书名</span>
            <input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={80} required />
          </label>
          <label className="field">
            <span>状态</span>
            <select value={status} onChange={(event) => setStatus(event.target.value as ProjectSummary['status'])}>
              <option value="writing">正在写</option>
              <option value="paused">暂时搁笔</option>
              <option value="done">已完稿</option>
              <option value="idea">只有一个念头</option>
            </select>
          </label>
        </div>
        <label className="field">
          <span>副标题</span>
          <input value={subtitle} onChange={(event) => setSubtitle(event.target.value)} maxLength={120} />
        </label>
        <div className="editor-row">
          <label className="field">
            <span>类型</span>
            <input value={genre} onChange={(event) => setGenre(event.target.value)} maxLength={60} />
          </label>
          <div className="field">
            <span>封面色</span>
            <div className="swatch-row">
              {accents.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={`swatch accent-${item.id} ${accent === item.id ? 'selected' : ''}`}
                  onClick={() => setAccent(item.id)}
                  aria-label={item.label}
                  title={item.label}
                />
              ))}
            </div>
          </div>
        </div>
        <div className="editor-row">
          <label className="field">
            <span>目标字数</span>
            <select value={targetWords} onChange={(event) => setTargetWords(Number(event.target.value))}>
              <option value={0}>未设定</option>
              <option value={100000}>10 万</option>
              <option value={300000}>30 万</option>
              <option value={1000000}>100 万</option>
              <option value={3000000}>300 万</option>
              <option value={5000000}>500 万</option>
            </select>
          </label>
          <label className="field">
            <span>更新节奏</span>
            <select value={updateCadence} onChange={(event) => setUpdateCadence(event.target.value)}>
              <option value="">未设定</option>
              {cadenceOptions.map((item) => <option key={item}>{item}</option>)}
            </select>
          </label>
        </div>
        <div className="editor-row">
          <label className="field">
            <span>叙事视角</span>
            <select value={pov} onChange={(event) => setPov(event.target.value)}>
              <option value="">未设定</option>
              {povOptions.map((item) => <option key={item}>{item}</option>)}
            </select>
          </label>
          <label className="field">
            <span>结构</span>
            <select value={structure} onChange={(event) => setStructure(event.target.value)}>
              <option value="">未设定</option>
              {structureOptions.map((item) => <option key={item}>{item}</option>)}
            </select>
          </label>
        </div>
        <label className="field">
          <span>一句话故事</span>
          <textarea value={premise} onChange={(event) => setPremise(event.target.value)} rows={3} maxLength={2000} />
        </label>
        <label className="field">
          <span>文风约定</span>
          <textarea
            value={styleGuide}
            onChange={(event) => setStyleGuide(event.target.value)}
            rows={4}
            maxLength={5000}
            placeholder="比如：第三人称限知，短句，冷静，不解释情绪，章末停在局面改变的一瞬。"
          />
        </label>
        {error && <p className="form-error">{error}</p>}
      </form>
    </Modal>
  );
}
