import { useEffect, useRef, useState } from 'react';
import { BookMarked, ChevronDown, Clock3, FileText, Focus, List, Type } from 'lucide-react';
import { countWords, formatNumber, statusLabel } from '../lib/format';
import type { TextSelection, Draft, SaveState } from './types';

export function ChapterEditor({
  draft,
  chapterNumber,
  saveState,
  savedAt,
  onChange,
  onSelectionChange,
  onOpenVersions,
  onOpenCodex,
  focusMode,
  typewriter,
  onToggleFocus,
  onToggleTypewriter,
  codexMentions = [],
}: {
  draft: Draft;
  chapterNumber: number;
  saveState: SaveState;
  savedAt: number;
  onChange: (patch: Partial<Draft>) => void;
  onSelectionChange: (selection: TextSelection) => void;
  onOpenVersions: () => void;
  onOpenCodex: () => void;
  focusMode: boolean;
  typewriter: boolean;
  onToggleFocus: () => void;
  onToggleTypewriter: () => void;
  codexMentions?: Array<{ id: string; name: string; kind: string }>;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [noteTab, setNoteTab] = useState<'summary' | 'beats'>('summary');
  const words = countWords(draft.content);
  const targetWords = draft.targetWords || 0;
  const progress = targetWords > 0 ? Math.min(100, Math.round((words / targetWords) * 100)) : 0;

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.max(el.scrollHeight, window.innerHeight - 260)}px`;
  }, [draft.content]);

  function reportSelection() {
    const el = textareaRef.current;
    if (!el) return;
    const start = el.selectionStart ?? 0;
    const end = el.selectionEnd ?? 0;
    onSelectionChange({ start, end, text: draft.content.slice(start, end) });
  }

  return (
    <div className="editor-scroll">
      <div className="editor-topline">
        <span>
          <FileText size={14} />
          第 {chapterNumber || 1} 章
        </span>
        <div className="editor-tools">
          {codexMentions.length > 0 && (
            <button type="button" className="editor-tool" onClick={onOpenCodex} title="本章提到的 Codex">
              <BookMarked size={14} />
              {codexMentions.length} 条资料
            </button>
          )}
          <button type="button" className={`editor-tool ${focusMode ? 'active' : ''}`} onClick={onToggleFocus} title="专注模式">
            <Focus size={14} />
            专注
          </button>
          <button type="button" className={`editor-tool ${typewriter ? 'active' : ''}`} onClick={onToggleTypewriter} title="打字机模式">
            <Type size={14} />
            打字机
          </button>
          <label className="status-select">
            <select value={draft.status} onChange={(event) => onChange({ status: event.target.value as Draft['status'] })}>
              <option value="draft">草稿</option>
              <option value="final">定稿</option>
              <option value="outline">待写</option>
            </select>
            <ChevronDown size={13} />
          </label>
        </div>
      </div>

      <div className="manuscript">
        <span className="manuscript-margin" aria-hidden="true" />
        <input
          ref={titleRef}
          className="manuscript-title"
          value={draft.title}
          onChange={(event) => onChange({ title: event.target.value })}
          placeholder="第 X 章"
          maxLength={120}
          aria-label="章节名"
        />
        <div className="manuscript-meta">
          <span>{formatNumber(words)} 字</span>
          <span>{statusLabel(draft.status)}</span>
          <span>{saveState === 'saved' ? '已保存' : saveState === 'saving' ? '正在保存' : saveState === 'dirty' ? '未保存' : '保存失败'}</span>
        </div>
        <div className="chapter-goal">
          <label>
            <span>本章目标</span>
            <input
              type="number"
              min={0}
              step={100}
              value={targetWords || ''}
              onChange={(event) => onChange({ targetWords: Math.max(0, Number(event.target.value) || 0) })}
              placeholder="2000"
              aria-label="本章目标字数"
            />
            <em>字</em>
          </label>
          {targetWords > 0 ? (
            <div className="chapter-goal-track" title={`${formatNumber(words)} / ${formatNumber(targetWords)} 字`}>
              <span style={{ width: `${progress}%` }} />
              <em>{progress}%</em>
            </div>
          ) : (
            <span className="chapter-goal-hint">给这一章定个字数，写完会有进度。</span>
          )}
        </div>
        {codexMentions.length > 0 && (
          <div className="mention-strip">
            <span>本章资料</span>
            {codexMentions.slice(0, 8).map((entry) => (
              <button key={entry.id} type="button" onClick={onOpenCodex}>{entry.name}</button>
            ))}
            <button type="button" className="mention-more" onClick={onOpenCodex}>查看</button>
          </div>
        )}
        <textarea
          ref={textareaRef}
          className={`manuscript-text ${typewriter ? 'typewriter' : ''}`}
          value={draft.content}
          onChange={(event) => onChange({ content: event.target.value })}
          onSelect={reportSelection}
          onKeyUp={reportSelection}
          onClick={reportSelection}
          onBlur={reportSelection}
          placeholder="从一句话开始。比如：雨停之后，院子里多了一双不属于任何人的鞋。"
          spellCheck={false}
          aria-label="正文"
        />
        <div className="manuscript-foot">
          <span className="folio">— {String(chapterNumber || 1).padStart(2, '0')} —</span>
        </div>
      </div>

      <div className="editor-under">
        <button type="button" className={`summary-toggle ${summaryOpen ? 'open' : ''}`} onClick={() => setSummaryOpen((value) => !value)}>
          <FileText size={15} />
          本章笔记
          <span>
            {draft.summary ? `摘要 ${draft.summary.length} 字` : '摘要待写'}
            {' · '}
            {draft.beats ? '场景卡已填' : '场景卡待写'}
          </span>
          <ChevronDown size={14} />
        </button>
        <div className="editor-under-right">
          <span className="save-note">
            <Clock3 size={13} />
            {saveState === 'error' ? '自动保存失败，请重试' : savedAt ? `上次保存 ${new Date(savedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}` : '尚未保存'}
          </span>
          <button type="button" className="text-button" onClick={onOpenVersions}>
            历史版本
          </button>
        </div>
      </div>

      {summaryOpen && (
        <div className="summary-panel">
          <div className="note-tabs" role="tablist" aria-label="章节笔记">
            <button
              type="button"
              role="tab"
              aria-selected={noteTab === 'summary'}
              className={noteTab === 'summary' ? 'active' : ''}
              onClick={() => setNoteTab('summary')}
            >
              <FileText size={14} />
              摘要
              <em>{draft.summary ? `${draft.summary.length} 字` : '空'}</em>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={noteTab === 'beats'}
              className={noteTab === 'beats' ? 'active' : ''}
              onClick={() => setNoteTab('beats')}
            >
              <List size={14} />
              场景卡
              <em>{draft.beats ? '已填' : '空'}</em>
            </button>
          </div>
          {noteTab === 'summary' ? (
            <>
              <div className="summary-panel-head">
                <strong>本章摘要</strong>
                <span>写给几十章之后的自己。只记事实、变化和留下的压力。</span>
              </div>
              <textarea
                value={draft.summary}
                onChange={(event) => onChange({ summary: event.target.value })}
                placeholder="这一章发生了什么？谁知道了什么？结束时局面哪里不一样了？"
                rows={4}
                maxLength={4000}
              />
              <p className="summary-hint">摘要会进入后续章节的“前情提要”，不进入读者看到的正文。</p>
            </>
          ) : (
            <>
              <div className="summary-panel-head">
                <strong>本章场景卡</strong>
                <span>按节拍写，不要写正文。生成时会作为本章的施工图。</span>
              </div>
              <textarea
                value={draft.beats}
                onChange={(event) => onChange({ beats: event.target.value })}
                placeholder={'1. 目标：谁想要什么\n2. 阻力：什么在阻止他\n3. 转折：哪一步让局面变了\n4. 出口：章末留下什么压力\n\n可选：视角限制、关键道具、必须出现的台词。'}
                rows={6}
                maxLength={20000}
              />
              <p className="summary-hint">场景卡会进入生成上下文，优先级高于泛泛的大纲；也可以把“拆章”结果一键存到这里。</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
