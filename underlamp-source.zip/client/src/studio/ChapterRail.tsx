import { useState, type FormEvent } from 'react';
import { ChevronDown, ChevronUp, Plus, Trash2, X } from 'lucide-react';
import { formatNumber } from '../lib/format';
import type { ChapterMeta } from '../types';

export function ChapterRail({
  chapters,
  currentId,
  words,
  open,
  onClose,
  onSelect,
  onAdd,
  onDelete,
  onMove,
}: {
  chapters: ChapterMeta[];
  currentId: string | null;
  words: number;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onAdd: (title: string) => Promise<void>;
  onDelete: (chapter: ChapterMeta) => void;
  onMove: (id: string, direction: -1 | 1) => void;
}) {
  const [adding, setAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!title.trim() || busy) return;
    setBusy(true);
    try {
      await onAdd(title.trim());
      setTitle('');
      setAdding(false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <aside className={`chapter-rail ${open ? 'is-open' : ''}`} aria-label="章节目录">
      <div className="rail-head">
        <div>
          <span className="rail-kicker">目录</span>
          <strong>{chapters.length} 章</strong>
        </div>
        <div className="rail-head-actions">
          <button type="button" className="icon-button" onClick={() => setAdding(true)} aria-label="新建章节">
            <Plus size={17} />
          </button>
          <button type="button" className="icon-button rail-close" onClick={onClose} aria-label="关闭目录">
            <X size={17} />
          </button>
        </div>
      </div>

      <div className="rail-list">
        {chapters.length === 0 && (
          <p className="rail-empty">还没有章节。先写下第一行。</p>
        )}
        {chapters.map((chapter, index) => (
          <div key={chapter.id} className={`rail-item ${chapter.id === currentId ? 'active' : ''}`}>
            <button type="button" className="rail-item-main" onClick={() => onSelect(chapter.id)}>
              <span className="rail-number">{String(index + 1).padStart(2, '0')}</span>
              <span className="rail-copy">
                <strong>{chapter.title}</strong>
                <span>
                  {formatNumber(chapter.wordCount)} 字
                  {chapter.status === 'final' && <em className="rail-final">定稿</em>}
                  {chapter.status === 'outline' && <em className="rail-outline">待写</em>}
                </span>
              </span>
            </button>
            <div className="rail-actions">
              <button
                type="button"
                className="icon-button tiny"
                onClick={() => onMove(chapter.id, -1)}
                disabled={index === 0}
                aria-label="上移章节"
              >
                <ChevronUp size={13} />
              </button>
              <button
                type="button"
                className="icon-button tiny"
                onClick={() => onMove(chapter.id, 1)}
                disabled={index === chapters.length - 1}
                aria-label="下移章节"
              >
                <ChevronDown size={13} />
              </button>
              <button
                type="button"
                className="icon-button tiny danger"
                onClick={() => onDelete(chapter)}
                aria-label="删除章节"
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}

        {adding && (
          <form className="rail-add" onSubmit={submit}>
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="章节名，如：第三章 雨停之后"
              autoFocus
              maxLength={120}
            />
            <button type="submit" className="btn btn-primary btn-sm" disabled={!title.trim() || busy}>
              {busy ? '…' : '添加'}
            </button>
          </form>
        )}
      </div>

      <div className="rail-foot">
        <span>共 {chapters.length} 章</span>
        <span>{formatNumber(words)} 字</span>
        <button type="button" className="rail-add-link" onClick={() => setAdding(true)}>
          <Plus size={13} /> 新章
        </button>
      </div>
    </aside>
  );
}
