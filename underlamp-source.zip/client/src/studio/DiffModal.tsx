import { useMemo } from 'react';
import { Check, X } from 'lucide-react';
import { Modal } from '../components/Modal';
import { diffText } from '../lib/diff';
import { formatNumber } from '../lib/format';

export function DiffModal({
  open,
  onClose,
  before,
  after,
  onAccept,
}: {
  open: boolean;
  onClose: () => void;
  before: string;
  after: string;
  onAccept: () => void;
}) {
  const parts = useMemo(() => diffText(before, after), [before, after]);
  const removed = parts.filter((part) => part.type === 'remove').reduce((sum, part) => sum + part.text.length, 0);
  const added = parts.filter((part) => part.type === 'add').reduce((sum, part) => sum + part.text.length, 0);
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="改动预览"
      description="先看删了什么、加了什么。接受之前不会覆盖原稿；旧稿仍可在历史版本里找回。"
      size="xl"
      footer={
        <>
          <span className="diff-stats">−{formatNumber(removed)} 字 · +{formatNumber(added)} 字</span>
          <button type="button" className="btn btn-ghost" onClick={onClose}><X size={14} /> 不接受</button>
          <button type="button" className="btn btn-primary" onClick={onAccept}><Check size={14} /> 接受并替换</button>
        </>
      }
    >
      <div className="diff-legend">
        <span className="diff-legend-remove">原文 / 删除</span>
        <span className="diff-legend-add">新稿 / 增加</span>
        <span>相同句子保持原样</span>
      </div>
      <div className="diff-body">
        {parts.map((part, index) => (
          <span key={index} className={`diff-part ${part.type}`}>{part.text}</span>
        ))}
      </div>
    </Modal>
  );
}
