import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  BookMarked,
  BookOpen,
  ChevronDown,
  Download,
  FileDown,
  Focus,
  Menu,
  MessageCircle,
  PenLine,
  PanelRight,
  Plus,
  Search,
  Settings2,
  Sparkles,
  Trash2,
  Wand2,
} from 'lucide-react';
import { api, getProviders } from '../api';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { FullPageLoader, Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { downloadProject } from '../local/export';
import { countWords, formatNumber, formatWords, statusLabel } from '../lib/format';
import { useModels } from '../lib/useModels';
import type { Bible, Chapter, ChapterMeta, CodexEntry, ProjectDetail, ProjectSummary, Provider, Skill } from '../types';
import { AiPanel } from './AiPanel';
import { BiblePanel } from './BiblePanel';
import { ChapterEditor } from './ChapterEditor';
import { ChapterRail } from './ChapterRail';
import { ChatPanel } from './ChatPanel';
import { CodexPanel } from './CodexPanel';
import { CodexSidebar } from './CodexSidebar';
import { InkCompanion } from './InkCompanion';
import { ProjectSearchModal } from './ProjectSearchModal';
import { SkillFinderModal } from '../pages/Skills';
import { ProjectSettingsModal } from './ProjectSettingsModal';
import { VersionModal } from './VersionModal';
import type { Draft, SaveState, TextSelection } from './types';

type View = 'write' | 'bible' | 'chat' | 'codex';

function metaFromChapter(chapter: Chapter): ChapterMeta {
  return {
    id: chapter.id,
    projectId: chapter.projectId,
    title: chapter.title,
    summary: chapter.summary,
    beats: chapter.beats || '',
    status: chapter.status,
    sort: chapter.sort,
    wordCount: chapter.wordCount,
    targetWords: chapter.targetWords || 0,
    createdAt: chapter.createdAt,
    updatedAt: chapter.updatedAt,
  };
}

export function Studio() {
  const { id: projectId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const [detail, setDetail] = useState<ProjectDetail | null>(null);
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [chapterLoading, setChapterLoading] = useState(false);
  const [saveState, setSaveState] = useState<SaveState>('saved');
  const [savedAt, setSavedAt] = useState(0);
  const [view, setView] = useState<View>('write');
  const [railOpen, setRailOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(() => (typeof window === 'undefined' ? true : window.innerWidth > 900));
  const [selection, setSelection] = useState<TextSelection>({ start: 0, end: 0, text: '' });
  const [providers, setProviders] = useState<Provider[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [selectedSkillIds, setSelectedSkillIds] = useState<string[]>([]);
  const [projectSettingsOpen, setProjectSettingsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [companionOpen, setCompanionOpen] = useState(false);
  const [skillFinderOpen, setSkillFinderOpen] = useState(false);
  const [codexSidebarOpen, setCodexSidebarOpen] = useState(false);
  const [codexEntries, setCodexEntries] = useState<CodexEntry[]>([]);
  const [focusMode, setFocusMode] = useState(false);
  const [typewriter, setTypewriter] = useState(false);
  const [aiRequest, setAiRequest] = useState<{ action: string; instruction: string; token: number } | null>(null);
  const [versionOpen, setVersionOpen] = useState(false);
  const [deleteProjectOpen, setDeleteProjectOpen] = useState(false);
  const [deleteChapterTarget, setDeleteChapterTarget] = useState<ChapterMeta | null>(null);
  const [deletingChapter, setDeletingChapter] = useState(false);
  const [deletingProject, setDeletingProject] = useState(false);
  const models = useModels(providers);

  const draftRef = useRef<Draft | null>(null);
  const chapterRef = useRef<Chapter | null>(null);
  const savingRef = useRef<Promise<boolean> | null>(null);

  useEffect(() => {
    draftRef.current = draft;
  }, [draft]);
  useEffect(() => {
    chapterRef.current = chapter;
  }, [chapter]);

  useEffect(() => {
    if (!projectId) return;
    let alive = true;
    setLoading(true);
    Promise.all([
      api.get<ProjectDetail>(`/api/projects/${projectId}`),
      getProviders().catch(() => ({ providers: [] as Provider[], presets: [] })),
      api.get<{ skills: Skill[] }>('/api/skills').catch(() => ({ skills: [] as Skill[] })),
    ])
      .then(([projectData, providerData, skillData]) => {
        if (!alive) return;
        setDetail(projectData);
        setProviders(providerData.providers);
        setSkills(skillData.skills);
        const storedChapter = localStorage.getItem(`underlamp.lastChapter.${projectId}`);
        const chapterId = projectData.chapters.some((item) => item.id === storedChapter)
          ? storedChapter
          : projectData.project.lastChapterId || projectData.chapters[0]?.id || null;
        setSelectedChapterId(chapterId);
        if (chapterId) localStorage.setItem(`underlamp.lastChapter.${projectId}`, chapterId);

        const skillStorageKey = `underlamp.skills.${projectId}`;
        const enabledSkills = skillData.skills.filter((skill) => skill.enabled);
        let chosen: string[] = [];
        try {
          let stored = JSON.parse(localStorage.getItem(skillStorageKey) || 'null');
          if (!Array.isArray(stored)) {
            const legacy = JSON.parse(localStorage.getItem('underlamp.skills') || '[]');
            // 旧版只有一个全局选择；迁移时只保留仍启用的技能，丢掉被自动带上的 LICENSE 等资料。
            stored = Array.isArray(legacy)
              ? legacy.filter((skillId: string) => {
                  const skill = enabledSkills.find((item) => item.id === skillId);
                  return Boolean(skill && skill.kind === 'skill');
                })
              : [];
            localStorage.removeItem('underlamp.skills');
          }
          if (Array.isArray(stored)) {
            chosen = stored.filter((skillId: string) => enabledSkills.some((skill) => skill.id === skillId));
          }
        } catch {
          chosen = [];
        }
        if (!chosen.length) {
          const preferred = ['去 AI 味：中文小说文风', '场景推进', '对话潜台词'];
          chosen = enabledSkills
            .filter((skill) => skill.kind === 'skill' && preferred.includes(skill.name))
            .slice(0, 2)
            .map((skill) => skill.id);
          if (!chosen.length) {
            chosen = enabledSkills.filter((skill) => skill.kind === 'skill').slice(0, 2).map((skill) => skill.id);
          }
        }
        setSelectedSkillIds(chosen);
        localStorage.setItem(skillStorageKey, JSON.stringify(chosen));
        setLoading(false);
      })
      .catch((error) => {
        if (!alive) return;
        toast.error((error as Error).message || '这本书没有打开');
        navigate('/library', { replace: true });
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  useEffect(() => {
    if (!projectId) return;
    let alive = true;
    api.get<{ entries: CodexEntry[] }>(`/api/projects/${projectId}/codex`)
      .then((data) => {
        if (alive) setCodexEntries(data.entries);
      })
      .catch(() => undefined);
    return () => { alive = false; };
  }, [projectId, view]);

  useEffect(() => {
    if (!selectedChapterId) {
      setChapter(null);
      setDraft(null);
      chapterRef.current = null;
      draftRef.current = null;
      setSavedAt(0);
      setSaveState('saved');
      setChapterLoading(false);
      return;
    }
    let alive = true;
    setChapterLoading(true);
    setSelection({ start: 0, end: 0, text: '' });
    api
      .get<{ chapter: Chapter }>(`/api/chapters/${selectedChapterId}`)
      .then((data) => {
        if (!alive) return;
        const loaded = data.chapter;
        const nextDraft: Draft = {
          title: loaded.title,
          content: loaded.content,
          summary: loaded.summary,
          beats: loaded.beats || '',
          targetWords: loaded.targetWords || 0,
          status: loaded.status,
        };
        setChapter(loaded);
        setDraft(nextDraft);
        chapterRef.current = loaded;
        draftRef.current = nextDraft;
        setSavedAt(loaded.updatedAt);
        setSaveState('saved');
      })
      .catch((error) => {
        if (alive) toast.error((error as Error).message || '章节没有读出来');
      })
      .finally(() => {
        if (alive) setChapterLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [selectedChapterId, toast]);

  useEffect(() => {
    if (!skills.length) return;
    const enabledIds = new Set(skills.filter((skill) => skill.enabled).map((skill) => skill.id));
    setSelectedSkillIds((current) => {
      const next = current.filter((id) => enabledIds.has(id));
      return next.length === current.length ? current : next;
    });
  }, [skills]);

  useEffect(() => {
    if (!projectId || !skills.length) return;
    try {
      localStorage.setItem(`underlamp.skills.${projectId}`, JSON.stringify(selectedSkillIds));
    } catch {
      /* ignore */
    }
  }, [selectedSkillIds, skills.length, projectId]);

  const refreshProjectMeta = useCallback((updated: Chapter) => {
    setDetail((current) => {
      if (!current) return current;
      const chapters = current.chapters.map((item) => (item.id === updated.id ? metaFromChapter(updated) : item));
      return {
        ...current,
        chapters,
        project: {
          ...current.project,
          chapters: chapters.length,
          words: chapters.reduce((sum, item) => sum + item.wordCount, 0),
          lastChapter: chapters.at(-1)?.title || current.project.lastChapter,
          updatedAt: updated.updatedAt,
        },
      };
    });
  }, []);

  const saveNow = useCallback(async () => {
    if (savingRef.current) return savingRef.current;
    const currentChapter = chapterRef.current;
    const currentDraft = draftRef.current;
    if (!currentChapter || !currentDraft) return true;
    if (
      currentChapter.title === currentDraft.title &&
      currentChapter.content === currentDraft.content &&
      currentChapter.summary === currentDraft.summary &&
      (currentChapter.targetWords || 0) === (currentDraft.targetWords || 0) &&
      currentChapter.status === currentDraft.status
    ) {
      setSaveState('saved');
      return true;
    }
    setSaveState('saving');
    const promise = (async () => {
      try {
        const data = await api.patch<{ chapter: Chapter }>(`/api/chapters/${currentChapter.id}`, currentDraft);
        const stillSame =
          draftRef.current?.title === currentDraft.title &&
          draftRef.current?.content === currentDraft.content &&
          draftRef.current?.summary === currentDraft.summary &&
          (draftRef.current?.targetWords || 0) === (currentDraft.targetWords || 0) &&
          draftRef.current?.status === currentDraft.status;
        setChapter(data.chapter);
        chapterRef.current = data.chapter;
        setSavedAt(data.chapter.updatedAt);
        refreshProjectMeta(data.chapter);
        setSaveState(stillSame ? 'saved' : 'dirty');
        return true;
      } catch (error) {
        setSaveState('error');
        toast.error((error as Error).message || '自动保存失败');
        return false;
      } finally {
        savingRef.current = null;
      }
    })();
    savingRef.current = promise;
    return promise;
  }, [refreshProjectMeta, toast]);

  useEffect(() => {
    if (saveState !== 'dirty' || !draft) return;
    const timer = window.setTimeout(() => {
      void saveNow();
    }, 900);
    return () => window.clearTimeout(timer);
  }, [draft, saveState, saveNow]);

  async function flushSave() {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      if (savingRef.current) {
        await savingRef.current;
        continue;
      }
      const currentChapter = chapterRef.current;
      const currentDraft = draftRef.current;
      if (!currentChapter || !currentDraft) return true;
      if (
        currentChapter.title === currentDraft.title &&
        currentChapter.content === currentDraft.content &&
        currentChapter.summary === currentDraft.summary &&
        (currentChapter.targetWords || 0) === (currentDraft.targetWords || 0) &&
        currentChapter.status === currentDraft.status
      ) {
        return true;
      }
      const saved = await saveNow();
      if (!saved) return false;
    }
    return false;
  }

  function warnUnsaved() {
    toast.error('当前章节还没有保存成功，先别离开这一页');
  }

  async function switchView(next: View) {
    if (next === view) return true;
    if (!(await flushSave())) {
      warnUnsaved();
      return false;
    }
    setView(next);
    setCodexSidebarOpen(false);
    return true;
  }

  async function openCodex() {
    if (await switchView('codex')) setCompanionOpen(false);
  }

  async function runFromCompanion(action: string, instruction: string) {
    if (!(await switchView('write'))) return;
    setAiOpen(true);
    setAiRequest({ action, instruction, token: Date.now() });
    setCompanionOpen(false);
  }

  async function goSettings() {
    if (!(await flushSave())) {
      warnUnsaved();
      return;
    }
    navigate('/settings');
  }

  async function enableFoundSkills(ids: string[]) {
    const targets = skills.filter((skill) => ids.includes(skill.id) && !skill.enabled);
    try {
      for (const skill of targets) {
        await api.patch(`/api/skills/${skill.id}`, { enabled: true });
      }
      if (targets.length) {
        const targetIds = new Set(targets.map((skill) => skill.id));
        setSkills((current) => current.map((skill) => (targetIds.has(skill.id) ? { ...skill, enabled: true } : skill)));
      }
      setSelectedSkillIds((current) => [...new Set([...current, ...ids])]);
      toast.success(targets.length ? `已启用并勾选 ${targets.length} 个技能` : '已勾选技能');
      setSkillFinderOpen(false);
    } catch (error) {
      toast.error((error as Error).message || '技能没有启用');
    }
  }

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') {
        event.preventDefault();
        void saveNow();
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [saveNow]);

  useEffect(() => {
    function beforeUnload(event: BeforeUnloadEvent) {
      if (saveState === 'dirty' || saveState === 'saving' || saveState === 'error') {
        event.preventDefault();
        event.returnValue = '';
      }
    }
    window.addEventListener('beforeunload', beforeUnload);
    return () => window.removeEventListener('beforeunload', beforeUnload);
  }, [saveState]);

  function updateDraft(patch: Partial<Draft>) {
    setDraft((current) => {
      if (!current) return current;
      const next = { ...current, ...patch };
      draftRef.current = next;
      return next;
    });
    setSaveState('dirty');
  }

  async function selectChapter(chapterId: string) {
    setRailOpen(false);
    if (chapterId === selectedChapterId) return;
    if (!(await flushSave())) {
      warnUnsaved();
      return;
    }
    setSelectedChapterId(chapterId);
    if (projectId) localStorage.setItem(`underlamp.lastChapter.${projectId}`, chapterId);
  }

  async function addChapter(title: string) {
    if (!projectId) return;
    if (!(await flushSave())) {
      warnUnsaved();
      return;
    }
    try {
      const data = await api.post<{ chapter: Chapter }>(`/api/projects/${projectId}/chapters`, { title });
      const meta = metaFromChapter(data.chapter);
      setDetail((current) => {
        if (!current) return current;
        const chapters = [...current.chapters, meta];
        return {
          ...current,
          chapters,
          project: {
            ...current.project,
            chapters: chapters.length,
            words: chapters.reduce((sum, item) => sum + item.wordCount, 0),
            lastChapter: chapters.at(-1)?.title || current.project.lastChapter,
          },
        };
      });
      setSelectedChapterId(data.chapter.id);
      localStorage.setItem(`underlamp.lastChapter.${projectId}`, data.chapter.id);
      toast.success('新章已经添上');
    } catch (error) {
      toast.error((error as Error).message || '新章没有添上');
    }
  }

  async function deleteChapter() {
    if (!deleteChapterTarget) return;
    setDeletingChapter(true);
    try {
      await api.delete(`/api/chapters/${deleteChapterTarget.id}`);
      const currentChapters = detail?.chapters || [];
      const index = currentChapters.findIndex((item) => item.id === deleteChapterTarget.id);
      const remaining = currentChapters.filter((item) => item.id !== deleteChapterTarget.id);
      setDetail((current) => {
        if (!current) return current;
        const chapters = current.chapters.filter((item) => item.id !== deleteChapterTarget.id);
        return {
          ...current,
          chapters,
          project: {
            ...current.project,
            chapters: chapters.length,
            words: chapters.reduce((sum, item) => sum + item.wordCount, 0),
          },
        };
      });
      if (deleteChapterTarget.id === selectedChapterId) {
        const next = remaining[Math.min(index, remaining.length - 1)];
        setSelectedChapterId(next?.id || null);
        if (next && projectId) localStorage.setItem(`underlamp.lastChapter.${projectId}`, next.id);
      }
      toast.success('章节已删除');
      setDeleteChapterTarget(null);
    } catch (error) {
      toast.error((error as Error).message || '没有删掉');
    } finally {
      setDeletingChapter(false);
    }
  }

  async function moveChapter(chapterId: string, direction: -1 | 1) {
    if (!detail || !projectId) return;
    const ids = detail.chapters.map((item) => item.id);
    const index = ids.indexOf(chapterId);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= ids.length) return;
    [ids[index], ids[target]] = [ids[target], ids[index]];
    const reordered = ids
      .map((id) => detail.chapters.find((item) => item.id === id)!)
      .map((item, sort) => ({ ...item, sort }));
    const previous = detail.chapters;
    setDetail({ ...detail, chapters: reordered });
    try {
      await api.post(`/api/projects/${projectId}/chapters/reorder`, { ids });
    } catch (error) {
      setDetail((current) => (current ? { ...current, chapters: previous } : current));
      toast.error((error as Error).message || '顺序没有改');
    }
  }

  function applyAi(text: string, mode: 'insert' | 'replace' | 'append') {
    if (!draft) return;
    const clean = text.trim();
    if (!clean) return;
    const start = Math.max(0, Math.min(selection.start, draft.content.length));
    const end = Math.max(start, Math.min(selection.end, draft.content.length));
    let next = draft.content;
    if (mode === 'replace' && end > start) {
      next = `${next.slice(0, start)}${clean}${next.slice(end)}`;
    } else if (mode === 'replace') {
      next = next ? `${next.trimEnd()}\n\n${clean}` : clean;
    } else if (mode === 'insert') {
      const before = next.slice(0, end);
      const after = next.slice(end);
      const leftGap = before && !before.endsWith('\n') ? '\n\n' : '';
      const rightGap = after && !after.startsWith('\n') ? '\n\n' : '';
      next = `${before}${leftGap}${clean}${rightGap}${after}`;
    } else {
      next = next.trim() ? `${next.trimEnd()}\n\n${clean}` : clean;
    }
    updateDraft({ content: next });
    setSelection({ start: end + clean.length, end: end + clean.length, text: '' });
    toast.success('已经放进稿纸');
  }

  function saveSummary(text: string) {
    updateDraft({ summary: text.trim() });
    toast.success('摘要已放进本章');
  }

  function saveBeats(text: string) {
    updateDraft({ beats: text.trim() });
    toast.success('场景卡已放进本章');
  }

  async function saveProject(updated: ProjectSummary) {
    setDetail((current) => (current ? { ...current, project: { ...current.project, ...updated } } : current));
  }

  async function saveBible(patch: Partial<Bible>) {
    if (!projectId) return;
    const data = await api.patch<{ bible: ProjectDetail['bible'] }>(`/api/projects/${projectId}/bible`, patch);
    setDetail((current) => (current ? { ...current, bible: data.bible } : current));
  }

  async function deleteProject() {
    if (!projectId) return;
    setDeletingProject(true);
    try {
      await api.delete(`/api/projects/${projectId}`);
      toast.success('这本书已经从书架上移除');
      navigate('/library', { replace: true });
    } catch (error) {
      toast.error((error as Error).message || '没有删掉');
    } finally {
      setDeletingProject(false);
      setDeleteProjectOpen(false);
    }
  }

  async function goLibrary() {
    if (!(await flushSave())) {
      warnUnsaved();
      return;
    }
    navigate('/library');
  }

  async function exportBook(format: 'md' | 'txt' | 'json' | 'docx') {
    if (!projectId) return;
    try {
      await downloadProject(projectId, format);
      toast.success('导出文件已生成');
    } catch (error) {
      toast.error((error as Error).message || '导出失败');
    }
  }

  if (loading) return <FullPageLoader label="正在把书翻到上次那一页" />;
  if (!detail) return null;

  const project = detail.project;
  const chapters = detail.chapters;
  const chapterNumber = chapter ? chapters.findIndex((item) => item.id === chapter.id) + 1 : 0;
  const words = draft ? countWords(draft.content) : 0;
  const provider = providers.find((item) => item.id === models.providerId) || null;

  const codexMentions = codexEntries
    .filter((entry) => {
      const terms = [entry.name, ...entry.aliases].filter((term) => term.length >= 2);
      return entry.pinned || terms.some((term) => (draft?.content || '').includes(term));
    })
    .slice(0, 10);
  const mentionChips = codexMentions.map((entry) => ({ id: entry.id, name: entry.name, kind: entry.kind }));

  return (
    <div className={`studio ${focusMode ? 'focus-mode' : ''}`}>
      <header className="studio-top">
        <div className="studio-top-left">
          <button type="button" className="icon-button studio-back" onClick={goLibrary} aria-label="回到书房">
            <ArrowLeft size={18} />
          </button>
          <button type="button" className="icon-button studio-search" onClick={() => setSearchOpen(true)} aria-label="搜索全书" title="搜索全书（⌘K / Ctrl K）">
            <Search size={17} />
          </button>
          <button type="button" className="studio-book-title" onClick={() => setProjectSettingsOpen(true)}>
            <span>{project.title}</span>
            <ChevronDown size={14} />
          </button>
          <span className="studio-status">{statusLabel(project.status)}</span>
        </div>

        <nav className="studio-tabs" aria-label="作品视图">
          <button type="button" className={view === 'write' ? 'active' : ''} onClick={() => { void switchView('write'); }}>
            <PenLine size={15} />
            写作
          </button>
          <button type="button" className={view === 'bible' ? 'active' : ''} onClick={() => { void switchView('bible'); }}>
            <BookOpen size={15} />
            设定
          </button>
          <button type="button" className={view === 'codex' ? 'active' : ''} onClick={() => { void switchView('codex'); }}>
            <BookMarked size={15} />
            资料
          </button>
          <button type="button" className={view === 'chat' ? 'active' : ''} onClick={() => { void switchView('chat'); }}>
            <MessageCircle size={15} />
            对谈
          </button>
        </nav>

        <div className="studio-top-right">
          <span className={`save-indicator ${saveState}`}>
            {saveState === 'saving' ? <Spinner size={12} /> : <span className="save-dot" />}
            {saveState === 'saved' ? '已保存' : saveState === 'saving' ? '保存中' : saveState === 'dirty' ? '未保存' : '保存失败'}
          </span>
          <span className="studio-words">{formatNumber(words)} 字</span>
          <details className="export-menu">
            <summary className="btn btn-ghost btn-sm">
              <Download size={14} />
              导出
            </summary>
            <div className="export-pop">
              <button type="button" onClick={() => { void exportBook('md'); }}>
                <FileDown size={14} /> Markdown
              </button>
              <button type="button" onClick={() => { void exportBook('docx'); }}>
                <FileDown size={14} /> Word 文档
              </button>
              <button type="button" onClick={() => { void exportBook('txt'); }}>
                <FileDown size={14} /> 纯文本
              </button>
              <button type="button" onClick={() => { void exportBook('json'); }}>
                <FileDown size={14} /> 项目备份
              </button>
            </div>
          </details>
          <button
            type="button"
            className="icon-button rail-toggle"
            onClick={() => {
              void (async () => {
                if (await switchView('write')) setRailOpen(true);
              })();
            }}
            aria-label="打开章节目录"
          >
            <Menu size={18} />
          </button>
          <button
            type="button"
            className={`btn btn-ghost btn-sm ai-toggle ${aiOpen ? 'active' : ''}`}
            onClick={() => {
              void (async () => {
                if (view !== 'write') {
                  if (await switchView('write')) setAiOpen(true);
                } else {
                  setAiOpen((value) => !value);
                }
              })();
            }}
          >
            <PanelRight size={15} />
            灯下
          </button>
          <button type="button" className="icon-button studio-settings" onClick={() => setSkillFinderOpen(true)} aria-label="找技能" title="找技能">
            <Wand2 size={17} />
          </button>
          <button type="button" className="icon-button studio-settings" onClick={() => setProjectSettingsOpen(true)} aria-label="作品资料">
            <Settings2 size={17} />
          </button>
        </div>
      </header>

      <div className={`studio-body ${view === 'write' && aiOpen ? 'ai-open' : ''}`}>
        {view === 'write' && (
          <>
            {railOpen && <button type="button" className="studio-scrim" aria-label="关闭目录" onClick={() => setRailOpen(false)} />}
            <ChapterRail
              chapters={chapters}
              currentId={selectedChapterId}
              words={project.words}
              open={railOpen}
              onClose={() => setRailOpen(false)}
              onSelect={selectChapter}
              onAdd={addChapter}
              onDelete={setDeleteChapterTarget}
              onMove={moveChapter}
            />
          </>
        )}

        <main className={`studio-main view-${view}`}>
          {view === 'write' ? (
            chapterLoading ? (
              <div className="editor-loading">
                <Spinner size={20} />
                正在翻到这一页
              </div>
            ) : draft ? (
              <ChapterEditor
                draft={draft}
                chapterNumber={chapterNumber}
                saveState={saveState}
                savedAt={savedAt}
                onChange={updateDraft}
                onSelectionChange={setSelection}
                onOpenVersions={() => setVersionOpen(true)}
                onOpenCodex={() => setCodexSidebarOpen(true)}
                focusMode={focusMode}
                typewriter={typewriter}
                onToggleFocus={() => setFocusMode((value) => !value)}
                onToggleTypewriter={() => setTypewriter((value) => !value)}
                codexMentions={mentionChips}
              />
            ) : (
              <div className="studio-empty">
                <BookOpen size={30} />
                <h2>这本书还没有章节。</h2>
                <p>先写第一行。名字可以之后再改。</p>
                <button type="button" className="btn btn-primary" onClick={() => addChapter('第一章')}>
                  <Plus size={16} />
                  写下第一章
                </button>
              </div>
            )
          ) : view === 'bible' ? (
            <BiblePanel
              projectId={projectId!}
              bible={detail.bible}
              provider={provider}
              model={models.model}
              onSave={saveBible}
              onOpenSettings={goSettings}
            />
          ) : view === 'codex' ? (
            <CodexPanel
              project={project}
              bible={detail.bible}
              chapters={detail.chapters}
              provider={provider}
              model={models.model}
              onOpenSettings={goSettings}
              onOpenChapter={(chapterId) => {
                void (async () => {
                  if (await switchView('write')) await selectChapter(chapterId);
                })();
              }}
            />
          ) : (
            <ChatPanel
              projectId={projectId!}
              providers={providers}
              providerId={models.providerId}
              model={models.model}
              onProviderChange={models.setProviderId}
              onModelChange={models.setModel}
              skills={skills}
              selectedSkillIds={selectedSkillIds}
              onSelectedSkillIdsChange={setSelectedSkillIds}
              onOpenSettings={goSettings}
            />
          )}
        </main>

        {view === 'write' && aiOpen && (
          <>
            {aiOpen && <button type="button" className="studio-scrim ai-scrim" aria-label="收起灯下" onClick={() => setAiOpen(false)} />}
            <AiPanel
              open={aiOpen}
              onClose={() => setAiOpen(false)}
              projectId={projectId!}
              chapterId={chapter?.id || null}
              chapterTitle={draft?.title || ''}
              providers={providers}
              providerId={models.providerId}
              model={models.model}
              onProviderChange={models.setProviderId}
              onModelChange={models.setModel}
              skills={skills}
              selectedSkillIds={selectedSkillIds}
              onSelectedSkillIdsChange={setSelectedSkillIds}
              selection={selection}
              onApply={applyAi}
              onSaveSummary={saveSummary}
              onSaveBeats={saveBeats}
              onOpenSettings={goSettings}
              request={aiRequest}
              onBeforeContext={flushSave}
            />
          </>
        )}
      </div>

      {focusMode && (
        <button type="button" className="focus-exit" onClick={() => setFocusMode(false)}>
          <Focus size={15} /> 退出专注
        </button>
      )}
      <CodexSidebar
        open={codexSidebarOpen}
        entries={codexEntries}
        mentions={codexMentions}
        onClose={() => setCodexSidebarOpen(false)}
        onOpenFull={() => { setCodexSidebarOpen(false); void openCodex(); }}
      />

      {!companionOpen && (
        <button type="button" className="ink-fab" onClick={() => setCompanionOpen(true)} aria-label="叫出灯灵">
          <Sparkles size={18} />
          <span>灯灵</span>
        </button>
      )}
      <InkCompanion
        open={companionOpen}
        onClose={() => setCompanionOpen(false)}
        project={project}
        bible={detail.bible}
        chapters={detail.chapters}
        provider={provider}
        model={models.model}
        onOpenCodex={() => { void openCodex(); }}
        onRunAction={(action, instruction) => { void runFromCompanion(action, instruction); }}
        onOpenSettings={goSettings}
        selection={selection}
        onApply={applyAi}
      />

      <nav className="studio-mobile-tabs" aria-label="移动端作品导航">
        <button type="button" className={view === 'write' ? 'active' : ''} onClick={() => { void switchView('write'); }}>
          <PenLine size={17} />
          写作
        </button>
        <button type="button" className={view === 'bible' ? 'active' : ''} onClick={() => { void switchView('bible'); }}>
          <BookOpen size={17} />
          设定
        </button>
        <button type="button" className={view === 'codex' ? 'active' : ''} onClick={() => { void switchView('codex'); }}>
          <BookMarked size={17} />
          资料
        </button>
        <button type="button" className={view === 'chat' ? 'active' : ''} onClick={() => { void switchView('chat'); }}>
          <MessageCircle size={17} />
          对谈
        </button>
        <button
          type="button"
          className={aiOpen && view === 'write' ? 'active' : ''}
          onClick={() => {
            void (async () => {
              if (await switchView('write')) setAiOpen(true);
            })();
          }}
        >
          <PanelRight size={17} />
          灯下
        </button>
      </nav>

      <ProjectSearchModal
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        projectId={projectId!}
        onSelect={(chapterId) => {
          void selectChapter(chapterId);
        }}
      />
      <SkillFinderModal
        open={skillFinderOpen}
        onClose={() => setSkillFinderOpen(false)}
        skills={skills}
        onEnable={enableFoundSkills}
      />
      <ProjectSettingsModal
        open={projectSettingsOpen}
        project={project}
        onClose={() => setProjectSettingsOpen(false)}
        onSaved={saveProject}
        onDelete={() => {
          setProjectSettingsOpen(false);
          setDeleteProjectOpen(true);
        }}
      />
      <VersionModal
        open={versionOpen}
        chapterId={chapter?.id || null}
        onClose={() => setVersionOpen(false)}
        onRestored={(restored) => {
          const nextDraft: Draft = {
            title: restored.title,
            content: restored.content,
            summary: restored.summary,
            beats: restored.beats || '',
            targetWords: restored.targetWords || 0,
            status: restored.status,
          };
          setChapter(restored);
          chapterRef.current = restored;
          setDraft(nextDraft);
          draftRef.current = nextDraft;
          setSavedAt(restored.updatedAt);
          setSaveState('saved');
          refreshProjectMeta(restored);
        }}
      />
      <ConfirmDialog
        open={Boolean(deleteChapterTarget)}
        title="删掉这一章？"
        message={`《${deleteChapterTarget?.title || ''}》的正文、摘要和历史版本都会删除，不能恢复。`}
        confirmLabel="删除章节"
        danger
        busy={deletingChapter}
        onCancel={() => setDeleteChapterTarget(null)}
        onConfirm={deleteChapter}
      />
      <ConfirmDialog
        open={deleteProjectOpen}
        title="删除整本书？"
        message={`《${project.title}》的全部章节、设定和历史版本都会从这台浏览器删除，不能恢复。建议先导出一份备份。`}
        confirmLabel="删除整本书"
        danger
        busy={deletingProject}
        onCancel={() => setDeleteProjectOpen(false)}
        onConfirm={deleteProject}
      />
    </div>
  );
}
