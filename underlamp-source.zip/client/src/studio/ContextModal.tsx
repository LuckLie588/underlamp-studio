import { useEffect, useState } from 'react';
import { Check, Copy, Eye, RefreshCw } from 'lucide-react';
import { previewContext } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { formatNumber } from '../lib/format';
import type { ContextPreview } from '../types';

export function ContextModal({
  open,
  onClose,
  providerId,
  model,
  projectId,
  chapterId,
  action,
  instruction,
  selection,
  skillIds,
  contextChars,
}: {
  open: boolean;
  onClose: () => void;
  providerId: string;
  model: string;
  projectId: string;
  chapterId: string | null;
  action: string;
  instruction: string;
  selection: string;
  skillIds: string[];
  contextChars: number;
}) {
  const toast = useToast();
  const [data, setData] = useState<ContextPreview | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'system' | 'user'>('system');
  const [copied, setCopied] = useState(false);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const result = await previewContext({
        providerId,
        model,
        action,
        projectId,
        chapterId,
        instruction,
        selection,
        skillIds,
        contextChars,
      });
      setData(result);
    } catch (err) {
      setError((err as Error).message || '上下文没有读出来');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (open) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, projectId, chapterId, action]);

  async function copy() {
    if (!data) return;
    try {
      await navigator.clipboard.writeText(tab === 'system' ? data.system : data.user);
      setCopied(true);
      toast.success('已复制');
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.error('浏览器没有允许复制，请手动选中');
    }
  }

  const text = tab === 'system' ? data?.system || '' : data?.user || '';

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="上下文透视"
      description="这是本次生成真正会发给模型的提示词。只读预览，不会调用模型，也不额外计费。"
      size="xl"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>关闭</button>
          <button type="button" className="btn btn-ghost" onClick={load} disabled={loading}>
            {loading ? <Spinner size={14} /> : <RefreshCw size={14} />}
            重新读取
          </button>
          <button type="button" className="btn btn-primary" onClick={copy} disabled={!data}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? '已复制' : '复制当前页'}
          </button>
        </>
      }
    >
      {loading && !data ? (
        <div className="context-loading"><Spinner size={18} /> 正在整理上下文</div>
      ) : error ? (
        <p className="form-error">{error}</p>
      ) : data ? (
        <div className="context-modal">
          <div className="context-stats">
            <span><strong>{formatNumber(data.stats.contextChars)}</strong> 字符</span>
            <span><strong>≈{formatNumber(data.estimatedTokens)}</strong> tokens</span>
            <span><strong>{data.stats.skills.length}</strong> 件工具</span>
            <span><strong>{(data.stats.codex || []).length}</strong> 条 Codex</span>
            {data.stats.genrePack && <span className="context-stats-target">类型包 · {data.stats.genrePack}</span>}
            <span><strong>{data.stats.chaptersBefore}</strong> 章前情</span>
            <span className="context-stats-target">{data.actionLabel} · 《{data.chapter?.title || data.project.title}》</span>
          </div>
          {data.stats.codex && data.stats.codex.length > 0 && (
            <div className="context-codex">
              <span>本次注入</span>
              {data.stats.codex.map((entry) => (
                <em key={entry.id}>{entry.name}</em>
              ))}
            </div>
          )}
          {data.stats.truncated?.length > 0 && (
            <div className="context-truncated">
              {data.stats.truncated.map((item, index) => (
                <p key={`${item.label}-${index}`}>
                  {item.label}：因预算裁掉约 {formatNumber(item.dropped)} 字
                </p>
              ))}
            </div>
          )}
          <div className="context-tabs" role="tablist">
            <button type="button" role="tab" aria-selected={tab === 'system'} className={tab === 'system' ? 'active' : ''} onClick={() => setTab('system')}>
              <Eye size={14} />
              System 提示词
              <em>{formatNumber(data.system.length)} 字</em>
            </button>
            <button type="button" role="tab" aria-selected={tab === 'user'} className={tab === 'user' ? 'active' : ''} onClick={() => setTab('user')}>
              本次任务
              <em>{formatNumber(data.user.length)} 字</em>
            </button>
          </div>
          <pre className="context-pre">{text}</pre>
          <p className="context-note">
            System 包含作品设定、前情、技能与规则；本次任务包含当前正文/选中文本和你的额外要求。修改技能或上下文预算后，重新读取即可对比。
          </p>
        </div>
      ) : null}
    </Modal>
  );
}
