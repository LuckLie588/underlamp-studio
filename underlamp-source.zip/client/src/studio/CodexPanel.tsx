import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  BookMarked,
  Check,
  ChevronDown,
  Clock3,
  MapPin,
  Package,
  Plus,
  ScanLine,
  Search,
  Shield,
  Sparkles,
  Trash2,
  Users,
  Wand2,
  X,
} from 'lucide-react';
import { api, completeAgent } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { emptyCodexEntry, extractCodexFromBible, scanCodexWithAgent, starterCodex } from '../local/codex';
import { assistText, type AssistMode } from '../local/aiAssist';
import { formatNumber } from '../lib/format';
import { RelationshipsGraph } from './RelationshipsGraph';
import { ProjectReportModal } from './ProjectReportModal';
import type { Bible, ChapterMeta, CodexEntry, CodexKind, ProjectSummary, Provider, TimelineEvent } from '../types';

const KIND_META: Record<CodexKind, { label: string; icon: typeof Users }> = {
  character: { label: '人物', icon: Users },
  location: { label: '地点', icon: MapPin },
  faction: { label: '势力', icon: Shield },
  item: { label: '物品', icon: Package },
  concept: { label: '设定', icon: Sparkles },
};

const KIND_ORDER: CodexKind[] = ['character', 'location', 'faction', 'item', 'concept'];

function parseAliases(value: string) {
  return value.split(/[,，、\n]/).map((item) => item.trim()).filter(Boolean).slice(0, 12);
}

function parseRelationships(value: string) {
  return value
    .split(/\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [name, label, note] = line.split(/[|｜]/).map((item) => item.trim());
      return { name: name || '', label: label || '', note: note || '' };
    })
    .filter((item) => item.name)
    .slice(0, 30);
}

function relationshipsText(entry: CodexEntry) {
  return entry.relationships.map((rel) => [rel.name, rel.label, rel.note].filter(Boolean).join('｜')).join('\n');
}

export function CodexPanel({
  project,
  bible,
  chapters,
  provider,
  model,
  onOpenSettings,
  onCountChange,
  onOpenChapter,
}: {
  project: ProjectSummary;
  bible: Bible;
  chapters: ChapterMeta[];
  provider: Provider | null;
  model: string;
  onOpenSettings: () => void;
  onCountChange?: (count: number) => void;
  onOpenChapter?: (chapterId: string) => void;
}) {
  const toast = useToast();
  const [entries, setEntries] = useState<CodexEntry[]>([]);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [mentions, setMentions] = useState<Record<string, { count: number; chapters: Array<{ id: string; title: string; count: number }> }>>({});
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<'entries' | 'timeline' | 'relations'>('entries');
  const [kind, setKind] = useState<'all' | CodexKind>('all');
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draft, setDraft] = useState<CodexEntry | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [scanBusy, setScanBusy] = useState(false);
  const [suggestions, setSuggestions] = useState<{ entries: any[]; timeline: any[] } | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [assistBusy, setAssistBusy] = useState<AssistMode | null>(null);
  const [selectedSuggestions, setSelectedSuggestions] = useState<Set<number>>(new Set());
  const [timelineDraft, setTimelineDraft] = useState<TimelineEvent | null>(null);

  async function load() {
    setLoading(true);
    try {
      const [data, mentionData] = await Promise.all([
        api.get<{ entries: CodexEntry[]; timeline: TimelineEvent[] }>(`/api/projects/${project.id}/codex`),
        api.get<{ mentions: Record<string, { count: number; chapters: Array<{ id: string; title: string; count: number }> }> }>(`/api/projects/${project.id}/codex/mentions`).catch(() => ({ mentions: {} })),
      ]);
      setEntries(data.entries);
      setTimeline(data.timeline);
      setMentions(mentionData.mentions);
      onCountChange?.(data.entries.length);
      setSelectedId((current) => (current && data.entries.some((entry) => entry.id === current) ? current : null));
    } catch (error) {
      toast.error((error as Error).message || '资料库没有读出来');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    setSelectedId(null);
    setDraft(null);
    setDirty(false);
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project.id]);

  const selected = useMemo(() => entries.find((entry) => entry.id === selectedId) || null, [entries, selectedId]);
  useEffect(() => {
    if (!selectedId && draft && !draft.id && dirty) return;
    setDraft(selected ? { ...selected } : null);
    setDirty(false);
  }, [selectedId, selected]);

  const filtered = entries.filter((entry) => {
    if (kind !== 'all' && entry.kind !== kind) return false;
    const haystack = `${entry.name} ${entry.aliases.join(' ')} ${entry.summary} ${entry.tags.join(' ')}`.toLowerCase();
    return !query.trim() || haystack.includes(query.trim().toLowerCase());
  });
  const selectedMentions = draft?.id ? mentions[draft.id] : null;
  const mentionCounts = new Map((selectedMentions?.chapters || []).map((chapter) => [chapter.id, chapter.count]));
  const mentionMax = Math.max(1, ...(selectedMentions?.chapters || []).map((chapter) => chapter.count));
  const timelineByChapter = timeline.filter((event) => event.chapterId);

  function startNew() {
    setMode('entries');
    setSelectedId(null);
    setDraft(emptyCodexEntry(project.id, kind === 'all' ? 'character' : kind));
    setDirty(true);
  }

  async function saveEntry() {
    if (!draft || !draft.name.trim()) return;
    setSaving(true);
    try {
      const payload = {
        ...draft,
        aliases: draft.aliases,
        relationships: draft.relationships,
      };
      const data = draft.id
        ? await api.patch<{ entry: CodexEntry }>(`/api/codex/${draft.id}`, payload)
        : await api.post<{ entry: CodexEntry }>(`/api/projects/${project.id}/codex`, payload);
      setEntries((current) => {
        const next = current.some((entry) => entry.id === data.entry.id)
          ? current.map((entry) => (entry.id === data.entry.id ? data.entry : entry))
          : [...current, data.entry];
        onCountChange?.(next.length);
        return next;
      });
      setSelectedId(data.entry.id);
      setDraft(data.entry);
      setDirty(false);
      toast.success(draft.id ? '资料已更新' : '资料已入库');
    } catch (error) {
      toast.error((error as Error).message || '没有保存');
    } finally {
      setSaving(false);
    }
  }

  async function assistEntry(field: 'summary' | 'details', mode: AssistMode) {
    if (!draft) return;
    if (!provider) {
      toast.info('先接入模型，才能让 AI 处理资料');
      onOpenSettings();
      return;
    }
    setAssistBusy(mode);
    try {
      const context = [
        `作品：《${project.title}》 ${project.premise}`,
        `世界：${bible.world}`,
        `人物：${bible.characters}`,
        `当前条目：${draft.name}（${draft.role || '未填身份'}）`,
        `已有摘要：${draft.summary}`,
        `已有详情：${draft.details}`,
      ].join('\n');
      const result = await assistText({
        providerId: provider.id,
        model,
        mode,
        field: field === 'summary' ? '一句话摘要' : '详情',
        value: draft[field],
        context,
      });
      if (!result) throw new Error('这次没有写出内容');
      setDraft((current) => (current ? { ...current, [field]: result } : current));
      setDirty(true);
      toast.success(mode === 'polish' ? '资料已润色，记得保存' : '资料已补齐，记得保存');
    } catch (error) {
      toast.error((error as Error).message || 'AI 没有处理成功');
    } finally {
      setAssistBusy(null);
    }
  }

  async function deleteEntry() {    if (!draft?.id) return;
    if (!window.confirm(`删除「${draft.name}」？`)) return;
    try {
      await api.delete(`/api/codex/${draft.id}`);
      const next = entries.filter((entry) => entry.id !== draft.id);
      setEntries(next);
      onCountChange?.(next.length);
      setSelectedId(null);
      setDraft(null);
      toast.success('资料已删除');
    } catch (error) {
      toast.error((error as Error).message || '没有删除');
    }
  }

  async function scan() {
    if (!provider) {
      useBibleFallback('未接模型，先按现有设定整理了一版');
      return;
    }
    setScanBusy(true);
    try {
      const fullChapters = await Promise.all(
        chapters.map((chapter) =>
          api.get<{ chapter: { content: string } }>(`/api/chapters/${chapter.id}`)
            .then((data) => ({ title: chapter.title, content: data.chapter.content }))
            .catch(() => ({ title: chapter.title, content: '' })),
        ),
      );
      const data = await scanCodexWithAgent({
        project,
        bible,
        chapters: fullChapters,
        providerId: provider.id,
        model,
      });
      if (!data.entries.length) throw new Error('没有提取到可用条目');
      setSuggestions(data);
      setSelectedSuggestions(new Set(data.entries.map((_: unknown, index: number) => index)));
    } catch (error) {
      const fallback = useBibleFallback('AI 没有整理成 JSON，先用现有设定做了一版');
      if (!fallback) toast.error((error as Error).message || '扫描失败');
    } finally {
      setScanBusy(false);
    }
  }

  function useBibleFallback(message: string) {
    const fallback = extractCodexFromBible(project, bible, project.id);
    if (!fallback.entries.length) {
      toast.info('现有设定还太少，先手写几条资料');
      return false;
    }
    setSuggestions(fallback);
    setSelectedSuggestions(new Set(fallback.entries.map((_: unknown, index: number) => index)));
    toast.info(message);
    return true;
  }

  async function useStarter() {
    const data = starterCodex(project, project.id);
    setSuggestions(data);
    setSelectedSuggestions(new Set(data.entries.map((_, index) => index)));
  }

  async function importSuggestions() {
    if (!suggestions) return;
    const chosen = suggestions.entries.filter((_, index) => selectedSuggestions.has(index));
    if (!chosen.length) return;
    setSaving(true);
    try {
      const result = await api.post<{ entries: CodexEntry[]; timeline: TimelineEvent[] }>(`/api/projects/${project.id}/codex/batch`, {
        entries: chosen,
        timeline: suggestions.timeline,
      });
      setSuggestions(null);
      await load();
      if (result.entries.length === 0) toast.info('这些条目已经在资料库里了');
      else toast.success(`已入库 ${result.entries.length} 条 Codex`);
    } catch (error) {
      toast.error((error as Error).message || '没有入库');
    } finally {
      setSaving(false);
    }
  }

  async function saveTimeline() {
    if (!timelineDraft?.title.trim()) return;
    setSaving(true);
    try {
      const data = timelineDraft.id
        ? await api.patch<{ event: TimelineEvent }>(`/api/timeline/${timelineDraft.id}`, timelineDraft)
        : await api.post<{ event: TimelineEvent }>(`/api/projects/${project.id}/timeline`, timelineDraft);
      setTimeline((current) => {
        const next = current.some((event) => event.id === data.event.id)
          ? current.map((event) => (event.id === data.event.id ? data.event : event))
          : [...current, data.event];
        return next.sort((a, b) => a.storyTime.localeCompare(b.storyTime));
      });
      setTimelineDraft(data.event);
      toast.success('时间线已更新');
    } catch (error) {
      toast.error((error as Error).message || '没有保存时间线');
    } finally {
      setSaving(false);
    }
  }

  async function deleteTimeline() {
    if (!timelineDraft?.id) return;
    if (!window.confirm('删除这个时间线事件？')) return;
    try {
      await api.delete(`/api/timeline/${timelineDraft.id}`);
      setTimeline((current) => current.filter((event) => event.id !== timelineDraft.id));
      setTimelineDraft(null);
    } catch (error) {
      toast.error((error as Error).message || '没有删除');
    }
  }

  return (
    <div className="codex-page">
      <header className="codex-head">
        <div>
          <p className="section-kicker">CODEX / 资料库</p>
          <h1>故事里的人和物。</h1>
          <p>只注入这一章真正用到的条目：置顶、提到的名字/别名、未回收伏笔。</p>
        </div>
        <div className="codex-head-actions">
          <button type="button" className="btn btn-ghost" onClick={() => setReportOpen(true)}>
            <Activity size={15} />
            全书体检
          </button>
          <button type="button" className="btn btn-ghost" onClick={scan} disabled={scanBusy}>
            {scanBusy ? <Spinner size={15} /> : <ScanLine size={15} />}
            扫描本书
          </button>
          <button type="button" className="btn btn-ghost" onClick={useStarter}>
            <Wand2 size={15} />
            快速模板
          </button>
          <button type="button" className="btn btn-primary" onClick={startNew}>
            <Plus size={15} />
            新建条目
          </button>
        </div>
      </header>

      <div className="codex-toolbar">
        <div className="codex-mode-tabs">
          <button type="button" className={mode === 'entries' ? 'active' : ''} onClick={() => setMode('entries')}>
            资料 <em>{entries.length}</em>
          </button>
          <button type="button" className={mode === 'timeline' ? 'active' : ''} onClick={() => setMode('timeline')}>
            时间线 <em>{timeline.length}</em>
          </button>
          <button type="button" className={mode === 'relations' ? 'active' : ''} onClick={() => setMode('relations')}>
            关系 <em>{entries.reduce((sum, entry) => sum + entry.relationships.length, 0)}</em>
          </button>
        </div>
        {mode === 'entries' && (
          <>
            <label className="codex-search">
              <Search size={14} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜名字、别名、摘要" />
            </label>
            <select value={kind} onChange={(event) => setKind(event.target.value as typeof kind)} className="codex-filter">
              <option value="all">全部类型</option>
              {KIND_ORDER.map((item) => <option key={item} value={item}>{KIND_META[item].label}</option>)}
            </select>
          </>
        )}
      </div>

      {loading ? (
        <div className="codex-loading"><Spinner size={18} /> 正在翻资料柜</div>
      ) : mode === 'entries' ? (
        <div className="codex-layout">
          <aside className="codex-list">
            {filtered.length === 0 ? (
              <div className="codex-empty">
                <BookMarked size={24} />
                <p>还没有这类资料。</p>
                <button type="button" className="text-button" onClick={startNew}>新建一条</button>
              </div>
            ) : (
              filtered.map((entry) => {
                const Icon = KIND_META[entry.kind].icon;
                return (
                  <button
                    key={entry.id}
                    type="button"
                    className={`codex-row ${selectedId === entry.id ? 'active' : ''}`}
                    onClick={() => setSelectedId(entry.id)}
                  >
                    <span className={`codex-kind kind-${entry.kind}`}><Icon size={14} /></span>
                    <span className="codex-row-copy">
                      <strong>{entry.name}{entry.pinned ? <em>置顶</em> : null}</strong>
                      <small>{entry.aliases.length ? `别名：${entry.aliases.join('、')}` : entry.summary || KIND_META[entry.kind].label}{mentions[entry.id]?.count ? ` · 出场 ${mentions[entry.id].count} 次` : ''}</small>
                    </span>
                    <span className="codex-row-kind">{KIND_META[entry.kind].label}</span>
                  </button>
                );
              })
            )}
          </aside>

          <section className="codex-detail">
            {!draft ? (
              <div className="codex-detail-empty">
                <BookMarked size={26} />
                <h2>从一个人、一个地方，或者一件东西开始。</h2>
                <p>选中左边条目，或新建。Codex 不是给读者看的，是给下一章的你留的便条。</p>
              </div>
            ) : (
              <form className="codex-form" onSubmit={(event) => { event.preventDefault(); void saveEntry(); }}>
                <div className="codex-form-head">
                  <div>
                    <span className="section-kicker">{draft.id ? 'EDIT ENTRY' : 'NEW ENTRY'}</span>
                    <h2>{draft.name || '未命名条目'}</h2>
                    {draft.id && mentions[draft.id]?.count ? (
                      <div className="codex-mention-block">
                        <p className="codex-mention-line">出场 {mentions[draft.id].count} 次</p>
                        <div className="codex-mention-chapters">
                          {mentions[draft.id].chapters.map((chapter) => (
                            <button key={chapter.id} type="button" onClick={() => onOpenChapter?.(chapter.id)}>
                              {chapter.title} <em>{chapter.count}</em>
                            </button>
                          ))}
                        </div>
                        <div className="codex-mention-chart" aria-hidden="true">
                          {chapters.map((chapter) => {
                            const count = mentionCounts.get(chapter.id) || 0;
                            return (
                              <span
                                key={chapter.id}
                                className={count ? '' : 'zero'}
                                style={{ height: `${Math.max(3, Math.round((count / mentionMax) * 26))}px` }}
                                title={`${chapter.title} · ${count} 次${timelineByChapter.filter((event) => event.chapterId === chapter.id).length ? ` · ${timelineByChapter.filter((event) => event.chapterId === chapter.id).map((event) => event.title).join('、')}` : ''}`}
                              />
                            );
                          })}
                        </div>
                        {timelineByChapter.length > 0 && (
                          <div className="codex-timeline-strip">
                            <span>时间线</span>
                            {timelineByChapter.map((event) => {
                              const index = chapters.findIndex((chapter) => chapter.id === event.chapterId);
                              return (
                                <button
                                  key={event.id}
                                  type="button"
                                  style={{ left: `${chapters.length > 1 ? (Math.max(0, index) / (chapters.length - 1)) * 100 : 0}%` }}
                                  title={`${event.storyTime || ''} ${event.title}`}
                                  onClick={() => onOpenChapter?.(event.chapterId || '')}
                                />
                              );
                            })}
                          </div>
                        )}
                      </div>
                    ) : null}
                  </div>
                  <div className="codex-form-actions">
                    {draft.id && <button type="button" className="icon-button danger" onClick={deleteEntry} aria-label="删除条目"><Trash2 size={15} /></button>}
                    <button type="submit" className="btn btn-primary" disabled={saving || !draft.name.trim()}>
                      {saving ? <Spinner size={14} /> : <Check size={14} />}
                      保存
                    </button>
                  </div>
                </div>

                <div className="editor-row">
                  <label className="field">
                    <span>类型</span>
                    <select value={draft.kind} onChange={(event) => setDraft({ ...draft, kind: event.target.value as CodexKind })}>
                      {KIND_ORDER.map((item) => <option key={item} value={item}>{KIND_META[item].label}</option>)}
                    </select>
                  </label>
                  <label className="field">
                    <span>名称</span>
                    <input value={draft.name} onChange={(event) => { setDraft({ ...draft, name: event.target.value }); setDirty(true); }} required />
                  </label>
                </div>
                <label className="field">
                  <span>别名（逗号分隔）</span>
                  <input value={draft.aliases.join('，')} onChange={(event) => { setDraft({ ...draft, aliases: parseAliases(event.target.value) }); setDirty(true); }} placeholder="例如：小名，绰号，旧称" />
                </label>
                <div className="editor-row">
                  <label className="field">
                    <span>{draft.kind === 'character' ? '身份 / 角色' : '定位'}</span>
                    <input value={draft.role} onChange={(event) => { setDraft({ ...draft, role: event.target.value }); setDirty(true); }} />
                  </label>
                  <label className="check-line codex-pin">
                    <input type="checkbox" checked={draft.pinned} onChange={(event) => { setDraft({ ...draft, pinned: event.target.checked }); setDirty(true); }} />
                    <span>每次生成都带上这一条</span>
                  </label>
                </div>
                <div className="codex-ai-row">
                  <span>AI 处理资料</span>
                  <button type="button" onClick={() => { void assistEntry('summary', 'polish'); }} disabled={Boolean(assistBusy)}>{assistBusy === 'polish' ? <Spinner size={12} /> : <Wand2 size={12} />}润色摘要</button>
                  <button type="button" onClick={() => { void assistEntry('summary', 'fill'); }} disabled={Boolean(assistBusy)}><Sparkles size={12} />补齐摘要</button>
                  <button type="button" onClick={() => { void assistEntry('details', 'polish'); }} disabled={Boolean(assistBusy)}>润色详情</button>
                  <button type="button" onClick={() => { void assistEntry('details', 'fill'); }} disabled={Boolean(assistBusy)}>补齐详情</button>
                </div>
                <label className="field">
                  <span>一句话摘要</span>
                  <textarea value={draft.summary} onChange={(event) => { setDraft({ ...draft, summary: event.target.value }); setDirty(true); }} rows={3} />
                </label>
                {draft.kind === 'character' && (
                  <div className="codex-character-grid">
                    <label className="field"><span>欲望</span><textarea value={draft.desire} onChange={(event) => { setDraft({ ...draft, desire: event.target.value }); setDirty(true); }} rows={2} /></label>
                    <label className="field"><span>恐惧 / 伤口</span><textarea value={draft.fear} onChange={(event) => { setDraft({ ...draft, fear: event.target.value }); setDirty(true); }} rows={2} /></label>
                    <label className="field"><span>秘密</span><textarea value={draft.secret} onChange={(event) => { setDraft({ ...draft, secret: event.target.value }); setDirty(true); }} rows={2} /></label>
                    <label className="field"><span>说话方式</span><textarea value={draft.voice} onChange={(event) => { setDraft({ ...draft, voice: event.target.value }); setDirty(true); }} rows={2} /></label>
                    <label className="field"><span>当前状态</span><textarea value={draft.state} onChange={(event) => { setDraft({ ...draft, state: event.target.value }); setDirty(true); }} rows={2} /></label>
                    <label className="field"><span>关系（名字｜关系｜备注，每行一条）</span><textarea value={relationshipsText(draft)} onChange={(event) => { setDraft({ ...draft, relationships: parseRelationships(event.target.value) }); setDirty(true); }} rows={3} /></label>
                  </div>
                )}
                <label className="field">
                  <span>详情</span>
                  <textarea value={draft.details} onChange={(event) => { setDraft({ ...draft, details: event.target.value }); setDirty(true); }} rows={6} />
                </label>
                <label className="field">
                  <span>标签（逗号分隔）</span>
                  <input value={draft.tags.join('，')} onChange={(event) => { setDraft({ ...draft, tags: parseAliases(event.target.value) }); setDirty(true); }} />
                </label>
                {dirty && <p className="form-hint">有改动未保存。</p>}
              </form>
            )}
          </section>
        </div>
      ) : mode === 'relations' ? (
        <div className="codex-relations">
          <RelationshipsGraph
            entries={entries}
            onSelect={(id) => {
              setSelectedId(id);
              setMode('entries');
            }}
          />
        </div>
      ) : (
        <div className="codex-layout">
          <aside className="codex-list">
            <button type="button" className="codex-add-timeline" onClick={() => setTimelineDraft({
              id: '', projectId: project.id, storyTime: '', title: '', description: '', participants: [], chapterId: null, consequences: '', createdAt: Date.now(), updatedAt: Date.now(),
            })}>
              <Plus size={14} /> 新增时间线事件
            </button>
            {timeline.length === 0 ? (
              <div className="codex-empty"><Clock3 size={24} /><p>还没有时间线。把“什么时候发生了什么”记下来。</p></div>
            ) : timeline.map((event) => (
              <button key={event.id} type="button" className={`codex-row ${timelineDraft?.id === event.id ? 'active' : ''}`} onClick={() => setTimelineDraft(event)}>
                <span className="codex-kind kind-timeline"><Clock3 size={14} /></span>
                <span className="codex-row-copy"><strong>{event.title}</strong><small>{event.storyTime || '未标时间'} · {event.description.slice(0, 40)}</small></span>
              </button>
            ))}
          </aside>
          <section className="codex-detail">
            {!timelineDraft ? (
              <div className="codex-detail-empty"><Clock3 size={26} /><h2>时间线让“后来”有地方落脚。</h2><p>事件不必写成正文，只要写清时间、参与者、后果。</p></div>
            ) : (
              <form className="codex-form" onSubmit={(event) => { event.preventDefault(); void saveTimeline(); }}>
                <div className="codex-form-head">
                  <div><span className="section-kicker">TIMELINE</span><h2>{timelineDraft.title || '新事件'}</h2></div>
                  <div className="codex-form-actions">
                    {timelineDraft.id && <button type="button" className="icon-button danger" onClick={deleteTimeline} aria-label="删除事件"><Trash2 size={15} /></button>}
                    <button type="submit" className="btn btn-primary" disabled={saving || !timelineDraft.title.trim()}>{saving ? <Spinner size={14} /> : <Check size={14} />}保存</button>
                  </div>
                </div>
                <div className="editor-row">
                  <label className="field"><span>故事时间</span><input value={timelineDraft.storyTime} onChange={(event) => setTimelineDraft({ ...timelineDraft, storyTime: event.target.value })} placeholder="例如：第一年·深秋 / 祭典前三日" /></label>
                  <label className="field"><span>事件标题</span><input value={timelineDraft.title} onChange={(event) => setTimelineDraft({ ...timelineDraft, title: event.target.value })} required /></label>
                </div>
                <label className="field"><span>发生了什么</span><textarea value={timelineDraft.description} onChange={(event) => setTimelineDraft({ ...timelineDraft, description: event.target.value })} rows={4} /></label>
                <label className="field">
                  <span>关联章节</span>
                  <select value={timelineDraft.chapterId || ''} onChange={(event) => setTimelineDraft({ ...timelineDraft, chapterId: event.target.value || null })}>
                    <option value="">不关联章节</option>
                    {chapters.map((chapter) => <option key={chapter.id} value={chapter.id}>{chapter.title}</option>)}
                  </select>
                </label>
                <div className="editor-row">
                  <label className="field"><span>参与者（逗号分隔）</span><input value={timelineDraft.participants.join('，')} onChange={(event) => setTimelineDraft({ ...timelineDraft, participants: parseAliases(event.target.value) })} /></label>
                  <label className="field"><span>后果 / 改变了什么</span><input value={timelineDraft.consequences} onChange={(event) => setTimelineDraft({ ...timelineDraft, consequences: event.target.value })} /></label>
                </div>
              </form>
            )}
          </section>
        </div>
      )}

      <Modal
        open={Boolean(suggestions)}
        onClose={() => setSuggestions(null)}
        title="把这本书整理成 Codex"
        description="AI 只做建议。勾选你认可的条目，入库前还可以在资料库里改。"
        size="xl"
        footer={
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setSuggestions(null)}>取消</button>
            <button type="button" className="btn btn-primary" onClick={importSuggestions} disabled={saving || selectedSuggestions.size === 0}>
              {saving ? <Spinner size={15} /> : <Check size={15} />}
              入库 {selectedSuggestions.size} 条
            </button>
          </>
        }
      >
        {suggestions && (
          <div className="codex-suggestions">
            {suggestions.entries.map((entry, index) => (
              <label key={`${entry.name}-${index}`} className={`codex-suggestion ${selectedSuggestions.has(index) ? 'selected' : ''}`}>
                <input
                  type="checkbox"
                  checked={selectedSuggestions.has(index)}
                  onChange={() => {
                    const next = new Set(selectedSuggestions);
                    if (next.has(index)) next.delete(index); else next.add(index);
                    setSelectedSuggestions(next);
                  }}
                />
                <span className={`codex-kind kind-${entry.kind}`}>{KIND_META[entry.kind as CodexKind]?.label || '条目'}</span>
                <span><strong>{entry.name}</strong><small>{entry.summary || entry.role || entry.details?.slice(0, 80)}</small></span>
              </label>
            ))}
            {suggestions.timeline.length > 0 && <p className="form-hint">另有 {suggestions.timeline.length} 条时间线会一起入库。</p>}
          </div>
        )}
      </Modal>
      <ProjectReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        projectId={project.id}
        bible={bible}
        chapters={chapters}
        codex={entries}
        timeline={timeline}
        mentions={mentions}
      />
    </div>
  );
}
