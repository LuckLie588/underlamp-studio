import { useEffect, useRef, useState } from 'react';
import { AlertCircle, BookOpen, Check, Copy, Download, Sparkles, Wand2 } from 'lucide-react';
import { api, ApiError, completeAgent, streamExtract } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { StyleVersionsModal } from './StyleVersionsModal';
import { assistText, type AssistMode } from '../local/aiAssist';
import { useToast } from '../context/ToastContext';
import { formatNumber, timeAgo } from '../lib/format';
import type { AiMeta, Bible, Provider } from '../types';

const tabs = [
  {
    key: 'world' as const,
    label: '世界',
    hint: '地点、时代、规则、气候。写模型需要知道的可感知事实。',
    placeholder: '临海旧城：虚构的沿海小城，终年多雾，旧港区与新城隔河相望。主要空间：旧宅、渡口、档案馆……',
  },
  {
    key: 'characters' as const,
    label: '人物',
    hint: '欲望、伤口、谎言、关系。不要只写性格标签。',
    placeholder: '林晚，32 岁，声音修复师。欲望：找回失踪的姐姐。伤口：母亲从不谈那场火灾……',
  },
  {
    key: 'outline' as const,
    label: '大纲',
    hint: '卷、章、转折与结尾。写给未来的自己，不是写给读者。',
    placeholder: '第一卷《回声》\n1. 主角回到旧城，在旧宅发现一盘未寄出的录音带……',
  },
  {
    key: 'foreshadowing' as const,
    label: '伏笔',
    hint: '一行一条，用 - [ ] 标记未回收，- [x] 标记已回收。未回收的会进入每次生成的上下文。',
    placeholder: '- [ ] 旧钥匙是谁留下的（第1章 旧宅）\n- [ ] 主角左手伤痕的来历（第1章）\n- [x] 旧宅邻居的遗言“别回头”（第3章 已兑现）',
  },
  {
    key: 'style' as const,
    label: '文风',
    hint: '从样章提取，或手写。文风卡进入每次生成，优先于通用文风建议。',
    placeholder: '叙述距离：第三人称限知，贴着主角的感官。\n句子：短句为主，少用四字词。\n意象：雨、铁锈、旧纸。\n对话：答非所问，不解释设定。\n禁忌：不写“他感到……”的情绪总结。',
  },
  {
    key: 'rules' as const,
    label: '规则',
    hint: '视角、禁忌、不能犯的错。它们会优先于通用写作习惯。',
    placeholder: '只写主角的限知视角。不写全知旁白。每章末尾必须改变局面……',
  },
  {
    key: 'themes' as const,
    label: '主题',
    hint: '这本书在反复追问什么？不要写成中心思想。',
    placeholder: '记忆不是事实，而是幸存者反复修改的证词。一个人可以用二十一年的沉默去爱……',
  },
];

export function BiblePanel({
  projectId,
  bible,
  provider,
  model,
  onSave,
  onOpenSettings,
}: {
  projectId: string;
  bible: Bible;
  provider: Provider | null;
  model: string;
  onSave: (patch: Partial<Bible>) => Promise<void>;
  onOpenSettings: () => void;
}) {
  const toast = useToast();
  const [values, setValues] = useState({
    world: bible.world,
    characters: bible.characters,
    outline: bible.outline,
    foreshadowing: bible.foreshadowing || '',
    style: bible.style || '',
    rules: bible.rules,
    themes: bible.themes,
  });
  const [active, setActive] = useState<(typeof tabs)[number]['key']>('world');
  const [dirty, setDirty] = useState(false);
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error'>('saved');
  const [extractOpen, setExtractOpen] = useState(false);
  const [styleBusy, setStyleBusy] = useState(false);
  const [assistBusy, setAssistBusy] = useState<AssistMode | null>(null);
  const [styleVersionsOpen, setStyleVersionsOpen] = useState(false);
  const [revision, setRevision] = useState(0);
  const valuesRef = useRef(values);
  const revisionRef = useRef(0);
  const savingRef = useRef(false);
  const dirtyRef = useRef(false);
  const onSaveRef = useRef(onSave);
  const savedRef = useRef(bible.updatedAt);

  useEffect(() => {
    valuesRef.current = values;
  }, [values]);

  useEffect(() => {
    dirtyRef.current = dirty;
  }, [dirty]);

  useEffect(() => {
    onSaveRef.current = onSave;
  }, [onSave]);

  useEffect(() => {
    return () => {
      if (dirtyRef.current) {
        void onSaveRef.current(valuesRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const next = {
      world: bible.world,
      characters: bible.characters,
      outline: bible.outline,
      foreshadowing: bible.foreshadowing || '',
      style: bible.style || '',
      rules: bible.rules,
      themes: bible.themes,
    };
    valuesRef.current = next;
    setValues(next);
    setDirty(false);
    setSaveState('saved');
    savedRef.current = bible.updatedAt;
    // Only reset when switching to a different book. Saves must not overwrite
    // characters typed while a request is in flight.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  useEffect(() => {
    if (!dirty) return;
    const timer = window.setTimeout(async () => {
      if (savingRef.current) return;
      const snapshot = { ...valuesRef.current };
      const attemptRevision = revisionRef.current;
      savingRef.current = true;
      setSaveState('saving');
      try {
        await onSaveRef.current(snapshot);
        savedRef.current = Date.now();
        if (revisionRef.current === attemptRevision) {
          setDirty(false);
          setSaveState('saved');
        } else {
          setSaveState('saved');
          setRevision((value) => value + 1);
        }
      } catch {
        setSaveState('error');
      } finally {
        savingRef.current = false;
      }
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [dirty, revision]);

  function change(key: keyof typeof values, value: string) {
    revisionRef.current += 1;
    setValues((current) => {
      const next = { ...current, [key]: value };
      valuesRef.current = next;
      return next;
    });
    setDirty(true);
    setRevision(revisionRef.current);
  }

  async function saveStyleVersion(
    source: 'manual' | 'extract' = 'manual',
    meta: { model?: string; sampleChapters?: string[]; promptVersion?: string } = {},
    content = values.style,
  ) {
    if (!content.trim()) {
      toast.info('文风卡还是空的');
      return;
    }
    try {
      await api.post(`/api/projects/${projectId}/style-versions`, {
        content,
        source,
        model: meta.model || model,
        providerLabel: provider?.label || '',
        sampleChapters: meta.sampleChapters || [],
        promptVersion: meta.promptVersion || 'r4-style-v1',
      });
      toast.success(source === 'extract' ? '这次提取已存为版本' : '当前文风已存为版本');
    } catch (error) {
      toast.error((error as Error).message || '版本没有存下来');
    }
  }

  async function extractStyle() {
    if (!provider) {
      toast.info('先接入模型，才能从正文提取文风');
      onOpenSettings();
      return;
    }
    setStyleBusy(true);
    try {
      const detail = await api.get<{ chapters: Array<{ id: string; title: string }> }>(`/api/projects/${projectId}`);
      const samples: string[] = [];
      const sampleChapters: string[] = [];
      for (const chapter of detail.chapters.slice(0, 5)) {
        const data = await api.get<{ chapter: { title: string; content: string } }>(`/api/chapters/${chapter.id}`);
        if (data.chapter.content.trim()) {
          samples.push(`【${data.chapter.title}】\n${data.chapter.content.slice(0, 6000)}`);
          sampleChapters.push(chapter.id);
        }
      }
      if (!samples.length) {
        toast.info('还没有正文。先写一章，再提取文风');
        return;
      }
      const result = await completeAgent({
        providerId: provider.id,
        model,
        system: `你是中文小说编辑。请从样章中提取可执行的“文风卡”，只输出 Markdown，不要解释。
必须覆盖：叙述距离与视角、句子长度与节奏、常用意象/感官、对话习惯、段落与留白、标点与禁用写法。
每条都要具体到能指导下一章，不要写“文笔优美”这种空话。不超过 500 字。`,
        messages: [{ role: 'user', content: `以下是同一本书的样章，请提取文风卡：\n\n${samples.join('\n\n').slice(0, 18000)}` }],
        temperature: 0.2,
        maxTokens: 1800,
      });
      setValues((current) => ({ ...current, style: result.text.trim() }));
      setDirty(true);
      await saveStyleVersion('extract', { model: result.model, sampleChapters, promptVersion: 'r4-style-v1' }, result.text.trim());
      toast.success('文风卡已生成，可以直接改');
    } catch (error) {
      toast.error((error as Error).message || '文风没有提取出来');
    } finally {
      setStyleBusy(false);
    }
  }

  const current = tabs.find((tab) => tab.key === active)!;

  async function assistField(mode: AssistMode) {
    if (!provider) {
      toast.info('先接入模型，才能让 AI 处理设定');
      onOpenSettings();
      return;
    }
    setAssistBusy(mode);
    try {
      const context = tabs
        .map((tab) => `【${tab.label}】${values[tab.key].slice(0, 2500) || '（空）'}`)
        .join('\n\n');
      const result = await assistText({
        providerId: provider.id,
        model,
        mode,
        field: current.label,
        value: values[active],
        context,
      });
      if (!result) throw new Error('这次没有写出内容');
      setValues((currentValues) => ({ ...currentValues, [active]: result }));
      setDirty(true);
      toast.success(mode === 'polish' ? '设定已润色，记得保存' : '设定已补齐，记得保存');
    } catch (error) {
      toast.error((error as Error).message || 'AI 没有处理成功');
    } finally {
      setAssistBusy(null);
    }
  }

  const totalChars = Object.values(values).reduce((sum, value) => sum + value.length, 0);
  const filled = Object.values(values).filter((value) => value.trim()).length;
  const threadOpen = (values.foreshadowing.match(/^\s*[-*]\s*\[\s\]/gm) || []).length;
  const threadDone = (values.foreshadowing.match(/^\s*[-*]\s*\[[xX]\]/gm) || []).length;

  return (
    <div className="bible-page">
      <header className="bible-head">
        <div>
          <p className="section-kicker">作品设定</p>
          <h1>故事的后台。</h1>
          <p>这里不是给读者看的。每次生成，灯下都会把这份设定一起带进上下文。</p>
        </div>
        <div className="bible-head-actions">
          <span className={`bible-save ${saveState}`}>
            {saveState === 'saving' ? <Spinner size={13} /> : saveState === 'error' ? <AlertCircle size={13} /> : <Check size={13} />}
            {saveState === 'saving' ? '保存中' : saveState === 'error' ? '保存失败' : dirty ? '未保存' : '已保存'}
          </span>
          <button type="button" className="btn btn-ghost" onClick={() => setExtractOpen(true)}>
            <Wand2 size={15} />
            从正文提取
          </button>
        </div>
      </header>

      <div className="bible-overview">
        <span><strong>{filled}</strong> / 7 个部分有内容</span>
        <span><strong>{formatNumber(totalChars)}</strong> 字设定</span>
        {threadOpen > 0 && <span className="bible-thread-count"><strong>{threadOpen}</strong> 条未回收伏笔</span>}
        <span>上次保存 {timeAgo(savedRef.current)}</span>
      </div>

      <div className="bible-layout">
        <nav className="bible-tabs" aria-label="设定分类">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              className={active === tab.key ? 'active' : ''}
              onClick={() => setActive(tab.key)}
            >
              <span>{tab.label}</span>
              <em>{values[tab.key].trim() ? formatNumber(values[tab.key].length) : '空'}</em>
            </button>
          ))}
        </nav>

        <section className="bible-editor">
          <div className="bible-editor-head">
            <div>
              <h2>{current.label}</h2>
              <p>{current.hint}</p>
              {active === 'foreshadowing' && (
                <p className="bible-thread-count">未回收 {threadOpen} 条 · 已回收 {threadDone} 条</p>
              )}
            </div>
            <div className="bible-editor-actions">
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => { void assistField('polish'); }} disabled={Boolean(assistBusy)}>
                {assistBusy === 'polish' ? <Spinner size={13} /> : <Wand2 size={13} />}
                AI 润色
              </button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => { void assistField('fill'); }} disabled={Boolean(assistBusy)}>
                {assistBusy === 'fill' ? <Spinner size={13} /> : <Sparkles size={13} />}
                AI 补齐
              </button>
              {active === 'style' && (
                <>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={extractStyle} disabled={styleBusy}>
                    {styleBusy ? <Spinner size={13} /> : <Sparkles size={13} />}
                    从正文提取文风
                  </button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => { void saveStyleVersion(); }}>
                    存为版本
                  </button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => setStyleVersionsOpen(true)}>
                    版本
                  </button>
                </>
              )}
              <BookOpen size={18} />
            </div>
          </div>
          <textarea
            value={values[active]}
            onChange={(event) => change(active, event.target.value)}
            placeholder={current.placeholder}
            spellCheck={false}
            aria-label={`${current.label}设定`}
          />
          <footer className="bible-editor-foot">
            <span>{formatNumber(values[active].length)} 字</span>
            <span>自动保存 · 也会进入每一章的上下文</span>
          </footer>
        </section>
      </div>
      <StyleVersionsModal
        open={styleVersionsOpen}
        projectId={projectId}
        current={values.style}
        onClose={() => setStyleVersionsOpen(false)}
        onRestore={(content) => {
          setValues((currentValues) => ({ ...currentValues, style: content }));
          setActive('style');
          setDirty(true);
        }}
      />

      <ExtractModal
        open={extractOpen}
        onClose={() => setExtractOpen(false)}
        projectId={projectId}
        provider={provider}
        model={model}
        onOpenSettings={onOpenSettings}
        onCopied={() => toast.success('提取结果已复制，可以粘进对应分类')}
      />
    </div>
  );
}

function ExtractModal({
  open,
  onClose,
  projectId,
  provider,
  model,
  onOpenSettings,
  onCopied,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  provider: Provider | null;
  model: string;
  onOpenSettings: () => void;
  onCopied: () => void;
}) {
  const [output, setOutput] = useState('');
  const [meta, setMeta] = useState<AiMeta | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const controllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!open) {
      controllerRef.current?.abort();
      controllerRef.current = null;
      setBusy(false);
    }
  }, [open]);

  async function run() {
    if (!provider || !model) return;
    setBusy(true);
    setOutput('');
    setError('');
    setMeta(null);
    setCopied(false);
    const controller = new AbortController();
    controllerRef.current = controller;
    try {
      await streamExtract(
        { projectId, providerId: provider.id, model, contextChars: 30_000 },
        {
          onMeta: setMeta,
          onDelta: (delta) => setOutput((value) => value + delta.text),
        },
        controller.signal,
      );
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        setError(err instanceof ApiError ? err.message : (err as Error).message || '提取失败');
      }
    } finally {
      setBusy(false);
      controllerRef.current = null;
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
      onCopied();
    } catch {
      setError('浏览器没有允许复制，请手动选中');
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="从正文提取设定"
      description="让模型把已经写出来的事实整理成可合并的设定条目。它不会直接改你的设定库。"
      size="lg"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>{busy ? '停止并关闭' : '关闭'}</button>
          {output && !busy && (
            <button type="button" className="btn btn-primary" onClick={copy}>
              {copied ? <Check size={15} /> : <Copy size={15} />}
              {copied ? '已复制' : '复制结果'}
            </button>
          )}
          <button type="button" className="btn btn-lamp" onClick={run} disabled={busy || !provider || !model}>
            {busy ? <Spinner size={15} /> : <Sparkles size={15} />}
            {busy ? '正在读全书…' : output ? '重新提取' : '开始提取'}
          </button>
        </>
      }
    >
      {!provider ? (
        <div className="extract-empty">
          <BookOpen size={24} />
          <p>先接入一个模型，才能从正文里提取设定。</p>
          <button type="button" className="btn btn-primary" onClick={onOpenSettings}>去接入模型</button>
        </div>
      ) : (
        <>
          <p className="extract-note">
            将读取《{meta ? '当前作品' : '当前作品'}》已写正文，按世界、人物、时间线、伏笔和矛盾整理。内容较多时会按上下文预算截断。
          </p>
          {meta && <p className="extract-meta">{formatNumber(meta.stats.contextChars)} 字上下文 · {meta.model}</p>}
          {output ? (
            <div className="extract-output">{output}</div>
          ) : (
            <div className="extract-placeholder">
              <Download size={20} />
              <p>结果会显示在这里。复制后，按分类粘进左边的设定页。</p>
            </div>
          )}
          {busy && <div className="extract-progress"><span /></div>}
          {error && <p className="form-error">{error}</p>}
        </>
      )}
    </Modal>
  );
}
