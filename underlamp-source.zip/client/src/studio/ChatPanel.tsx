import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { AlertCircle, Check, MessageCircle, Send, Sparkles, Square, Trash2 } from 'lucide-react';
import { ApiError, streamAi } from '../api';
import { useToast } from '../context/ToastContext';
import { formatNumber, isMac } from '../lib/format';
import type { Provider, Skill } from '../types';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  error?: boolean;
}

const prompts = [
  '这一章最该保住的是什么？',
  '主角现在的选择不够疼，帮我想三个更狠的。',
  '下一章如果要从雨天开始，怎么接才不闷？',
  '我卡在第二幕了，帮我找出真正的问题。',
];

export function ChatPanel({
  projectId,
  providers,
  providerId,
  model,
  onProviderChange,
  onModelChange,
  skills,
  selectedSkillIds,
  onSelectedSkillIdsChange,
  onOpenSettings,
}: {
  projectId: string;
  providers: Provider[];
  providerId: string;
  model: string;
  onProviderChange: (id: string) => void;
  onModelChange: (model: string) => void;
  skills: Skill[];
  selectedSkillIds: string[];
  onSelectedSkillIdsChange: (ids: string[]) => void;
  onOpenSettings: () => void;
}) {
  const toast = useToast();
  const storageKey = `underlamp.chat.${projectId}`;
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed.slice(-30) : [];
    } catch {
      return [];
    }
  });
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [skillsOpen, setSkillsOpen] = useState(false);
  const [error, setError] = useState('');
  const controllerRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const provider = providers.find((item) => item.id === providerId) || null;
  const selectedSkills = skills.filter((skill) => selectedSkillIds.includes(skill.id));
  const shortcut = isMac() ? '⌘↵' : 'Ctrl ↵';

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(messages.slice(-30)));
    } catch {
      /* ignore */
    }
  }, [messages, storageKey]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }, [input]);

  useEffect(() => {
    return () => controllerRef.current?.abort();
  }, []);

  const contextNote = useMemo(
    () => `作品设定 · 前情摘要 · ${selectedSkills.length} 件工具`,
    [selectedSkills.length],
  );

  async function send(textOverride?: string) {
    const text = (textOverride ?? input).trim();
    if (!text || streaming) return;
    if (!provider || !model) {
      toast.error('先在设置里接入一个模型');
      return;
    }
    setError('');
    setInput('');
    const prior = messages;
    const userMessage: ChatMessage = { id: crypto.randomUUID(), role: 'user', content: text };
    const assistantId = crypto.randomUUID();
    setMessages([...prior, userMessage, { id: assistantId, role: 'assistant', content: '' }]);
    setStreaming(true);
    const controller = new AbortController();
    controllerRef.current = controller;
    try {
      await streamAi(
        {
          providerId: provider.id,
          model,
          action: 'chat',
          projectId,
          chapterId: null,
          instruction: text,
          history: prior.map((message) => ({ role: message.role, content: message.content })),
          skillIds: selectedSkillIds,
          contextChars: 48_000,
        },
        {
          onDelta: (delta) => {
            if (!delta.text) return;
            setMessages((current) =>
              current.map((message) =>
                message.id === assistantId ? { ...message, content: message.content + delta.text } : message,
              ),
            );
          },
        },
        controller.signal,
      );
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        toast.info('已经停下');
      } else {
        const message = err instanceof ApiError ? err.message : (err as Error).message || '对谈中断了';
        setError(message);
        setMessages((current) => current.map((item) => (item.id === assistantId ? { ...item, error: true } : item)));
      }
    } finally {
      setStreaming(false);
      controllerRef.current = null;
    }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void send();
  }

  function toggleSkill(id: string) {
    if (selectedSkillIds.includes(id)) onSelectedSkillIdsChange(selectedSkillIds.filter((item) => item !== id));
    else onSelectedSkillIdsChange([...selectedSkillIds, id]);
  }

  function clear() {
    controllerRef.current?.abort();
    setMessages([]);
    setError('');
    toast.info('对谈已清空');
  }

  return (
    <div className="chat-page">
      <header className="chat-head">
        <div>
          <p className="section-kicker">和灯下聊聊</p>
          <h1>把卡住的地方说出来。</h1>
        </div>
        <div className="chat-head-actions">
          {provider ? (
            <>
              <label className="chat-model">
                <span>服务</span>
                <select value={providerId} onChange={(event) => onProviderChange(event.target.value)}>
                  {providers.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
                </select>
              </label>
              <label className="chat-model">
                <span>模型</span>
                <select value={model} onChange={(event) => onModelChange(event.target.value)}>
                  {provider.models.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
                </select>
              </label>
            </>
          ) : (
            <button type="button" className="btn btn-primary" onClick={onOpenSettings}>接入模型</button>
          )}
          {messages.length > 0 && (
            <button type="button" className="icon-button" onClick={clear} aria-label="清空对谈" title="清空对谈">
              <Trash2 size={16} />
            </button>
          )}
        </div>
      </header>

      <div className="chat-context">
        <span><MessageCircle size={13} /> {contextNote}</span>
        <button type="button" className={`chat-skills-button ${skillsOpen ? 'open' : ''}`} onClick={() => setSkillsOpen((value) => !value)}>
          <Sparkles size={13} />
          调整技能
        </button>
        {skillsOpen && (
          <div className="chat-skill-pop">
            {skills.filter((skill) => skill.enabled).map((skill) => (
              <label key={skill.id}>
                <input type="checkbox" checked={selectedSkillIds.includes(skill.id)} onChange={() => toggleSkill(skill.id)} />
                <span>{skill.name}</span>
                {selectedSkillIds.includes(skill.id) && <Check size={12} />}
              </label>
            ))}
          </div>
        )}
      </div>

      <div className="chat-scroll" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="chat-empty">
            <span className="chat-empty-mark" aria-hidden="true" />
            <h2>这里不写正文，只把问题想清楚。</h2>
            <p>灯下知道这本书的设定、前情和人物。你可以从一句话开始，不必组织好。</p>
            <div className="chat-prompts">
              {prompts.map((prompt) => (
                <button key={prompt} type="button" onClick={() => send(prompt)} disabled={!provider}>
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="chat-transcript">
            {messages.map((message) => (
              <article key={message.id} className={`chat-message ${message.role} ${message.error ? 'has-error' : ''}`}>
                <span className="chat-role">
                  {message.role === 'assistant' ? <span className="chat-lamp" aria-hidden="true" /> : '你'}
                </span>
                <div className="chat-content">
                  {message.content || (streaming && message.role === 'assistant' ? <span className="typing-dots" aria-label="正在输入"><i /><i /><i /></span> : null)}
                  {message.error && <p className="chat-error"><AlertCircle size={13} /> 这段没有写完，可以重发。</p>}
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      <div className="chat-composer-wrap">
        <form className="chat-composer" onSubmit={submit}>
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
                event.preventDefault();
                void send();
              }
            }}
            placeholder="比如：第二章结尾主角没有推门，会不会显得太被动？"
            rows={1}
            disabled={streaming}
            aria-label="对谈内容"
          />
          <div className="chat-composer-foot">
            <span>{shortcut} 发送 · 只留在这台浏览器</span>
            {streaming ? (
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => controllerRef.current?.abort()}>
                <Square size={13} />
                停
              </button>
            ) : (
              <button type="submit" className="btn btn-ink btn-sm" disabled={!input.trim() || !provider}>
                <Send size={14} />
                发过去
              </button>
            )}
          </div>
        </form>
        {error && <p className="chat-composer-error">{error}</p>}
      </div>
    </div>
  );
}
