import { useEffect, useMemo, useState } from 'react';
import { Activity, Pencil, Trash2 } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { formatNumber, timeAgo } from '../lib/format';
import { downloadBlob, downloadText } from '../local/export';
import { deleteMany, getAllByIndex, put, remove } from '../local/db';
import { buildProjectReport, type MentionMap, type ProjectReport } from '../local/report';
import type { Bible, ChapterMeta, CodexEntry, DeletedSnapshot, ReportSnapshot, TimelineEvent } from '../types';

const kindLabel: Record<string, string> = {
  character: '人物',
  location: '地点',
  faction: '势力',
  item: '物品',
  concept: '设定',
};

export function ProjectReportModal({
  open,
  onClose,
  projectId,
  bible,
  chapters,
  codex,
  timeline,
  mentions,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  bible: Bible;
  chapters: ChapterMeta[];
  codex: CodexEntry[];
  timeline: TimelineEvent[];
  mentions: MentionMap;
}) {
  const toast = useToast();
  const [report, setReport] = useState<ProjectReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [snapshots, setSnapshots] = useState<ReportSnapshot[]>([]);
  const [baseline, setBaseline] = useState<ReportSnapshot | null>(null);
  const [saving, setSaving] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletedStack, setDeletedStack] = useState<ReportSnapshot[]>([]);
  const [chapterTexts, setChapterTexts] = useState<Array<{ title: string; content: string }>>([]);

  async function loadSnapshots() {
    const data = await api.get<{ snapshots: ReportSnapshot[] }>(`/api/projects/${projectId}/report-snapshots`).catch(() => ({ snapshots: [] }));
    setSnapshots(data.snapshots);
    setBaseline((current) => current || data.snapshots[0] || null);
  }

  async function loadUndo() {
    const rows = await getAllByIndex<DeletedSnapshot>('reportUndo', 'projectId', projectId).catch(() => []);
    setDeletedStack(rows.sort((a, b) => a.deletedAt - b.deletedAt).slice(-5).map((row) => row.snapshot));
  }

  async function clearUndo() {
    const rows = await getAllByIndex<DeletedSnapshot>('reportUndo', 'projectId', projectId).catch(() => []);
    if (rows.length) await deleteMany('reportUndo', rows.map((row) => row.id));
    setDeletedStack([]);
  }

  async function saveSnapshot() {
    if (!report) return;
    setSaving(true);
    try {
      await api.post(`/api/projects/${projectId}/report-snapshots`, { report });
      await loadSnapshots();
      toast.success('这次体检已存为快照');
    } catch (error) {
      toast.error((error as Error).message || '快照没有存下来');
    } finally {
      setSaving(false);
    }
  }

  async function renameSnapshot(snapshot: ReportSnapshot) {
    try {
      const data = await api.patch<{ snapshot: ReportSnapshot }>(`/api/report-snapshots/${snapshot.id}`, { name: renameValue.trim() });
      setSnapshots((current) => current.map((item) => (item.id === snapshot.id ? data.snapshot : item)));
      setBaseline((current) => (current?.id === snapshot.id ? data.snapshot : current));
      setRenamingId(null);
      setRenameValue('');
    } catch (error) {
      toast.error((error as Error).message || '没有改名');
    }
  }

  async function deleteSnapshot(snapshot: ReportSnapshot) {
    try {
      await api.delete(`/api/report-snapshots/${snapshot.id}`);
      await put<DeletedSnapshot>('reportUndo', { id: snapshot.id, projectId, snapshot, deletedAt: Date.now() });
      const undoRows = await getAllByIndex<DeletedSnapshot>('reportUndo', 'projectId', projectId).catch(() => []);
      if (undoRows.length > 5) {
        await deleteMany('reportUndo', undoRows.sort((a, b) => a.deletedAt - b.deletedAt).slice(0, undoRows.length - 5).map((row) => row.id));
      }
      setDeletedStack((current) => [...current, snapshot].slice(-5));
      setSnapshots((current) => current.filter((item) => item.id !== snapshot.id));
      setBaseline((current) => (current?.id === snapshot.id ? null : current));
      setDeletingId(null);
      toast.success('快照已删除，可以撤销');
    } catch (error) {
      toast.error((error as Error).message || '没有删除');
    }
  }

  async function undoDelete() {
    const lastDeleted = deletedStack[deletedStack.length - 1];
    if (!lastDeleted) return;
    try {
      await api.post(`/api/projects/${projectId}/report-snapshots`, {
        name: lastDeleted.name || '',
        report: lastDeleted.report,
      });
      await remove('reportUndo', lastDeleted.id);
      setDeletedStack((current) => current.slice(0, -1));
      await loadSnapshots();
      toast.success('快照已恢复');
    } catch (error) {
      toast.error((error as Error).message || '没有恢复');
    }
  }

  async function exportReport(withText = false) {
    if (!report) return;
    const payload = {
      format: 'underlamp-report',
      version: 2,
      generatedAt: new Date().toISOString(),
      projectId,
      baseline: base && baseline ? { name: baseline.name || '', createdAt: baseline.createdAt, report: base } : null,
      current: report,
      ...(withText ? { chapterTexts } : {}),
    };
    const text = JSON.stringify(payload, null, 2);
    const stamp = new Date().toISOString().slice(0, 10);
    if (withText && typeof CompressionStream !== 'undefined') {
      const blob = await new Response(new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'))).blob();
      downloadBlob(`全书体检-含正文-${stamp}.json.gz`, blob);
      return;
    }
    downloadText(
      `全书体检${withText ? '-含正文' : ''}-${stamp}.json`,
      text,
      'application/json;charset=utf-8',
    );
  }

  useEffect(() => {
    if (!open) return;
    let alive = true;
    setLoading(true);
    void loadSnapshots();
    void loadUndo();
    Promise.all(
      chapters.map((chapter) =>
        api.get<{ chapter: { content: string } }>(`/api/chapters/${chapter.id}`)
          .then((data) => ({ ...chapter, content: data.chapter.content }))
          .catch(() => ({ ...chapter, content: '' })),
      ),
    )
      .then((full) => {
        if (alive) {
          setReport(buildProjectReport({ bible, chapters: full, codex, timeline, mentions }));
          setChapterTexts(full.filter((chapter) => chapter.content.trim()).map((chapter) => ({ title: chapter.title, content: chapter.content })));
        }
      })
      .catch((error) => {
        if (alive) toast.error((error as Error).message || '体检没有跑完');
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => { alive = false; };
  }, [open, projectId, bible, chapters, codex, timeline, mentions, toast]);

  const maxWords = useMemo(() => Math.max(1, ...(report?.chapters.map((chapter) => chapter.words) || [1])), [report]);
  const base = baseline?.report as ProjectReport | undefined;
  const lastUndo = deletedStack[deletedStack.length - 1];
  const delta = (current: number, previous?: number) => {
    if (previous === undefined) return '';
    const value = Math.round(current - previous);
    return value === 0 ? '持平' : `${value > 0 ? '+' : ''}${value}`;
  };
  const chapterDeltas = useMemo(() => {
    if (!report || !base) return [];
    const previous = new Map((base.chapters || []).map((chapter: any) => [chapter.id, chapter.words]));
    return report.chapters
      .map((chapter) => ({
        id: chapter.id,
        title: chapter.title,
        delta: chapter.words - (previous.get(chapter.id) || 0),
        current: chapter.words,
      }))
      .filter((chapter) => chapter.delta !== 0)
      .sort((a, b) => b.delta - a.delta);
  }, [report, base]);

  const allChapterDeltas = useMemo(() => {
    if (!report || !base) return [];
    const previous = new Map((base.chapters || []).map((chapter: any) => [chapter.id, chapter.words]));
    return report.chapters.map((chapter) => {
      const oldWords = previous.get(chapter.id) || 0;
      return {
        id: chapter.id,
        title: chapter.title,
        previous: oldWords,
        current: chapter.words,
        delta: chapter.words - oldWords,
        rate: oldWords > 0 ? (chapter.words - oldWords) / oldWords : null,
      };
    });
  }, [report, base]);

  function exportDeltaCsv() {
    if (!allChapterDeltas.length) return;
    const csv = [
      ['章节', '快照字数', '当前字数', '差值', '变化率'].join(','),
      ...allChapterDeltas.map((row) => [
        `"${row.title.replace(/"/g, '""')}"`,
        row.previous,
        row.current,
        row.delta,
        row.rate === null ? '' : `${(row.rate * 100).toFixed(1)}%`,
      ].join(',')),
    ].join('\n');
    downloadText(`体检对比-${new Date().toISOString().slice(0, 10)}.csv`, `\ufeff${csv}`, 'text/csv;charset=utf-8');
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="全书体检"
      description="只做可验证的统计，不假装判断文学质量。用来看字数、对话、重复、Codex 覆盖和伏笔。"
      size="xl"
      footer={<>
        <span className="modal-foot-spacer" />
        <button type="button" className="btn btn-ghost" onClick={() => { void exportReport(false); }} disabled={!report}>导出报告</button>
        <button type="button" className="btn btn-ghost" onClick={() => { void exportReport(true); }} disabled={!report}>导出含正文</button>
        <button type="button" className="btn btn-ghost" onClick={onClose}>关闭</button>
        <button type="button" className="btn btn-primary" onClick={() => { void saveSnapshot(); }} disabled={saving || !report}>
          {saving ? <Spinner size={14} /> : null}
          存为快照
        </button>
      </>}
    >
      {loading ? (
        <div className="codex-loading"><Spinner size={18} /> 正在把整本书摊开</div>
      ) : !report ? (
        <p className="form-hint">还没有可体检的内容。</p>
      ) : (
        <div className="report">
          <div className="report-stats">
            <div><strong>{formatNumber(report.totalWords)}</strong><span>总字数</span></div>
            <div><strong>{report.chapters.length}</strong><span>章</span></div>
            <div><strong>{formatNumber(report.averageWords)}</strong><span>平均章字数</span></div>
            <div><strong>{Math.round(report.dialogueRatio * 100)}%</strong><span>对话占比</span></div>
            <div><strong>{report.codexSeen}/{report.codexTotal}</strong><span>Codex 有出场</span></div>
            <div><strong>{report.openThreads}</strong><span>未回收伏笔</span></div>
            <div><strong>{report.timelineCount}</strong><span>时间线事件</span></div>
            <div><strong>{report.styleReady ? '有' : '无'}</strong><span>文风卡</span></div>
          </div>

          <section className="report-section">
            <div className="report-section-head">
              <h3>章节字数曲线</h3>
              <span>最短 {report.shortest?.title || '—'} · 最长 {report.longest?.title || '—'}</span>
            </div>
            <div className="report-bars" aria-hidden="true">
              {report.chapters.map((chapter) => (
                <span key={chapter.id} title={`${chapter.title} · ${formatNumber(chapter.words)} 字`}>
                  <i style={{ height: `${Math.max(3, Math.round((chapter.words / maxWords) * 100))}%` }} />
                  <em>{chapter.title.replace(/^第.+?章\s*/, '').slice(0, 4)}</em>
                </span>
              ))}
            </div>
          </section>

          <div className="report-columns">
            <section className="report-section">
              <div className="report-section-head"><h3>重复四字片段</h3><span>出现 ≥4 次且跨章</span></div>
              {report.repeated.length ? (
                <div className="report-phrases">
                  {report.repeated.map((item) => (
                    <span key={item.phrase}>{item.phrase}<em>{item.count} 次 / {item.chapters} 章</em></span>
                  ))}
                </div>
              ) : <p className="report-muted">没有明显的跨章重复四字片段。</p>}
            </section>
            <section className="report-section">
              <div className="report-section-head"><h3>人物没出场</h3><span>Codex 人物、零次提及</span></div>
              {report.neverSeen.length ? (
                <div className="report-never">
                  {report.neverSeen.map((entry) => <span key={entry.id}>{entry.name}<em>{kindLabel[entry.kind] || '人物'}</em></span>)}
                </div>
              ) : <p className="report-muted">所有人物条目都至少被提到一次。</p>}
            </section>
          </div>

          <section className="report-section report-history">
            <div className="report-section-head">
              <h3>体检快照</h3>
              <span>{snapshots.length ? '点一个作为对比基线' : '还没有快照'}</span>
            </div>
            {lastUndo && (
              <div className="report-undo">
                <span>已删除「{lastUndo.name || timeAgo(lastUndo.createdAt)}」{deletedStack.length > 1 ? `，还可撤销 ${deletedStack.length} 张` : ''}</span>
                <button type="button" onClick={() => { void undoDelete(); }}>撤销</button>
                <button type="button" onClick={() => { void clearUndo(); }}>不再提示</button>
              </div>
            )}
            {snapshots.length ? (
              <>
                <div className="report-snapshots">
                  {snapshots.map((snapshot) => (
                    <div key={snapshot.id} className={`report-snapshot-row ${baseline?.id === snapshot.id ? 'active' : ''}`}>
                      {renamingId === snapshot.id ? (
                        <div className="report-snapshot-rename">
                          <input
                            value={renameValue}
                            onChange={(event) => setRenameValue(event.target.value)}
                            maxLength={80}
                            autoFocus
                            placeholder="快照名称"
                            onKeyDown={(event) => {
                              if (event.key === 'Enter') { event.preventDefault(); void renameSnapshot(snapshot); }
                              if (event.key === 'Escape') { setRenamingId(null); setRenameValue(''); }
                            }}
                          />
                          <button type="button" className="btn btn-primary btn-sm" onClick={() => { void renameSnapshot(snapshot); }}>保存</button>
                          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setRenamingId(null); setRenameValue(''); }}>取消</button>
                        </div>
                      ) : (
                        <button type="button" className="report-snapshot-pick" onClick={() => setBaseline(snapshot)}>
                          <strong>{snapshot.name || timeAgo(snapshot.createdAt)}</strong>
                          <span>{formatNumber(snapshot.report?.totalWords || 0)} 字 · {snapshot.report?.chapters?.length || 0} 章</span>
                        </button>
                      )}
                      <button type="button" className="report-snapshot-act" onClick={() => { setRenamingId(snapshot.id); setRenameValue(snapshot.name || ''); }} aria-label="重命名快照"><Pencil size={11} /></button>
                      {deletingId === snapshot.id ? (
                        <span className="report-delete-confirm">
                          <button type="button" onClick={() => { void deleteSnapshot(snapshot); }}>确认删除</button>
                          <button type="button" onClick={() => setDeletingId(null)}>取消</button>
                        </span>
                      ) : (
                        <button type="button" className="report-snapshot-act" onClick={() => setDeletingId(snapshot.id)} aria-label="删除快照"><Trash2 size={11} /></button>
                      )}
                    </div>
                  ))}
                </div>
                {base && (
                  <>
                  <div className="report-deltas">
                    <span>对比：总字数 <em>{delta(report.totalWords, base.totalWords)}</em></span>
                    <span>平均章字数 <em>{delta(report.averageWords, base.averageWords)}</em></span>
                    <span>对话占比 <em>{delta(report.dialogueRatio * 100, base.dialogueRatio * 100)}pp</em></span>
                    <span>Codex出场 <em>{delta(report.codexSeen, base.codexSeen)}</em></span>
                    <span>未回收伏笔 <em>{delta(report.openThreads, base.openThreads)}</em></span>
                  </div>
                  <div className="report-compare">
                    <div className="report-compare-head"><span>逐章字数：旧 / 新</span><span>灰 = 快照 · 金 = 当前</span></div>
                    <div className="report-compare-bars">
                      {report.chapters.map((chapter) => {
                        const previous = (base.chapters || []).find((item: any) => item.id === chapter.id)?.words || 0;
                        const max = Math.max(1, previous, chapter.words);
                        return (
                          <span key={chapter.id} title={`${chapter.title}：${previous} → ${chapter.words} 字`}>
                            <i className="old" style={{ height: `${Math.max(2, Math.round((previous / max) * 70))}%` }} />
                            <i className="new" style={{ height: `${Math.max(2, Math.round((chapter.words / max) * 70))}%` }} />
                            <em>{chapter.title.replace(/^第.+?章\s*/, '').slice(0, 4)}</em>
                          </span>
                        );
                      })}
                    </div>
                  </div>
                  <div className="report-delta-ranking">
                    <div className="report-delta-column">
                      <h4>涨得最多</h4>
                      {chapterDeltas.filter((item) => item.delta > 0).slice(0, 3).map((item) => (
                        <span key={item.id}>{item.title}<em>+{formatNumber(item.delta)}</em></span>
                      ))}
                      {!chapterDeltas.some((item) => item.delta > 0) && <p>没有增长章节。</p>}
                    </div>
                    <div className="report-delta-column">
                      <h4>缩得最多</h4>
                      {chapterDeltas.filter((item) => item.delta < 0).slice(-3).reverse().map((item) => (
                        <span key={item.id}>{item.title}<em>{formatNumber(item.delta)}</em></span>
                      ))}
                      {!chapterDeltas.some((item) => item.delta < 0) && <p>没有缩水章节。</p>}
                    </div>
                  </div>
                  <details className="report-all-delta">
                    <summary>完整逐章变化（{allChapterDeltas.length} 章）</summary>
                    <div className="report-all-head">
                      <span>按当前章节顺序</span>
                      <button type="button" className="btn btn-ghost btn-sm" onClick={exportDeltaCsv}>导出 CSV</button>
                    </div>
                    <div className="report-all-table">
                      <div className="report-all-row head"><span>章节</span><span>快照</span><span>当前</span><span>差值</span></div>
                      {allChapterDeltas.map((row) => (
                        <div key={row.id} className="report-all-row">
                          <span>{row.title}</span>
                          <span>{formatNumber(row.previous)}</span>
                          <span>{formatNumber(row.current)}</span>
                          <em className={row.delta > 0 ? 'up' : row.delta < 0 ? 'down' : ''}>
                            {row.delta > 0 ? '+' : ''}{formatNumber(row.delta)}
                          </em>
                        </div>
                      ))}
                    </div>
                  </details>
                  </>
                )}
              </>
            ) : (
              <p className="report-muted">这次体检可以存成第一张快照；下次再体检就能对比。</p>
            )}
          </section>

          <p className="report-note">
            <Activity size={13} /> 对话占比按引号内字符粗略统计；重复片段是字面匹配，不代表文风差。所有指标都只是线索，不是判决。
          </p>
        </div>
      )}
    </Modal>
  );
}
