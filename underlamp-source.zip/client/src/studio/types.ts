export interface Draft {
  title: string;
  content: string;
  summary: string;
  beats: string;
  targetWords: number;
  status: 'draft' | 'final' | 'outline';
}

export interface TextSelection {
  start: number;
  end: number;
  text: string;
}

export type SaveState = 'saved' | 'dirty' | 'saving' | 'error';
