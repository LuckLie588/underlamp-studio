import { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDown,
  Check,
  Copy,
  Eye,
  Feather,
  FileText,
  Lightbulb,
  List,
  Maximize2,
  Minimize2,
  Play,
  RefreshCw,
  ScanSearch,
  Settings,
  Sparkles,
  Square,
  Stethoscope,
  Tag,
  Wand2,
  X,
} from 'lucide-react';
import { ApiError, streamAi } from '../api';
import { useToast } from '../context/ToastContext';
import { actionLabel, formatChars, formatNumber, isMac } from '../lib/format';
import type { AiDone, AiMeta, Provider, Skill } from '../types';
import { ContextModal } from './ContextModal';
import { DiffModal } from './DiffModal';
import type { TextSelection } from './types';

const actions = [
  { id: 'continue', label: '续写', icon: Feather },
  { id: 'polish', label: '润色', icon: Wand2 },
  { id: 'expand', label: '扩写', icon: Maximize2 },
  { id: 'condense', label: '收紧', icon: Minimize2 },
  { id: 'rewrite', label: '改写', icon: RefreshCw },
  { id: 'outline', label: '拆章', icon: List },
  { id: 'continuity', label: '连贯', icon: ScanSearch },
  { id: 'diagnose', label: '体检', icon: Stethoscope },
  { id: 'title', label: '起名', icon: Tag },
  { id: 'brainstorm', label: '走向', icon: Lightbulb },
  { id: 'summarize', label: '摘要', icon: FileText },
] as const;

type ActionId = (typeof actions)[number]['id'];

function aiErrorHint(message: string) {
  const text = String(message || '');
  if (/model names|model.*not|模型.*(不存在|不支持)|400/i.test(text)) {
    return '模型 ID 与服务商支持的不一致。DeepSeek 官方请填 deepseek-flash 或 deepseek-v4-pro；到设置里改完再试。';
  }
  if (/401|403|Key|权限|unauthorized|forbidden/i.test(text)) {
    return 'Key 被拒绝：检查 Key 是否有效、是否激活、是否有该模型权限。';
  }
  if (/404|Base URL|接口或模型/i.test(text)) {
    return '地址或模型不对：OpenAI 兼容通常以 /v1 结尾；Anthropic 填根地址；模型 ID 按服务商文档。';
  }
  if (/429|限流|余额|quota/i.test(text)) {
    return '被限流或余额不足。等一会儿，或去服务商后台看余额与并发。';
  }
  if (/超时|中断|network|fetch|连接|502|503|504/i.test(text)) {
    return '网络或代理中断。先点一次测试；公网部署时检查 Render 日志和 SSE 缓冲。';
  }
  return '先到“设置 → 模型服务”点“测试”，确认地址、模型 ID 和 Key 都能通过，再回来生成。';
}

const placeholders: Record<ActionId, string> = {
  continue: '接下来想往哪儿写？可以留空。',
  polish: '想特别留意什么？比如：去掉解释，句子再短一点。',
  expand: '想放大哪个部分？动作、环境，还是人物反应？',
  condense: '哪里觉得拖？可以指定段落或节奏。',
  rewrite: '想换成什么叙述方式或语气？',
  outline: '下一章想完成什么？可以只写一个念头。',
  continuity: '可以留空，也可以指定重点：时间线、人物知识、物件或伏笔。',
  diagnose: '可以留空，也可以指定重点：AI 腔、节奏、对话、章末钩子。',
  title: '这本书或这一章的气质是什么？',
  brainstorm: '卡在什么地方？想要更狠、更暖，还是更意外？',
  summarize: '可以留空。摘要会写成 150–260 字。',
};

export function AiPanel({
  open,
  onClose,
  projectId,
  chapterId,
  chapterTitle,
  providers,
  providerId,
  model,
  onProviderChange,
  onModelChange,
  skills,
  selectedSkillIds,
  onSelectedSkillIdsChange,
  selection,
  onApply,
  onSaveSummary,
  onSaveBeats,
  onOpenSettings,
  request,
  onBeforeContext,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  chapterId: string | null;
  chapterTitle: string;
  providers: Provider[];
  providerId: string;
  model: string;
  onProviderChange: (id: string) => void;
  onModelChange: (model: string) => void;
  skills: Skill[];
  selectedSkillIds: string[];
  onSelectedSkillIdsChange: (ids: string[]) => void;
  selection: TextSelection;
  onApply: (text: string, mode: 'insert' | 'replace' | 'append') => void;
  onSaveSummary: (text: string) => void;
  onSaveBeats: (text: string) => void;
  onOpenSettings: () => void;
  request?: { action: string; instruction: string; token: number } | null;
  onBeforeContext?: () => Promise<unknown>;
}) {
  const toast = useToast();
  const [action, setAction] = useState<ActionId>('continue');
  const [instruction, setInstruction] = useState('');
  const [output, setOutput] = useState('');
  const [reasoning, setReasoning] = useState('');
  const [meta, setMeta] = useState<AiMeta | null>(null);
  const [done, setDone] = useState<AiDone | null>(null);
  const [error, setError] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [runAction, setRunAction] = useState<ActionId>('continue');
  const [runChapterId, setRunChapterId] = useState<string | null>(null);
  const [runChapterTitle, setRunChapterTitle] = useState('');
  const [skillsOpen, setSkillsOpen] = useState(false);
  const [contextOpen, setContextOpen] = useState(false);
  const [diffOpen, setDiffOpen] = useState(false);
  const [contextChars, setContextChars] = useState(48_000);
  const [copied, setCopied] = useState(false);
  const controllerRef = useRef<AbortController | null>(null);
  const generateRef = useRef<() => void>(() => undefined);

  const provider = providers.find((item) => item.id === providerId) || null;
  const selectedSkills = skills.filter((skill) => selectedSkillIds.includes(skill.id) && skill.enabled);
  const selectedChars = selectedSkills.reduce((sum, skill) => sum + skill.chars, 0);
  const canGenerate = Boolean(provider && model && !streaming && (action !== 'summarize' || chapterId));
  const shortcut = isMac() ? '⌘↵' : 'Ctrl ↵';

  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
        event.preventDefault();
        generateRef.current();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open]);

  useEffect(() => {
    if (!request) return;
    setAction(request.action as ActionId);
    setInstruction(request.instruction || '');
    setOutput('');
    setReasoning('');
    setError('');
    setMeta(null);
    setDone(null);
  }, [request?.token]);

  useEffect(() => {
    return () => controllerRef.current?.abort();
  }, []);

  function toggleSkill(id: string) {
    if (selectedSkillIds.includes(id)) onSelectedSkillIdsChange(selectedSkillIds.filter((item) => item !== id));
    else onSelectedSkillIdsChange([...selectedSkillIds, id]);
  }

  function stop() {
    controllerRef.current?.abort();
  }

  async function generate() {
    if (!provider || !model) {
      toast.error('先在设置里接入一个模型');
      return;
    }
    if (streaming) return;
    if (action === 'summarize' && !chapterId) {
      toast.error('先打开一个章节，再写摘要');
      return;
    }
    setStreaming(true);
    setError('');
    setOutput('');
    setReasoning('');
    setMeta(null);
    setDone(null);
    setCopied(false);
    setRunAction(action);
    setRunChapterId(chapterId);
    setRunChapterTitle(chapterTitle);
    const controller = new AbortController();
    controllerRef.current = controller;
    const usesSelection = ['polish', 'expand', 'condense', 'rewrite'].includes(action);
    try {
      await streamAi(
        {
          providerId: provider.id,
          model,
          action,
          projectId,
          chapterId,
          instruction: instruction.trim(),
          selection: usesSelection ? selection.text : '',
          skillIds: selectedSkills.map((skill) => skill.id),
          contextChars,
        },
        {
          onMeta: (value) => setMeta(value),
          onDelta: (delta) => {
            if (delta.text) setOutput((current) => current + delta.text);
            if (delta.reasoning) setReasoning((current) => current + delta.reasoning);
          },
          onDone: (value) => setDone(value),
        },
        controller.signal,
      );
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        toast.info('已经停下');
      } else {
        const message = err instanceof ApiError ? err.message : (err as Error).message || '生成中断了';
        setError(message);
      }
    } finally {
      setStreaming(false);
      controllerRef.current = null;
    }
  }
  generateRef.current = generate;

  async function copy() {
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
      toast.success('已复制');
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error('浏览器没有允许复制，请手动选中');
    }
  }

  const hasOutput = Boolean(output || reasoning);
  const isProse = ['continue', 'polish', 'expand', 'condense', 'rewrite'].includes(runAction);
  const usesSelection = ['polish', 'expand', 'condense', 'rewrite'].includes(action);
  const resultIsStaleChapter = Boolean(runChapterId && chapterId !== runChapterId);
  const canReplace = isProse && !resultIsStaleChapter && selection.text.trim().length > 0;
  const contextLabel = contextChars >= 90_000 ? '深读' : contextChars >= 40_000 ? '标准' : '精简';

  return (
    <aside className={`ai-panel ${open ? 'is-open' : ''}`} aria-label="灯下 AI 写作面板">
      <header className="ai-head">
        <div className="ai-title">
          <span className="ai-lamp" aria-hidden="true" />
          <div>
            <strong>灯下</strong>
            <span>{streaming ? '正在写' : hasOutput ? '写完了' : '待命'}</span>
          </div>
        </div>
        <button type="button" className="icon-button ai-close" onClick={onClose} aria-label="收起灯下面板">
          <X size={17} />
        </button>
      </header>

      {!provider ? (
        <div className="ai-setup">
          <span className="ai-setup-icon"><Settings size={22} /></span>
          <h3>灯下还没有笔</h3>
          <p>接入 DeepSeek、Claude、Gemini，或任何 OpenAI 兼容服务。Key 只存在这台浏览器里。</p>
          <button type="button" className="btn btn-lamp" onClick={onOpenSettings}>
            去接入模型
          </button>
        </div>
      ) : (
        <>
          <div className="ai-model-row">
            <label>
              <span>模型服务</span>
              <select value={providerId} onChange={(event) => onProviderChange(event.target.value)}>
                {providers.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
              </select>
            </label>
            <label>
              <span>模型</span>
              <select value={model} onChange={(event) => onModelChange(event.target.value)}>
                {provider.models.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
              </select>
            </label>
          </div>

          <div className="ai-scroll">
            <div className="ai-section">
              <div className="ai-section-head">
                <span>做什么</span>
                <span className="ai-shortcut">{shortcut} 生成</span>
              </div>
              <div className="ai-actions">
                {actions.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    type="button"
                    className={`ai-action ${action === id ? 'active' : ''}`}
                    onClick={() => setAction(id)}
                  >
                    <Icon size={14} />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div className="ai-section">
              <button type="button" className={`ai-skills-trigger ${skillsOpen ? 'open' : ''}`} onClick={() => setSkillsOpen((value) => !value)}>
                <span>
                  <Sparkles size={14} />
                  装载技能
                  <em>{selectedSkills.length} 件 · {formatChars(selectedChars)}</em>
                </span>
                <span className="ai-skills-toggle">{skillsOpen ? '收起' : '挑选'}</span>
              </button>
              {skillsOpen && (
                <div className="ai-skill-picker">
                  {(['skill', 'reference'] as const).map((kind) => {
                    const items = skills.filter((skill) => skill.kind === kind && skill.enabled);
                    if (!items.length) return null;
                    return (
                      <div className="ai-skill-group" key={kind}>
                        <span className="ai-skill-group-label">{kind === 'skill' ? '技能 · 工艺要求' : '资料 · 事实与语感'}</span>
                        {items.map((skill) => (
                          <label className={`ai-skill-item ${selectedSkillIds.includes(skill.id) ? 'selected' : ''}`} key={skill.id}>
                            <input
                              type="checkbox"
                              checked={selectedSkillIds.includes(skill.id)}
                              onChange={() => toggleSkill(skill.id)}
                            />
                            <span>
                              <strong>{skill.name}</strong>
                              <small>{formatNumber(skill.chars)} 字</small>
                            </span>
                            <span className="ai-check" aria-hidden="true">{selectedSkillIds.includes(skill.id) ? <Check size={12} /> : null}</span>
                          </label>
                        ))}
                      </div>
                    );
                  })}
                  {!skills.some((skill) => skill.enabled) && <p className="ai-skill-empty">还没有启用的技能。去技能库挑几件。</p>}
                </div>
              )}
            </div>

            <div className="ai-section">
              <div className="ai-section-head">
                <label htmlFor="ai-instruction">这次的要求</label>
                <select
                  className="ai-context-select"
                  value={contextChars}
                  onChange={(event) => setContextChars(Number(event.target.value))}
                  aria-label="上下文长度"
                >
                  <option value={24_000}>精简上下文</option>
                  <option value={48_000}>标准上下文</option>
                  <option value={90_000}>深读上下文</option>
                </select>
              </div>
              <textarea
                id="ai-instruction"
                className="ai-instruction"
                value={instruction}
                onChange={(event) => setInstruction(event.target.value)}
                placeholder={placeholders[action]}
                rows={3}
                maxLength={3000}
              />
              <p className="ai-context-note">
                将带上作品设定、前情摘要、上一章结尾{usesSelection && selection.text ? `，以及选中的 ${formatNumber(selection.text.length)} 字` : ''}。
              </p>
              <button
                type="button"
                className="ai-context-open"
                onClick={() => {
                  void (async () => {
                    const saved = await onBeforeContext?.();
                    if (saved === false) return;
                    setContextOpen(true);
                  })();
                }}
              >
                <Eye size={13} />
                透视这次上下文
              </button>
            </div>

            <div className="ai-generate-row">
              <button type="button" className="btn btn-lamp btn-block" onClick={generate} disabled={!canGenerate}>
                {streaming ? <Square size={14} /> : <Play size={14} />}
                {streaming ? '正在写…' : action === 'continue' ? `请灯下${chapterTitle ? '续写' : '起笔'}` : `请灯下${actionLabel(action)}`}
              </button>
              {streaming && (
                <button type="button" className="btn btn-ghost" onClick={stop} aria-label="停止生成">
                  停
                </button>
              )}
            </div>

            {hasOutput && (
              <div className="ai-result">
                <div className="ai-result-head">
                  <div>
                    <span className="ai-result-kicker">{actionLabel(runAction)}结果</span>
                    {meta && (
                      <span className="ai-result-meta">
                        {meta.stats.skills.length} 件工具 · {formatChars(meta.stats.contextChars)} 上下文
                      </span>
                    )}
                  </div>
                  <button type="button" className="icon-button" onClick={copy} aria-label="复制结果">
                    {copied ? <Check size={15} /> : <Copy size={15} />}
                  </button>
                </div>
                {meta?.stats.truncated?.length ? (
                  <p className="ai-truncated">
                    <AlertCircle size={13} />
                    {meta.stats.truncated.length} 处内容因上下文预算被截断。可以调高上下文，或减少技能。
                  </p>
                ) : null}
                <div className="ai-output-text">{output}</div>
                {reasoning && (
                  <details className="ai-reasoning">
                    <summary>看看模型的思考</summary>
                    <pre>{reasoning}</pre>
                  </details>
                )}
                {streaming && <span className="ai-caret" aria-label="正在输入" />}
                {error && <p className="ai-error"><AlertCircle size={14} /> {error}</p>}
                {error && <p className="ai-error-hint">{aiErrorHint(error)}</p>}
                {done && (
                  <p className="ai-done-note">
                    {formatNumber(done.outputChars)} 字 · {(done.elapsedMs / 1000).toFixed(1)} 秒
                    {done.usage?.output ? ` · ${done.usage.output} tokens` : ''}
                  </p>
                )}
                {resultIsStaleChapter && (
                  <p className="ai-stale">
                    <AlertCircle size={14} />
                    这段结果属于《{runChapterTitle || '上一章'}》。你已经切到别的章节，所以不能直接插入。复制它，或切回原章节再应用。
                  </p>
                )}

                {!streaming && (
                  <div className="ai-apply-row">
                    {resultIsStaleChapter ? (
                      <button type="button" className="btn btn-ghost btn-sm" onClick={copy}>
                        <Copy size={14} />
                        复制结果
                      </button>
                    ) : runAction === 'summarize' ? (
                      <button type="button" className="btn btn-lamp btn-sm" onClick={() => onSaveSummary(output)}>
                        <FileText size={14} />
                        存为本章摘要
                      </button>
                    ) : isProse ? (
                      <>
                        {canReplace && (
                          <button type="button" className="btn btn-lamp btn-sm" onClick={() => setDiffOpen(true)}>
                            预览并替换
                          </button>
                        )}
                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => onApply(output, 'insert')}>
                          <ArrowDown size={14} />
                          插入到光标
                        </button>
                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => onApply(output, 'append')}>
                          加到章末
                        </button>
                      </>
                    ) : runAction === 'outline' ? (
                      <>
                        <button type="button" className="btn btn-lamp btn-sm" onClick={() => onSaveBeats(output)}>
                          <List size={14} />
                          存为场景卡
                        </button>
                        <button type="button" className="btn btn-ghost btn-sm" onClick={copy}>
                          <Copy size={14} />
                          复制结果
                        </button>
                      </>
                    ) : (
                      <button type="button" className="btn btn-ghost btn-sm" onClick={copy}>
                        <Copy size={14} />
                        复制结果
                      </button>
                    )}
                    <button type="button" className="text-button" onClick={generate} disabled={streaming}>
                      再写一版
                    </button>
                  </div>
                )}
              </div>
            )}

            {!hasOutput && !streaming && (
              <div className="ai-idle">
                <p className="ai-idle-title">这张书桌会带上</p>
                <ul>
                  <li><span>01</span> 作品设定与人物关系</li>
                  <li><span>02</span> 前情摘要和上一章结尾</li>
                  <li><span>03</span> 你挑选的工具{selectedSkills.length ? `（${selectedSkills.length} 件）` : ''}</li>
                </ul>
                {usesSelection && selection.text && (
                  <p className="ai-selection-note">已选中 {formatNumber(selection.text.length)} 字。润色、扩写、收紧和改写会作用在这段文字上。</p>
                )}
                <p className="ai-idle-tip">写不出时，先选“走向”让它给几个坏主意。坏主意常常比好主意有用。</p>
              </div>
            )}

            {error && !hasOutput && <p className="ai-error"><AlertCircle size={14} /> {error}</p>}
          </div>
        </>
      )}
      <ContextModal
        open={contextOpen}
        onClose={() => setContextOpen(false)}
        providerId={providerId}
        model={model}
        projectId={projectId}
        chapterId={chapterId}
        action={action}
        instruction={instruction}
        selection={usesSelection ? selection.text : ''}
        skillIds={selectedSkills.map((skill) => skill.id)}
        contextChars={contextChars}
      />
      <DiffModal
        open={diffOpen}
        onClose={() => setDiffOpen(false)}
        before={selection.text}
        after={output}
        onAccept={() => {
          onApply(output, 'replace');
          setDiffOpen(false);
        }}
      />
    </aside>
  );
}
