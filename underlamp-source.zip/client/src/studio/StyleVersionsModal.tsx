import { useEffect, useMemo, useState } from 'react';
import { RotateCcw, Trash2 } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { diffText } from '../lib/diff';
import { formatNumber, timeAgo } from '../lib/format';
import type { StyleVersion } from '../types';

export function StyleVersionsModal({
  open,
  projectId,
  current,
  onClose,
  onRestore,
}: {
  open: boolean;
  projectId: string;
  current: string;
  onClose: () => void;
  onRestore: (content: string) => void;
}) {
  const toast = useToast();
  const [versions, setVersions] = useState<StyleVersion[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [view, setView] = useState<'diff' | 'side'>('diff');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    api.get<{ versions: StyleVersion[] }>(`/api/projects/${projectId}/style-versions`)
      .then((data) => {
        setVersions(data.versions);
        setSelectedId((currentId) => currentId && data.versions.some((v) => v.id === currentId) ? currentId : data.versions[0]?.id || null);
      })
      .catch((error) => toast.error((error as Error).message || '文风版本没有读出来'))
      .finally(() => setLoading(false));
  }, [open, projectId, toast]);

  const selected = versions.find((version) => version.id === selectedId) || null;
  const parts = useMemo(() => diffText(selected?.content || '', current), [selected, current]);

  async function removeVersion(id: string) {
    try {
      await api.delete(`/api/style-versions/${id}`);
      setVersions((currentVersions) => currentVersions.filter((version) => version.id !== id));
      if (selectedId === id) setSelectedId(null);
      toast.success('版本已删除');
    } catch (error) {
      toast.error((error as Error).message || '没有删除');
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="文风版本"
      description="旧版和当前文风卡的差异。恢复只改 textarea，保存后才写入项目。"
      size="xl"
      footer={
        <>
          <span className="modal-foot-spacer" />
          <button type="button" className="btn btn-ghost" onClick={onClose}>关闭</button>
          <button
            type="button"
            className="btn btn-primary"
            disabled={!selected}
            onClick={() => { if (selected) { onRestore(selected.content); onClose(); } }}
          >
            <RotateCcw size={14} />
            恢复这一版
          </button>
        </>
      }
    >
      {loading ? (
        <div className="codex-loading"><Spinner size={17} /> 正在翻旧文风</div>
      ) : versions.length === 0 ? (
        <p className="form-hint">还没有版本。在文风页点“存为版本”会把当前内容存下来。</p>
      ) : (
        <div className="style-version-layout">
          <aside className="style-version-list">
            {versions.map((version) => (
              <button
                key={version.id}
                type="button"
                className={selectedId === version.id ? 'active' : ''}
                onClick={() => setSelectedId(version.id)}
              >
                <strong>{version.source === 'extract' ? '从正文提取' : '手动快照'}</strong>
                <span>{timeAgo(version.createdAt)} · {formatNumber(version.content.length)} 字</span>
                {(version.model || version.sampleChapters?.length) && (
                  <em>
                    {[version.providerLabel, version.model, version.sampleChapters?.length ? `样章 ${version.sampleChapters.length} 章` : '', version.promptVersion].filter(Boolean).join(' · ')}
                  </em>
                )}
                <p>{version.content.slice(0, 90)}</p>
              </button>
            ))}
          </aside>
          <section className="style-version-diff">
            <div className="style-version-head">
              <span>旧版 → 当前</span>
              <div className="style-version-view">
                <button type="button" className={view === 'diff' ? 'active' : ''} onClick={() => setView('diff')}>差异</button>
                <button type="button" className={view === 'side' ? 'active' : ''} onClick={() => setView('side')}>并排</button>
              </div>
              {selected && (
                <button type="button" className="icon-button danger" onClick={() => { void removeVersion(selected.id); }} aria-label="删除版本">
                  <Trash2 size={14} />
                </button>
              )}
            </div>
            {view === 'diff' ? (
              <div className="diff-body">
                {parts.map((part, index) => (
                  <span key={index} className={`diff-part ${part.type}`}>{part.text}</span>
                ))}
              </div>
            ) : (
              <div className="style-side-by-side">
                <section>
                  <h4>旧版</h4>
                  <pre>{selected?.content || ''}</pre>
                </section>
                <section>
                  <h4>当前</h4>
                  <pre>{current}</pre>
                </section>
              </div>
            )}
          </section>
        </div>
      )}
    </Modal>
  );
}
