import { useEffect, useState } from 'react';
import { Clock3, RotateCcw } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { dateTime } from '../lib/format';
import type { Chapter, VersionInfo } from '../types';

export function VersionModal({
  open,
  chapterId,
  onClose,
  onRestored,
}: {
  open: boolean;
  chapterId: string | null;
  onClose: () => void;
  onRestored: (chapter: Chapter) => void;
}) {
  const toast = useToast();
  const [versions, setVersions] = useState<VersionInfo[]>([]);
  const [selected, setSelected] = useState<VersionInfo | null>(null);
  const [preview, setPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [snapshotting, setSnapshotting] = useState(false);

  async function load() {
    if (!chapterId) return;
    setLoading(true);
    try {
      const data = await api.get<{ versions: VersionInfo[] }>(`/api/chapters/${chapterId}/versions`);
      setVersions(data.versions);
      setSelected(data.versions[0] || null);
    } catch (error) {
      toast.error((error as Error).message || '历史版本没有读出来');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!open) return;
    setPreview('');
    setSelected(null);
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, chapterId]);

  useEffect(() => {
    if (!selected || !chapterId) {
      setPreview('');
      return;
    }
    let alive = true;
    setPreviewLoading(true);
    api
      .get<{ version: { content: string } }>(`/api/chapters/${chapterId}/versions/${selected.id}`)
      .then((data) => {
        if (alive) setPreview(data.version.content);
      })
      .catch((error) => {
        if (alive) toast.error((error as Error).message || '这个版本没有读出来');
      })
      .finally(() => {
        if (alive) setPreviewLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [selected, chapterId, toast]);

  async function snapshot() {
    if (!chapterId) return;
    setSnapshotting(true);
    try {
      await api.post(`/api/chapters/${chapterId}/versions`, {});
      toast.success('已给当前稿纸存了一个快照');
      await load();
    } catch (error) {
      toast.error((error as Error).message || '快照没有存成');
    } finally {
      setSnapshotting(false);
    }
  }

  async function restore() {
    if (!chapterId || !selected) return;
    setRestoring(true);
    try {
      const data = await api.post<{ chapter: Chapter }>(`/api/chapters/${chapterId}/versions/${selected.id}/restore`, {});
      onRestored(data.chapter);
      toast.success('已经回到这个版本');
      onClose();
    } catch (error) {
      toast.error((error as Error).message || '没有恢复');
    } finally {
      setRestoring(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="历史版本"
      description="每十分钟最多自动留一个快照，也可以手动存一份。最多保留 40 个版本。"
      size="xl"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>关闭</button>
          <button type="button" className="btn btn-ghost" onClick={snapshot} disabled={snapshotting || !chapterId}>
            {snapshotting ? <Spinner size={15} /> : <Clock3 size={15} />}
            给现在存一份
          </button>
          <button type="button" className="btn btn-primary" onClick={restore} disabled={!selected || restoring}>
            {restoring ? <Spinner size={15} /> : <RotateCcw size={15} />}
            恢复这个版本
          </button>
        </>
      }
    >
      <div className="version-layout">
        <div className="version-list">
          {loading ? (
            <div className="version-empty"><Spinner size={16} /> 正在翻旧稿</div>
          ) : versions.length === 0 ? (
            <div className="version-empty">还没有历史版本。继续写，或者手动存一份。</div>
          ) : (
            versions.map((version) => (
              <button
                key={version.id}
                type="button"
                className={`version-item ${selected?.id === version.id ? 'active' : ''}`}
                onClick={() => setSelected(version)}
              >
                <strong>{dateTime(version.createdAt)}</strong>
                <span>{version.wordCount} 字</span>
                <small>{version.preview}</small>
              </button>
            ))
          )}
        </div>
        <div className="version-preview">
          {previewLoading ? (
            <div className="version-empty"><Spinner size={16} /> 正在展开</div>
          ) : preview ? (
            <pre>{preview}</pre>
          ) : (
            <div className="version-empty">选一个版本，看看当时的样子。</div>
          )}
        </div>
      </div>
    </Modal>
  );
}
