import { useEffect, useRef, useState } from 'react';
import {
  ArrowDownToLine,
  BookMarked,
  Feather,
  ScanSearch,
  Send,
  Sparkles,
  Stethoscope,
  X,
} from 'lucide-react';
import { completeAgent } from '../api';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import type { Bible, ChapterMeta, ProjectSummary, Provider } from '../types';
import type { TextSelection } from './types';

type ChatMessage = { role: 'user' | 'assistant'; content: string };

export function InkCompanion({
  open,
  onClose,
  project,
  bible,
  chapters,
  provider,
  model,
  onOpenCodex,
  onRunAction,
  onOpenSettings,
  selection,
  onApply,
}: {
  open: boolean;
  onClose: () => void;
  project: ProjectSummary;
  bible: Bible;
  chapters: ChapterMeta[];
  provider: Provider | null;
  model: string;
  onOpenCodex: () => void;
  onRunAction: (action: string, instruction: string) => void;
  onOpenSettings: () => void;
  selection: TextSelection;
  onApply: (text: string, mode: 'insert' | 'replace' | 'append') => void;
}) {
  const toast = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    requestAnimationFrame(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }));
  }, [open, messages, busy]);

  function systemPrompt() {
    const summaries = chapters
      .filter((chapter) => chapter.summary)
      .slice(-3)
      .map((chapter) => `- ${chapter.title}：${chapter.summary}`)
      .join('\n');
    return `你是「灯灵」，中文长篇小说工作台「灯下」的创作伙伴。你熟悉当前作品的设定和前情，回答要短、具体、可执行。
不要自动改写正文；需要写正文时，建议作者用右侧的“续写/拆章/体检”动作，并给出可以直接粘贴的指令。
【作品】《${project.title}》${project.genre ? ` · ${project.genre}` : ''}
【一句话】${project.premise || '（未填）'}
【世界】${bible.world.slice(0, 1200)}
【人物】${bible.characters.slice(0, 1600)}
【大纲】${bible.outline.slice(0, 1200)}
【最近前情】${summaries || '（还没有章节摘要）'}`;
  }

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    if (!provider) {
      toast.info('先接入模型，灯灵才能回答');
      onOpenSettings();
      return;
    }
    const prior: ChatMessage[] = messages;
    const outgoing: ChatMessage[] = [...prior, { role: 'user', content: text }];
    setMessages(outgoing);
    setInput('');
    setBusy(true);
    try {
      const result = await completeAgent({
        providerId: provider.id,
        model,
        system: systemPrompt(),
        messages: outgoing.slice(-12),
        temperature: 0.55,
        maxTokens: 1800,
      });
      setMessages((current) => [...current, { role: 'assistant', content: result.text || '这次没有写出内容，再说一次？' }]);
    } catch (error) {
      toast.error((error as Error).message || '灯灵没有回应');
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;

  return (
    <>
      <button type="button" className="ink-scrim" aria-label="收起灯灵" onClick={onClose} />
      <aside className="ink-panel">
        <header className="ink-head">
          <div className="ink-title">
            <span className="ink-orb"><Sparkles size={16} /></span>
            <div><strong>灯灵</strong><span>当前《{project.title}》</span></div>
          </div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="关闭灯灵"><X size={17} /></button>
        </header>

        <div className="ink-actions">
          <button type="button" onClick={onOpenCodex}>
            <BookMarked size={15} /><span><strong>整理资料</strong><small>人物、地点、伏笔</small></span>
          </button>
          <button type="button" onClick={() => onRunAction('outline', '按当前章节和 Codex，给这一章做可执行场景卡。')}>
            <ScanSearch size={15} /><span><strong>拆这一章</strong><small>场景卡 / 节拍</small></span>
          </button>
          <button type="button" onClick={() => onRunAction('continue', '按本章场景卡写完整初稿，约 1800–2200 字，只写正文。')}>
            <Feather size={15} /><span><strong>写本章初稿</strong><small>到灯下面板确认</small></span>
          </button>
          <button type="button" onClick={() => onRunAction('diagnose', '体检这一章：AI 腔、节奏、对话、章末钩子。')}>
            <Stethoscope size={15} /><span><strong>体检本章</strong><small>只审稿，不改写</small></span>
          </button>
        </div>

        <div className="ink-chat" ref={scrollRef}>
          {messages.length === 0 ? (
            <div className="ink-empty">
              <p>“这一章卡在哪里？”</p>
              <span>我可以帮你拆场景、想人物动机、检查伏笔。写正文会交给灯下面板，不在这里偷偷改稿。</span>
            </div>
          ) : messages.map((message, index) => (
            <div key={index} className={`ink-message ${message.role}`}>
              <span>{message.role === 'assistant' ? '灯灵' : '你'}</span>
              <p>{message.content}</p>
              {message.role === 'assistant' && (
                <div className="ink-apply-row">
                  <button type="button" onClick={() => onApply(message.content, 'insert')}>
                    <ArrowDownToLine size={11} /> 插入正文
                  </button>
                  <button type="button" onClick={() => onApply(message.content, 'append')}>加到章末</button>
                  {selection.text.trim() && (
                    <button type="button" onClick={() => onApply(message.content, 'replace')}>替换选中</button>
                  )}
                </div>
              )}
            </div>
          ))}
          {busy && <div className="ink-thinking"><Spinner size={14} /> 灯灵在想</div>}
        </div>

        <div className="ink-composer">
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
                event.preventDefault();
                void send();
              }
            }}
            rows={2}
            placeholder={provider ? '比如：主角为什么不肯回家？' : '先接入模型，再和灯灵聊'}
            disabled={busy}
          />
          <button type="button" className="btn btn-lamp btn-sm" onClick={send} disabled={busy || !input.trim() || !provider}>
            {busy ? <Spinner size={14} /> : <Send size={14} />}
            发送
          </button>
        </div>
        <p className="ink-foot">灯灵只回答，不改稿。所有写入都要你确认。</p>
      </aside>
    </>
  );
}
