import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { FileSearch, Search } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import type { SearchResult } from '../types';

function Highlight({ text, query }: { text: string; query: string }) {
  const parts = useMemo(() => {
    if (!query.trim()) return [text];
    const lower = text.toLowerCase();
    const needle = query.toLowerCase();
    const output: Array<string | { hit: string }> = [];
    let cursor = 0;
    while (cursor < text.length) {
      const index = lower.indexOf(needle, cursor);
      if (index < 0) {
        output.push(text.slice(cursor));
        break;
      }
      if (index > cursor) output.push(text.slice(cursor, index));
      output.push({ hit: text.slice(index, index + query.length) });
      cursor = index + query.length;
    }
    return output;
  }, [text, query]);

  return (
    <>
      {parts.map((part, index) =>
        typeof part === 'string' ? (
          <Fragment key={index}>{part}</Fragment>
        ) : (
          <mark key={index}>{part.hit}</mark>
        ),
      )}
    </>
  );
}

export function ProjectSearchModal({
  open,
  onClose,
  projectId,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  onSelect: (chapterId: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const sequence = useRef(0);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    setResults([]);
    setError('');
    window.setTimeout(() => inputRef.current?.focus(), 60);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const q = query.trim();
    if (!q) {
      sequence.current += 1;
      setResults([]);
      setLoading(false);
      return;
    }
    const current = ++sequence.current;
    setLoading(true);
    const timer = window.setTimeout(async () => {
      try {
        const data = await api.get<{ results: SearchResult[] }>(
          `/api/projects/${projectId}/search?q=${encodeURIComponent(q)}`,
        );
        if (current === sequence.current) {
          setResults(data.results || []);
          setError('');
        }
      } catch (err) {
        if (current === sequence.current) setError((err as Error).message || '搜索失败');
      } finally {
        if (current === sequence.current) setLoading(false);
      }
    }, 260);
    return () => window.clearTimeout(timer);
  }, [query, open, projectId]);

  return (
    <Modal open={open} onClose={onClose} title="搜索全书" description="搜章节名、正文、摘要与场景卡。中文按原文匹配。" size="lg">
      <div className="search-modal-input">
        <Search size={17} />
        <input
          ref={inputRef}
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="比如：旧钥匙、那封信、渡口"
          maxLength={100}
          aria-label="搜索全书"
        />
        {loading && <Spinner size={16} />}
      </div>

      {error && <p className="form-error">{error}</p>}

      {!query.trim() ? (
        <div className="search-hint">
          <FileSearch size={24} />
          <p>输入一个名字、地点或句子。搜索只在你自己的这本书里进行。</p>
        </div>
      ) : !loading && results.length === 0 && !error ? (
        <div className="search-hint">
          <FileSearch size={24} />
          <p>没有找到「{query.trim()}」。换个更短的词试试。</p>
        </div>
      ) : (
        <div className="search-results">
          {results.map((result) => (
            <button
              type="button"
              key={`${result.chapterId}-${result.field}`}
              className="search-result"
              onClick={() => {
                onSelect(result.chapterId);
                onClose();
              }}
            >
              <span className="search-result-index">{String(result.chapterNumber).padStart(2, '0')}</span>
              <span className="search-result-main">
                <span className="search-result-title">
                  {result.title}
                  <em>{result.field === 'content' ? '正文' : result.field === 'summary' ? '摘要' : result.field === 'beats' ? '场景卡' : '章节名'}</em>
                </span>
                <span className="search-result-snippet">
                  <Highlight text={result.snippet} query={query.trim()} />
                </span>
              </span>
              <span className="search-result-words">{result.wordCount} 字</span>
            </button>
          ))}
          {results.length > 0 && <p className="search-count">找到 {results.length} 处 · 点击跳到对应章节</p>}
        </div>
      )}
    </Modal>
  );
}
