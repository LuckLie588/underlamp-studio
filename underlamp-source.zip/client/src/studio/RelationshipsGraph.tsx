import { useMemo } from 'react';
import { Network } from 'lucide-react';
import type { CodexEntry } from '../types';

const kindColor: Record<string, string> = {
  character: '#a94733',
  location: '#4f6d5b',
  faction: '#7b6748',
  item: '#8a6a45',
  concept: '#6d5d75',
};

export function RelationshipsGraph({
  entries,
  onSelect,
}: {
  entries: CodexEntry[];
  onSelect: (id: string) => void;
}) {
  const graph = useMemo(() => {
    const byName = new Map<string, CodexEntry>();
    for (const entry of entries) {
      byName.set(entry.name, entry);
      for (const alias of entry.aliases) byName.set(alias, entry);
    }
    const involved = new Set<string>();
    const edges: Array<{ from: CodexEntry; to: CodexEntry; label: string; note: string }> = [];
    for (const entry of entries) {
      for (const relation of entry.relationships) {
        const target = byName.get(relation.name);
        if (!target || target.id === entry.id) continue;
        involved.add(entry.id);
        involved.add(target.id);
        edges.push({ from: entry, to: target, label: relation.label, note: relation.note || '' });
      }
    }
    const nodes = entries.filter((entry) => involved.has(entry.id)).slice(0, 12);
    const positions = new Map<string, { x: number; y: number }>();
    nodes.forEach((node, index) => {
      const angle = (Math.PI * 2 * index) / Math.max(1, nodes.length) - Math.PI / 2;
      positions.set(node.id, {
        x: 380 + Math.cos(angle) * 255,
        y: 245 + Math.sin(angle) * 165,
      });
    });
    return { nodes, edges, positions };
  }, [entries]);

  if (!graph.nodes.length) {
    return (
      <div className="codex-detail-empty">
        <Network size={26} />
        <h2>关系还没有连起来。</h2>
        <p>在人物条目的“关系”里写：名字｜关系｜备注。比如：阿青｜旧友｜互相试探。保存后这里会出现线。</p>
      </div>
    );
  }

  return (
    <div className="relations-view">
      <div className="relations-head">
        <div>
          <span className="section-kicker">RELATIONSHIPS</span>
          <h2>谁欠谁，谁怕谁。</h2>
          <p>线只表示作者写下的关系，不自动推断。点一个人，回到他的条目。</p>
        </div>
        <span>{graph.nodes.length} 人 · {graph.edges.length} 条关系</span>
      </div>
      <div className="relations-canvas">
        <svg viewBox="0 0 760 490" role="img" aria-label="人物关系图">
          {graph.edges.map((edge, index) => {
            const from = graph.positions.get(edge.from.id)!;
            const to = graph.positions.get(edge.to.id)!;
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;
            return (
              <g key={`${edge.from.id}-${edge.to.id}-${index}`} className="relation-edge">
                <line x1={from.x} y1={from.y} x2={to.x} y2={to.y} />
                <text x={midX} y={midY - 5} textAnchor="middle">{edge.label || edge.note || '关系'}</text>
              </g>
            );
          })}
          {graph.nodes.map((node) => {
            const pos = graph.positions.get(node.id)!;
            return (
              <g key={node.id} className="relation-node" onClick={() => onSelect(node.id)} role="button" tabIndex={0}>
                <circle cx={pos.x} cy={pos.y} r={24} fill={kindColor[node.kind] || '#617a6b'} />
                <text x={pos.x} y={pos.y + 4} textAnchor="middle">{node.name.slice(0, 4)}</text>
                <text className="relation-node-role" x={pos.x} y={pos.y + 42} textAnchor="middle">{node.role || '人物'}</text>
              </g>
            );
          })}
        </svg>
      </div>
      <div className="relations-list">
        {graph.edges.map((edge, index) => (
          <button key={index} type="button" onClick={() => onSelect(edge.from.id)}>
            <strong>{edge.from.name}</strong>
            <span>{edge.label || '关系'}</span>
            <strong>{edge.to.name}</strong>
            {edge.note && <em>{edge.note}</em>}
          </button>
        ))}
      </div>
    </div>
  );
}
