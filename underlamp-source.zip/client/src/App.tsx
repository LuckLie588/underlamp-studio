import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { FullPageLoader } from './components/Spinner';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { canInstall, installApp } from './lib/pwa';
import { AppShell } from './layout/AppShell';
import { Landing } from './pages/Landing';

const Library = lazy(() => import('./pages/Library').then((module) => ({ default: module.Library })));
const Settings = lazy(() => import('./pages/Settings').then((module) => ({ default: module.Settings })));
const Skills = lazy(() => import('./pages/Skills').then((module) => ({ default: module.Skills })));
const Studio = lazy(() => import('./studio/Studio').then((module) => ({ default: module.Studio })));

function ScrollToTop() {
  const location = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);
  return null;
}

function LocalGate({ children }: { children: ReactNode }) {
  const { loading } = useAuth();
  if (loading) return <FullPageLoader label="正在打开本地书房" />;
  return <>{children}</>;
}

function NotFound() {  return (
    <div className="not-found">
      <p className="section-kicker">404</p>
      <h1>这一页没有写。</h1>
      <p>可能是稿纸被移走了，或者链接少了一个字。</p>
      <a className="btn btn-primary" href="/library">回到书房</a>
    </div>
  );
}

function PwaBanners() {
  const [installable, setInstallable] = useState(false);
  const [updateReady, setUpdateReady] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    const refresh = () => setInstallable(canInstall());
    const update = () => setUpdateReady(true);
    refresh();
    window.addEventListener('underlamp-installable', refresh);
    window.addEventListener('underlamp-update', update);
    return () => {
      window.removeEventListener('underlamp-installable', refresh);
      window.removeEventListener('underlamp-update', update);
    };
  }, []);
  if (dismissed || (!installable && !updateReady)) return null;
  return (
    <div className="pwa-banners">
      {updateReady && (
        <div>
          <strong>灯下已经更新</strong>
          <span>刷新一次，载入新版本。</span>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => window.location.reload()}>刷新</button>
        </div>
      )}
      {installable && (
        <div>
          <strong>安装灯下</strong>
          <span>装到桌面，像本地应用一样打开。</span>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { void installApp().then(() => setInstallable(canInstall())); }}>安装</button>
        </div>
      )}
      <button type="button" className="pwa-dismiss" onClick={() => setDismissed(true)} aria-label="关闭提示">×</button>
    </div>
  );
}

function OfflineBanner() {  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);
  if (online) return null;
  return <div className="offline-banner">当前离线。作品还在本机；模型和同步请求要联网才能用。</div>;
}

export function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <OfflineBanner />
          <PwaBanners />
          <ScrollToTop />
          <LocalGate>
            <Suspense fallback={<FullPageLoader />}>
              <Routes>
                <Route path="/" element={<Landing />} />
                <Route element={<AppShell />}>
                  <Route path="/library" element={<Library />} />
                  <Route path="/skills" element={<Skills />} />
                  <Route path="/settings" element={<Settings />} />
                </Route>
                <Route path="/project/:id" element={<Studio />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </LocalGate>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
