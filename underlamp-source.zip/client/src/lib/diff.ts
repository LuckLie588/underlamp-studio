export interface DiffPart {
  type: 'same' | 'add' | 'remove';
  text: string;
}

function sentences(text: string) {
  const rows = text.match(/[^。！？!?\n]*[。！？!?\n]?/g) || [];
  return rows.filter((row) => row.length > 0);
}

export function diffText(before: string, after: string): DiffPart[] {
  const a = sentences(before);
  const b = sentences(after);
  if (!a.length || !b.length || a.length * b.length > 160_000) {
    return [
      ...(before ? [{ type: 'remove' as const, text: before }] : []),
      ...(after ? [{ type: 'add' as const, text: after }] : []),
    ];
  }
  const dp = Array.from({ length: a.length + 1 }, () => new Uint16Array(b.length + 1));
  for (let i = a.length - 1; i >= 0; i -= 1) {
    for (let j = b.length - 1; j >= 0; j -= 1) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const parts: DiffPart[] = [];
  const push = (type: DiffPart['type'], text: string) => {
    if (!text) return;
    const last = parts[parts.length - 1];
    if (last?.type === type) last.text += text;
    else parts.push({ type, text });
  };
  let i = 0;
  let j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      push('same', a[i]);
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      push('remove', a[i]);
      i += 1;
    } else {
      push('add', b[j]);
      j += 1;
    }
  }
  while (i < a.length) { push('remove', a[i]); i += 1; }
  while (j < b.length) { push('add', b[j]); j += 1; }
  return parts;
}
