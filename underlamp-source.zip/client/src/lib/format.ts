export function formatNumber(value: number): string {
  return new Intl.NumberFormat('zh-CN').format(Number(value) || 0);
}

export function formatWords(value: number): string {
  const n = Number(value) || 0;
  if (n >= 10000) {
    const w = n / 10000;
    return `${w >= 100 ? Math.round(w) : w.toFixed(1).replace(/\.0$/, '')} 万`;
  }
  return formatNumber(n);
}

export function timeAgo(timestamp: number): string {
  if (!timestamp) return '';
  const diff = Date.now() - timestamp;
  if (diff < 60_000) return '刚刚';
  if (diff < 60 * 60_000) return `${Math.floor(diff / 60_000)} 分钟前`;
  if (diff < 24 * 60 * 60_000) return `${Math.floor(diff / (60 * 60_000))} 小时前`;
  if (diff < 48 * 60 * 60_000) return '昨天';
  if (diff < 7 * 24 * 60 * 60_000) return `${Math.floor(diff / (24 * 60 * 60_000))} 天前`;
  return new Date(timestamp).toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' });
}

export function clockTime(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

export function dateTime(timestamp: number): string {
  return new Date(timestamp).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function todayLabel(): string {
  const now = new Date();
  const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][now.getDay()];
  return `${now.getMonth() + 1} 月 ${now.getDate()} 日 · ${week}`;
}

export function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 5) return '夜深了';
  if (hour < 11) return '早上好';
  if (hour < 14) return '中午好';
  if (hour < 18) return '下午好';
  return '晚上好';
}

export function countWords(input: string): number {
  const s = input || '';
  if (!s.trim()) return 0;
  const cjk = (s.match(/[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/g) || []).length;
  const latin = (s.match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g) || []).length;
  return cjk + latin;
}

export function formatChars(n: number): string {
  return `${formatNumber(n)} 字`;
}

export function statusLabel(status: string): string {
  return (
    {
      writing: '正在写',
      paused: '暂时搁笔',
      done: '已完稿',
      idea: '只有一个念头',
      draft: '草稿',
      final: '定稿',
      outline: '待写',
    }[status] || status
  );
}

export function actionLabel(action: string): string {
  return (
    {
      continue: '续写',
      polish: '润色',
      expand: '扩写',
      condense: '收紧',
      rewrite: '改写',
      outline: '拆章',
      brainstorm: '走向',
      title: '起名',
      summarize: '摘要',
      extract: '提取设定',
      continuity: '连贯性',
      diagnose: '体检',
      chat: '对谈',
    }[action] || action
  );
}

export function isMac(): boolean {
  return typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);
}
