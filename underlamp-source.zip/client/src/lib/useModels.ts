import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Provider } from '../types';

const PROVIDER_KEY = 'underlamp.provider';
const MODEL_KEY = 'underlamp.model';

export function useModels(providers: Provider[]) {
  const [providerId, setProviderIdState] = useState<string>(() => {
    try {
      return localStorage.getItem(PROVIDER_KEY) || '';
    } catch {
      return '';
    }
  });
  const [model, setModelState] = useState<string>(() => {
    try {
      return localStorage.getItem(MODEL_KEY) || '';
    } catch {
      return '';
    }
  });

  const provider = useMemo(() => {
    if (!providers.length) return null;
    return (
      providers.find((item) => item.id === providerId) ||
      providers.find((item) => item.isDefault) ||
      providers[0]
    );
  }, [providers, providerId]);

  useEffect(() => {
    if (!provider) return;
    if (provider.id !== providerId) setProviderIdState(provider.id);
    if (!provider.models.some((item) => item.id === model)) {
      setModelState(provider.models[0]?.id || '');
    }
  }, [provider, providerId, model]);

  const setProviderId = useCallback(
    (id: string) => {
      setProviderIdState(id);
      try {
        localStorage.setItem(PROVIDER_KEY, id);
      } catch {
        /* ignore */
      }
      const next = providers.find((item) => item.id === id);
      if (next) {
        const nextModel = next.models[0]?.id || '';
        setModelState(nextModel);
        try {
          localStorage.setItem(MODEL_KEY, nextModel);
        } catch {
          /* ignore */
        }
      }
    },
    [providers],
  );

  const setModel = useCallback((value: string) => {
    setModelState(value);
    try {
      localStorage.setItem(MODEL_KEY, value);
    } catch {
      /* ignore */
    }
  }, []);

  return { provider, providerId: provider?.id || '', model, setProviderId, setModel };
}
