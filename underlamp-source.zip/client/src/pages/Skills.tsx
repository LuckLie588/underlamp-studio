import { useEffect, useMemo, useRef, useState, type DragEvent, type FormEvent } from 'react';
import {
  BookOpen,
  Check,
  Copy,
  Download,
  ExternalLink,
  FileText,
  FolderUp,
  Globe2,
  Layers,
  Pencil,
  Plus,
  RotateCcw,
  Search,
  Sparkles,
  Trash2,
  Upload,
  Wand2,
} from 'lucide-react';
import { api, uploadSkillFiles } from '../api';
import { downloadSkill } from '../local/export';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { EmptyState } from '../components/EmptyState';
import { Markdown } from '../components/Markdown';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { formatNumber, timeAgo } from '../lib/format';
import { GENRE_PACKS, type GenrePack } from '../local/genrePacks';
import type { ProjectSummary, Skill } from '../types';

type Filter = string;

function collectionOf(skill: Skill): string {
  const explicit = String(skill.collection || '').trim();
  if (explicit) return explicit;
  if (/^ultimate-novel/i.test(skill.name)) return 'LY小说Skill';
  if (skill.kind === 'reference') return '资料';
  if (skill.builtin) return '内置';
  return '我的导入';
}

function collectionRank(name: string) {
  if (name === '内置') return 90;
  if (name === '我的导入') return 91;
  if (name === '资料') return 92;
  return 0;
}

type LocalSkillMatch = { skill: Skill; score: number; reason: string };

function queryTokens(query: string) {
  const text = query.toLowerCase().replace(/[，。！？、；：,.!?;:()[\]{}"'“”‘’/\\|]/g, ' ');
  const tokens = new Set<string>();
  for (const part of text.split(/\s+/)) {
    if (!part) continue;
    if (/^[a-z0-9-]{2,}$/i.test(part)) tokens.add(part);
    if (/[\u4e00-\u9fff]/.test(part)) {
      if (part.length >= 2) tokens.add(part);
      for (let i = 0; i < part.length - 1; i += 1) tokens.add(part.slice(i, i + 2));
    }
  }
  return [...tokens].filter((token) => token.length >= 2).slice(0, 12);
}

function rankLocalSkills(skills: Skill[], query: string): LocalSkillMatch[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const tokens = queryTokens(q);
  return skills
    .filter((skill) => skill.kind === 'skill')
    .map((skill) => {
      const name = skill.name.toLowerCase();
      const description = (skill.description || '').toLowerCase();
      const tags = skill.tags.map((tag) => tag.toLowerCase());
      let score = 0;
      const reasons: string[] = [];
      if (name.includes(q)) { score += 18; reasons.push('名称匹配'); }
      if (description.includes(q)) { score += 8; reasons.push('说明匹配'); }
      if (tags.some((tag) => tag.includes(q))) { score += 6; reasons.push('标签匹配'); }
      for (const token of tokens) {
        if (name.includes(token)) score += 5;
        if (description.includes(token)) score += 2;
        if (tags.some((tag) => tag.includes(token))) score += 3;
      }
      const hitTags = skill.tags.filter((tag) => tokens.some((token) => tag.toLowerCase().includes(token))).slice(0, 3);
      if (hitTags.length && !tags.some((tag) => tag.includes(q))) reasons.push(`标签：${hitTags.join(' / ')}`);
      return { skill, score, reason: [...new Set(reasons)].slice(0, 2).join(' · ') || '关键词相关' };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || b.skill.updatedAt - a.skill.updatedAt)
    .slice(0, 8);
}

type ExternalSkill = {
  id: string;
  name: string;
  source: string;
  skillId: string;
  installs: number;
  url: string;
  installCommand: string;
};

function KindBadge({ kind }: { kind: string }) {
  return <span className={`kind-badge kind-${kind}`}>{kind === 'skill' ? '技能' : '资料'}</span>;
}

function Switch({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`switch ${checked ? 'on' : ''}`}
      onClick={(event) => {
        event.stopPropagation();
        onChange();
      }}
    >
      <span />
    </button>
  );
}

export function Skills() {
  const toast = useToast();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<Skill | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Skill | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Skill | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [finderOpen, setFinderOpen] = useState(false);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [packProjectId, setPackProjectId] = useState('');
  const [packDetail, setPackDetail] = useState<GenrePack | null>(null);
  const [packBusy, setPackBusy] = useState('');

  async function loadSkills(preferId?: string) {
    setLoading(true);
    try {
      const data = await api.get<{ skills: Skill[] }>('/api/skills');
      setSkills(data.skills);
      const wanted = [preferId, selectedId].find(
        (candidate) => candidate && data.skills.some((skill) => skill.id === candidate),
      );
      const next = wanted || data.skills[0]?.id || null;
      setSelectedId(next);
    } catch (error) {
      toast.error((error as Error).message || '技能没有加载出来');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadSkills();
    api.get<{ projects: ProjectSummary[] }>('/api/projects')
      .then((data) => {
        setProjects(data.projects);
        setPackProjectId((current) => current || data.projects[0]?.id || '');
      })
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setDetail(null);
      return;
    }
    let alive = true;
    setDetailLoading(true);
    api
      .get<{ skill: Skill }>(`/api/skills/${selectedId}`)
      .then((data) => {
        if (alive) setDetail(data.skill);
      })
      .catch((error) => {
        if (alive) toast.error((error as Error).message || '技能内容没有打开');
      })
      .finally(() => {
        if (alive) setDetailLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [selectedId, toast]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return skills.filter((skill) => {
      if (filter !== 'all' && collectionOf(skill) !== filter) return false;
      if (!q) return true;
      return (
        skill.name.toLowerCase().includes(q) ||
        skill.description.toLowerCase().includes(q) ||
        skill.tags.some((tag) => tag.toLowerCase().includes(q))
      );
    });
  }, [skills, filter, query]);

  const collections = useMemo(() => {
    const names = [...new Set(skills.map((skill) => collectionOf(skill)))];
    return names.sort((a, b) => collectionRank(a) - collectionRank(b) || a.localeCompare(b, 'zh-CN'));
  }, [skills]);

  const grouped = useMemo(() => {
    const buckets = new Map<string, Skill[]>();
    for (const skill of filtered) {
      const key = collectionOf(skill);
      const list = buckets.get(key) || [];
      list.push(skill);
      buckets.set(key, list);
    }
    return collections
      .filter((key) => buckets.has(key))
      .map((key) => ({ key, label: key, items: buckets.get(key)! }));
  }, [filtered, collections]);

  const counts = useMemo(() => {
    const result: Record<string, number> = { all: skills.length };
    for (const skill of skills) {
      const key = collectionOf(skill);
      result[key] = (result[key] || 0) + 1;
    }
    return result;
  }, [skills]);

  async function toggle(skill: Skill) {
    try {
      const data = await api.patch<{ skill: Skill }>(`/api/skills/${skill.id}`, { enabled: !skill.enabled });
      setSkills((current) => current.map((item) => (item.id === skill.id ? { ...item, enabled: data.skill.enabled } : item)));
      if (detail?.id === skill.id) setDetail({ ...detail, enabled: data.skill.enabled });
      toast.success(data.skill.enabled ? `已启用《${skill.name}》` : `已停用《${skill.name}》`);
    } catch (error) {
      toast.error((error as Error).message || '没有改成');
    }
  }

  async function enableFound(ids: string[]) {
    const targets = skills.filter((skill) => ids.includes(skill.id) && !skill.enabled);
    try {
      for (const skill of targets) {
        await api.patch(`/api/skills/${skill.id}`, { enabled: true });
      }
      if (targets.length) {
        const targetIds = new Set(targets.map((skill) => skill.id));
        setSkills((current) => current.map((skill) => (targetIds.has(skill.id) ? { ...skill, enabled: true } : skill)));
        if (detail && targetIds.has(detail.id)) setDetail({ ...detail, enabled: true });
        toast.success(`已启用 ${targets.length} 个技能`);
      } else {
        toast.success('选中的技能都已经启用了');
      }
    } catch (error) {
      toast.error((error as Error).message || '启用失败');
    }
  }

  async function remove() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.delete(`/api/skills/${deleteTarget.id}`);
      toast.success(`已删除《${deleteTarget.name}》`);
      setDeleteTarget(null);
      if (selectedId === deleteTarget.id) setSelectedId(null);
      await loadSkills();
    } catch (error) {
      toast.error((error as Error).message || '没有删掉');
    } finally {
      setDeleting(false);
    }
  }

  async function restore() {
    setRestoring(true);
    try {
      const data = await api.post<{ added: number }>('/api/skills/restore-builtins', {});
      toast.success(data.added ? `补回了 ${data.added} 件内置技能` : '内置技能都在');
      await loadSkills();
    } catch (error) {
      toast.error((error as Error).message || '内置技能没有补回来');
    } finally {
      setRestoring(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setEditorOpen(true);
  }

  function openEdit() {
    if (!detail) return;
    setEditing(detail);
    setEditorOpen(true);
  }

  async function mountPack(pack: GenrePack) {
    if (!packProjectId) {
      toast.info('先开一本新书，再把类型包挂上去');
      return;
    }
    setPackBusy(pack.id);
    try {
      const data = await api.patch<{ project: ProjectSummary }>(`/api/projects/${packProjectId}`, {
        genrePackId: pack.id,
      });
      setProjects((current) => current.map((project) => (project.id === data.project.id ? data.project : project)));
      toast.success(`《${data.project.title}》挂上了「${pack.name}」`);
    } catch (error) {
      toast.error((error as Error).message || '类型包没有挂上');
    } finally {
      setPackBusy('');
    }
  }

  const selectedPackProject = projects.find((project) => project.id === packProjectId) || null;

  return (
    <div className="skills-page page-enter">
      <header className="skills-head">
        <div>
          <p className="section-kicker">工艺与资料</p>
          <h1>技能库</h1>
          <p>
            技能是给模型的工艺要求；资料只作为事实、语感和素材参考。生成时自己决定带哪几件。
          </p>
        </div>
        <div className="skills-head-actions">
          <button type="button" className="btn btn-ghost" onClick={restore} disabled={restoring}>
            {restoring ? <Spinner size={15} /> : <RotateCcw size={15} />}
            补回内置
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setFinderOpen(true)}>
            <Wand2 size={16} />
            找技能
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setUploadOpen(true)}>
            <Upload size={16} />
            导入文件
          </button>
          <button type="button" className="btn btn-primary" onClick={openCreate}>
            <Plus size={16} />
            新建技能
          </button>
        </div>
      </header>

      <section className="pack-section" aria-label="类型包">
        <div className="pack-head">
          <div>
            <span className="section-kicker">类型包</span>
            <h2>先选一套江湖规矩，再动笔。</h2>
            <p>每套包含 10 条法则和 13 个桥段。挂到项目后，会和作品设定一起进入上下文；不替代你的技能。</p>
          </div>
          <label className="pack-project">
            <span>挂载到</span>
            <select value={packProjectId} onChange={(event) => setPackProjectId(event.target.value)}>
              {projects.length === 0 ? <option value="">还没有作品</option> : null}
              {projects.map((project) => <option key={project.id} value={project.id}>{project.title}</option>)}
            </select>
          </label>
        </div>
        <div className="pack-grid">
          {GENRE_PACKS.map((pack) => {
            const mounted = selectedPackProject?.genrePackId === pack.id;
            return (
              <article key={pack.id} className={`pack-card ${mounted ? 'mounted' : ''}`}>
                <div className="pack-card-top">
                  <span>{pack.genre}</span>
                  {mounted && <em><Check size={11} /> 已挂载</em>}
                </div>
                <h3>{pack.name}</h3>
                <p>{pack.tagline}</p>
                <div className="pack-tags">{pack.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                <div className="pack-card-actions">
                  <button type="button" className="text-button" onClick={() => setPackDetail(pack)}>看 10 法则 / 13 桥段</button>
                  <button
                    type="button"
                    className={`btn btn-sm ${mounted ? 'btn-ghost' : 'btn-primary'}`}
                    disabled={Boolean(packBusy) || !packProjectId || mounted}
                    onClick={() => { void mountPack(pack); }}
                  >
                    {packBusy === pack.id ? <Spinner size={13} /> : mounted ? '已挂载' : '挂载'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <div className="skills-toolbar">
        <div className="segmented" role="tablist" aria-label="筛选技能">
          {([
            ['all', '全部', counts.all],
            ...collections.map((name) => [name, name, counts[name] || 0] as const),
          ] as const).map(([value, label, count]) => (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={filter === value}
              className={filter === value ? 'active' : ''}
              onClick={() => setFilter(value)}
            >
              {label}
              <span>{count}</span>
            </button>
          ))}
        </div>
        <label className="search-field">
          <Search size={15} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="搜名字、用途或标签"
            aria-label="搜索技能"
          />
        </label>
      </div>

      <div className="skills-layout">
        <section className="skill-list" aria-label="技能列表">
          {loading ? (
            <div className="skill-list-loading">
              <Spinner size={18} /> 正在整理工具
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={<Sparkles size={28} />}
              title={skills.length ? '没有找到这一件' : '工具箱还是空的'}
              description={skills.length ? '换个关键词，或者把筛选切回全部。' : '导入一份 SKILL.md，或者从新建一件开始。'}
              action={
                <button type="button" className="btn btn-ghost" onClick={() => setUploadOpen(true)}>
                  <Upload size={15} />
                  导入文件
                </button>
              }
            />
          ) : (
            grouped.map((group) => (
              <div key={group.key} className="skill-group">
                {filter === 'all' && grouped.length > 1 && (
                  <div className="skill-group-head">
                    <span>{group.label}</span>
                    <em>{group.items.length}</em>
                  </div>
                )}
                {group.items.map((skill) => (
                  <div
                    key={skill.id}
                    role="button"
                    tabIndex={0}
                    className={`skill-row ${selectedId === skill.id ? 'selected' : ''} ${skill.enabled ? '' : 'is-off'}`}
                    onClick={() => setSelectedId(skill.id)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        setSelectedId(skill.id);
                      }
                    }}
                  >
                    <span className={`skill-icon ${skill.kind}`} aria-hidden="true">
                      {skill.kind === 'skill' ? <Sparkles size={16} /> : <BookOpen size={16} />}
                    </span>
                    <span className="skill-row-main">
                      <span className="skill-row-title">
                        <strong>{skill.name}</strong>
                        <em className={`skill-collection ${collectionOf(skill) === '内置' ? 'builtin' : collectionOf(skill) === '我的导入' ? 'mine' : collectionOf(skill) === '资料' ? 'reference' : 'package'}`}>{collectionOf(skill)}</em>
                      </span>
                      <span className="skill-row-desc">{skill.description || skill.preview || '没有写说明'}</span>
                      <span className="skill-row-meta">
                        <KindBadge kind={skill.kind} />
                        <span>{formatNumber(skill.chars)} 字</span>
                        {skill.tags.slice(0, 3).map((tag) => (
                          <span className="tag-mini" key={tag}>{tag}</span>
                        ))}
                      </span>
                    </span>
                    <Switch checked={skill.enabled} onChange={() => toggle(skill)} label={`${skill.enabled ? '停用' : '启用'} ${skill.name}`} />
                  </div>
                ))}
              </div>
            ))
          )}
        </section>

        <section className="skill-detail">
          {detailLoading ? (
            <div className="detail-loading">
              <Spinner size={20} />
              正在展开
            </div>
          ) : detail ? (
            <>
              <header className="skill-detail-head">
                <div>
                  <div className="skill-detail-meta">
                    <KindBadge kind={detail.kind} />
                    {detail.builtin && <span className="tag-mini">内置</span>}
                    <span>{formatNumber(detail.chars)} 字</span>
                    <span>更新于 {timeAgo(detail.updatedAt)}</span>
                  </div>
                  <h2>{detail.name}</h2>
                  <p>{detail.description || '这件工具还没有写说明。'}</p>
                  {detail.tags.length > 0 && (
                    <div className="tag-row">
                      {detail.tags.map((tag) => <span className="tag" key={tag}>{tag}</span>)}
                    </div>
                  )}
                </div>
                <div className="skill-detail-actions">
                  <button type="button" className="icon-button" onClick={() => downloadSkill(detail)} title="下载 Markdown" aria-label="下载 Markdown">
                    <Download size={16} />
                  </button>
                  <button type="button" className="icon-button" onClick={openEdit} title="编辑" aria-label="编辑">
                    <Pencil size={16} />
                  </button>
                  <button type="button" className="icon-button danger" onClick={() => setDeleteTarget(detail)} title="删除" aria-label="删除">
                    <Trash2 size={16} />
                  </button>
                </div>
              </header>
              <div className="skill-content-scroll">
                <Markdown>{(detail.content || '').replace(/^#\s+.*\n+/, '')}</Markdown>
              </div>
              <footer className="skill-detail-foot">
                <span>{detail.sourceFilename ? `来自 ${detail.sourceFilename}` : '在灯下创建'}</span>
                <Switch checked={detail.enabled} onChange={() => toggle(detail)} label={`${detail.enabled ? '停用' : '启用'} ${detail.name}`} />
              </footer>
            </>
          ) : (
            <EmptyState
              icon={<FileText size={28} />}
              title="选一件工具"
              description="左边是技能和资料。选中之后，可以在这里读全文、编辑或下载。"
            />
          )}
        </section>
      </div>

      <UploadModal
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onUploaded={async (ids) => {
          setUploadOpen(false);
          await loadSkills(ids[0]);
          toast.success('文件已经放上书桌');
        }}
      />
      <SkillEditorModal
        open={editorOpen}
        skill={editing}
        onClose={() => setEditorOpen(false)}
        onSaved={async (skill) => {
          setEditorOpen(false);
          await loadSkills(skill.id);
          setSelectedId(skill.id);
          toast.success('技能已经保存');
        }}
      />
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="删掉这件工具？"
        message={`《${deleteTarget?.name || ''}》会从你的技能库里移除，已经写进作品里的文字不受影响。`}
        confirmLabel="删除"
        danger
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={remove}
      />
      <Modal
        open={Boolean(packDetail)}
        onClose={() => setPackDetail(null)}
        title={packDetail?.name || '类型包'}
        description={packDetail?.blurb}
        size="lg"
        footer={
          <>
            <span className="modal-foot-spacer" />
            <button type="button" className="btn btn-ghost" onClick={() => setPackDetail(null)}>关闭</button>
            <button
              type="button"
              className="btn btn-primary"
              disabled={!packProjectId || !packDetail || selectedPackProject?.genrePackId === packDetail.id || Boolean(packBusy)}
              onClick={() => { if (packDetail) void mountPack(packDetail); }}
            >
              {packDetail && selectedPackProject?.genrePackId === packDetail.id ? '已挂载' : '挂到当前项目'}
            </button>
          </>
        }
      >
        {packDetail && (
          <div className="pack-detail">
            <div className="pack-detail-tags">{packDetail.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
            <div className="pack-detail-cols">
              <section>
                <h3>十条法则</h3>
                <ol>{packDetail.laws.map((law) => <li key={law}>{law}</li>)}</ol>
              </section>
              <section>
                <h3>十三个桥段</h3>
                <ol>{packDetail.bridges.map((bridge) => <li key={bridge}>{bridge}</li>)}</ol>
              </section>
            </div>
          </div>
        )}
      </Modal>
      <SkillFinderModal
        open={finderOpen}
        onClose={() => setFinderOpen(false)}
        skills={skills}
        onEnable={enableFound}
      />
    </div>
  );
}

export function SkillFinderModal({
  open,
  onClose,
  skills,
  onEnable,
}: {
  open: boolean;
  onClose: () => void;
  skills: Skill[];
  onEnable: (ids: string[]) => Promise<void>;
}) {
  const toast = useToast();
  const [query, setQuery] = useState('');
  const [matches, setMatches] = useState<LocalSkillMatch[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [searched, setSearched] = useState(false);
  const [external, setExternal] = useState<ExternalSkill[]>([]);
  const [externalBusy, setExternalBusy] = useState(false);
  const [externalError, setExternalError] = useState('');
  const [externalSearched, setExternalSearched] = useState(false);
  const [enabling, setEnabling] = useState(false);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    setMatches([]);
    setSelected(new Set());
    setSearched(false);
    setExternal([]);
    setExternalError('');
    setExternalSearched(false);
  }, [open]);

  async function searchExternal(text = query) {
    const q = text.trim();
    if (q.length < 2) return;
    setExternalBusy(true);
    setExternalError('');
    setExternalSearched(true);
    try {
      const response = await fetch(`/api/tools/skill-finder/search?q=${encodeURIComponent(q)}`);
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.error || '外部检索失败');
      setExternal(Array.isArray(data?.results) ? data.results : []);
    } catch (error) {
      setExternal([]);
      setExternalError((error as Error).message || '外部检索失败');
    } finally {
      setExternalBusy(false);
    }
  }

  function searchLocal(event?: FormEvent) {
    event?.preventDefault();
    const q = query.trim();
    if (!q) return;
    const found = rankLocalSkills(skills, q);
    setMatches(found);
    setSelected(new Set(found.slice(0, 3).map((item) => item.skill.id)));
    setSearched(true);
    setExternal([]);
    setExternalError('');
    setExternalSearched(false);
    if (!found.length) void searchExternal(q);
  }

  async function enableSelected() {
    if (!selected.size) return;
    setEnabling(true);
    try {
      await onEnable([...selected]);
    } finally {
      setEnabling(false);
    }
  }

  function toggleSelected(id: string) {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  async function copyCommand(command: string) {
    try {
      await navigator.clipboard.writeText(command);
      toast.success('安装命令已复制');
    } catch {
      toast.error('复制失败，请手动选中命令');
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="找技能"
      description="先说你要做什么。平台先找现有技能并勾选；没有匹配，再去 skills.sh 找外部推荐。"
      size="lg"
      footer={
        <>
          <span className="modal-foot-spacer" />
          <button type="button" className="btn btn-ghost" onClick={onClose}>关闭</button>
          <button type="button" className="btn btn-primary" onClick={() => { void enableSelected(); }} disabled={!selected.size || enabling}>
            {enabling ? <Spinner size={14} /> : <Check size={14} />}
            启用选中（{selected.size}）
          </button>
        </>
      }
    >
      <div className="skill-finder">
        <form className="skill-finder-search" onSubmit={searchLocal}>
          <Search size={16} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="例如：写一章打斗 / 审稿 / 去 AI 味 / 拆大纲"
            autoFocus
          />
          <button type="submit" className="btn btn-primary btn-sm" disabled={query.trim().length < 2}>找平台内技能</button>
        </form>

        {searched && (
          <section className="skill-finder-section">
            <div className="skill-finder-head">
              <h3>平台内匹配</h3>
              <span>{matches.length ? `自动勾选前 ${Math.min(3, matches.length)} 个` : '没有匹配'}</span>
            </div>
            {matches.length ? (
              <div className="skill-finder-local">
                {matches.map(({ skill, score, reason }) => (
                  <label key={skill.id} className={`skill-finder-row ${selected.has(skill.id) ? 'selected' : ''}`}>
                    <input type="checkbox" checked={selected.has(skill.id)} onChange={() => toggleSelected(skill.id)} />
                    <span className="skill-finder-main">
                      <strong>{skill.name}</strong>
                      <em>{skill.description || '没有说明'}</em>
                      <small>{reason} · 匹配分 {score} · {skill.enabled ? '已启用' : '未启用'}</small>
                    </span>
                    {skill.enabled && <span className="skill-finder-enabled">已启用</span>}
                  </label>
                ))}
              </div>
            ) : (
              <p className="skill-finder-empty">平台里没有够接近的技能，下面去外部找。</p>
            )}
          </section>
        )}

        {(externalSearched || externalBusy || externalError) && (
          <section className="skill-finder-section">
            <div className="skill-finder-head">
              <h3>skills.sh 外部推荐</h3>
              <span>{externalBusy ? '正在查' : external.length ? `${external.length} 个结果` : '暂无结果'}</span>
            </div>
            {externalBusy ? (
              <p className="skill-finder-empty"><Spinner size={14} /> 正在检索外部技能库</p>
            ) : externalError ? (
              <p className="form-error">{externalError}</p>
            ) : external.length ? (
              <div className="skill-finder-external">
                {external.map((skill) => (
                  <article key={skill.id} className="skill-finder-card">
                    <div>
                      <strong>{skill.name}</strong>
                      <span>{skill.source} · {formatNumber(skill.installs)} 次安装</span>
                    </div>
                    <div className="skill-finder-command">
                      <code>{skill.installCommand}</code>
                      <button type="button" className="icon-button" title="复制安装命令" onClick={() => { void copyCommand(skill.installCommand); }}>
                        <Copy size={14} />
                      </button>
                    </div>
                    <div className="skill-finder-links">
                      <a href={skill.url} target="_blank" rel="noreferrer">在 skills.sh 查看 <ExternalLink size={12} /></a>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <p className="skill-finder-empty">外部也没有找到。可以直接用灯灵按普通写作流程处理。</p>
            )}
            <p className="form-hint">外部技能不会自动安装。复制命令在终端执行后，把生成的 SKILL.md 或 ZIP 再导入平台。</p>
          </section>
        )}

        <div className="skill-finder-fallback">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { void searchExternal(); }} disabled={externalBusy || query.trim().length < 2}>
            <Globe2 size={14} />
            直接搜外部技能
          </button>
          <span>外部检索由 skills.sh 提供；不会自动下载或执行任何包。</span>
        </div>
      </div>
    </Modal>
  );
}

function UploadModal({
  open,
  onClose,
  onUploaded,
}: {
  open: boolean;
  onClose: () => void;
  onUploaded: (ids: string[]) => void;
}) {
  const toast = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [kind, setKind] = useState<'auto' | 'skill' | 'reference'>('auto');
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');

  function addFiles(incoming: FileList | File[]) {
    const next = Array.from(incoming);
    setFiles((current) => {
      const names = new Set(current.map((file) => `${file.name}:${file.size}`));
      return [...current, ...next.filter((file) => !names.has(`${file.name}:${file.size}`))].slice(0, 12);
    });
    setError('');
  }

  function onDrop(event: DragEvent) {
    event.preventDefault();
    setDragging(false);
    if (event.dataTransfer.files.length) addFiles(event.dataTransfer.files);
  }

  async function submit() {
    if (!files.length) return;
    setBusy(true);
    setProgress(0);
    setError('');
    try {
      const data = await uploadSkillFiles(files, kind, setProgress);
      if (data.errors?.length) {
        toast.error(`${data.errors.length} 个文件没有读出来：${data.errors[0].filename}`);
      }
      onUploaded(data.skills.map((skill) => skill.id));
      setFiles([]);
      setProgress(0);
    } catch (err) {
      setError((err as Error).message || '文件没有导入成功');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="导入技能或资料"
      description="Markdown、文本、Word、PDF，或带 SKILL.md 的整包 zip。"
      size="lg"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            取消
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || !files.length}>
            {busy ? <Spinner size={16} /> : <Upload size={16} />}
            {busy ? `正在读 ${progress}%` : `导入 ${files.length ? `${files.length} 个文件` : ''}`}
          </button>
        </>
      }
    >
      <div
        className={`dropzone ${dragging ? 'dragging' : ''}`}
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(event) => event.key === 'Enter' && inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".md,.markdown,.mdx,.txt,.text,.docx,.pdf,.zip,.json,.yaml,.yml"
          onChange={(event) => event.target.files && addFiles(event.target.files)}
          hidden
        />
        <span className="dropzone-icon"><FolderUp size={28} /></span>
        <strong>把文件拖进来，或点这里选</strong>
        <p>单文件最大 40MB，一次最多 12 个。PDF 限 300 页以内，扫描件读不出文字。</p>
      </div>

      {files.length > 0 && (
        <ul className="file-list">
          {files.map((file, index) => (
            <li key={`${file.name}-${index}`}>
              <FileText size={15} />
              <span>{file.name}</span>
              <small>{(file.size / 1024).toFixed(0)} KB</small>
              <button
                type="button"
                className="icon-button"
                onClick={() => setFiles((current) => current.filter((_, i) => i !== index))}
                aria-label={`移除 ${file.name}`}
              >
                ×
              </button>
            </li>
          ))}
        </ul>
      )}

      <fieldset className="radio-fieldset">
        <legend>导入为</legend>
        {([
          ['auto', '自动判断', '带 frontmatter 或 SKILL.md 的作为技能，其余作为资料'],
          ['skill', '技能', '会被当作工艺要求，参与提示词'],
          ['reference', '资料', '只作为事实、语感和素材参考'],
        ] as const).map(([value, label, note]) => (
          <label key={value} className={`radio-card ${kind === value ? 'selected' : ''}`}>
            <input type="radio" name="import-kind" value={value} checked={kind === value} onChange={() => setKind(value)} />
            <span>
              <strong>{label}</strong>
              <small>{note}</small>
            </span>
          </label>
        ))}
      </fieldset>

      {busy && (
        <div className="upload-progress" aria-label="上传进度">
          <span style={{ width: `${progress}%` }} />
        </div>
      )}
      {error && <p className="form-error">{error}</p>}
    </Modal>
  );
}

function SkillEditorModal({
  open,
  skill,
  onClose,
  onSaved,
}: {
  open: boolean;
  skill: Skill | null;
  onClose: () => void;
  onSaved: (skill: Skill) => void;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [kind, setKind] = useState<'skill' | 'reference'>('skill');
  const [content, setContent] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setName(skill?.name || '');
    setDescription(skill?.description || '');
    setTags(skill?.tags?.join('，') || '');
    setKind(skill?.kind || 'skill');
    setContent(
      skill?.content ||
        `# 新技能\n\n## 什么时候用\n\n写清楚这个技能在什么任务里生效。\n\n## 具体要求\n\n- \n- \n\n## 不要做什么\n\n- \n`,
    );
    setError('');
  }, [open, skill]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const payload = { name, description, tags, kind, content };
      const data = skill
        ? await api.patch<{ skill: Skill }>(`/api/skills/${skill.id}`, payload)
        : await api.post<{ skill: Skill }>('/api/skills/text', payload);
      onSaved(data.skill);
    } catch (err) {
      setError((err as Error).message || '没有保存成功');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={skill ? '编辑技能' : '新建技能'}
      description={skill ? '改动只影响你自己的这一份。' : '一份技能，就是一段会被模型认真读的工艺说明。'}
      size="xl"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            取消
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || !name.trim() || !content.trim()}>
            {busy ? <Spinner size={16} /> : null}
            {busy ? '正在保存…' : '保存'}
          </button>
        </>
      }
    >
      <form className="skill-editor" onSubmit={submit}>
        <div className="editor-row">
          <label className="field">
            <span>名称</span>
            <input value={name} onChange={(event) => setName(event.target.value)} maxLength={80} required autoFocus />
          </label>
          <label className="field">
            <span>类型</span>
            <select value={kind} onChange={(event) => setKind(event.target.value as 'skill' | 'reference')}>
              <option value="skill">技能 · 工艺要求</option>
              <option value="reference">资料 · 事实与语感参考</option>
            </select>
          </label>
        </div>
        <label className="field">
          <span>一句话说明</span>
          <input
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            maxLength={500}
            placeholder="这个技能解决什么问题，什么时候该用它。"
          />
        </label>
        <label className="field">
          <span>标签</span>
          <input value={tags} onChange={(event) => setTags(event.target.value)} placeholder="结构，对话，文风（用逗号分隔）" />
        </label>
        <label className="field">
          <span>正文 Markdown</span>
          <textarea
            className="code-textarea"
            value={content}
            onChange={(event) => setContent(event.target.value)}
            rows={18}
            spellCheck={false}
            required
          />
        </label>
        {error && <p className="form-error">{error}</p>}
      </form>
    </Modal>
  );
}
