import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookPlus, Feather, Plus, Sparkles } from 'lucide-react';
import { api } from '../api';
import { EmptyState } from '../components/EmptyState';
import { Spinner } from '../components/Spinner';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatNumber, formatWords, greeting, statusLabel, timeAgo, todayLabel } from '../lib/format';
import type { ProjectSummary, Skill, WritingStats } from '../types';
import { NewProjectModal } from './NewProjectModal';

function BookCover({ project }: { project: ProjectSummary }) {
  return (
    <div className={`book-cover accent-${project.accent}`}>
      <div className="book-spine" aria-hidden="true" />
      <div className="book-cover-inner">
        <div className="book-topline">
          <span className="book-genre">{project.genre || '未定类型'}</span>
          <span className="book-status">{statusLabel(project.status)}</span>
        </div>
        <h3>{project.title}</h3>
        {project.subtitle && <p className="book-subtitle">{project.subtitle}</p>}
        <p className="book-premise">{project.premise || '故事还在路上。'}</p>
        <div className="book-foot">
          <span>{project.chapters} 章</span>
          <span>{formatWords(project.words)} 字</span>
        </div>
        <span className="book-seal" aria-hidden="true">灯下</span>
      </div>
    </div>
  );
}

export function Library() {
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [writing, setWriting] = useState<WritingStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [newOpen, setNewOpen] = useState(params.get('new') === '1');

  useEffect(() => {
    let alive = true;
    setLoading(true);
    Promise.all([
      api.get<{ projects: ProjectSummary[] }>('/api/projects'),
      api.get<{ skills: Skill[] }>('/api/skills').catch(() => ({ skills: [] as Skill[] })),
      api.get<WritingStats>('/api/stats/writing?days=14').catch(() => null),
    ])
      .then(([projectData, skillData, writingData]) => {
        if (!alive) return;
        setProjects(projectData.projects);
        setSkills(skillData.skills);
        setWriting(writingData);
      })
      .catch((error) => {
        if (alive) toast.error((error as Error).message || '书房没有打开');
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [toast]);

  useEffect(() => {
    setNewOpen(params.get('new') === '1');
  }, [params]);

  function closeNew(open: boolean) {
    setNewOpen(open);
    if (!open) {
      const next = new URLSearchParams(params);
      next.delete('new');
      setParams(next, { replace: true });
    }
  }

  const totalWords = projects.reduce((sum, project) => sum + project.words, 0);
  const latest = projects[0];
  const enabledSkills = skills.filter((skill) => skill.enabled && skill.kind === 'skill').slice(0, 4);
  const displayName = user?.displayName || '写作者';
  const maxDayWords = Math.max(1, ...(writing?.days.map((day) => day.words) || [1]));

  return (
    <div className="library page-enter">
      <header className="library-head">
        <div>
          <p className="section-kicker">{todayLabel()}</p>
          <h1>{greeting()}，{displayName}。</h1>
          <p className="library-summary">
            <span>{projects.length}</span> 部作品，<span>{formatNumber(totalWords)}</span> 字，<span>{skills.filter((s) => s.enabled).length}</span> 件工具放在手边。
          </p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setNewOpen(true)}>
          <Plus size={16} />
          开一本新书
        </button>
      </header>

      {writing && (
        <div className="writing-pulse" aria-label="近十四天写作统计">
          <div className="pulse-number">
            <strong>{formatNumber(writing.todayWords)}</strong>
            <span>今天新增</span>
          </div>
          <div className="pulse-streak">
            {writing.streak > 0 ? <>连续 <strong>{writing.streak}</strong> 天</> : '今天还没落笔'}
          </div>
          <div className="pulse-bars" aria-hidden="true">
            {writing.days.map((day) => (
              <span
                key={day.day}
                className={day.day === writing.today ? 'today' : ''}
                style={{ height: `${Math.max(3, Math.round((day.words / maxDayWords) * 24))}px` }}
                title={`${day.day} · ${formatNumber(day.words)} 字`}
              />
            ))}
          </div>
          <span className="pulse-caption">近 14 天 {formatNumber(writing.totalInSpan)} 字</span>
        </div>
      )}

      {latest && (
        <section className="continue-strip">
          <div className="continue-index" aria-hidden="true">续</div>
          <div className="continue-copy">
            <span className="continue-label">上次写到</span>
            <h2>{latest.lastChapter || '第一章'}</h2>
            <p>
              《{latest.title}》 · {formatWords(latest.words)} 字 · {timeAgo(latest.updatedAt)}
            </p>
          </div>
          <button type="button" className="btn btn-ink" onClick={() => navigate(`/project/${latest.id}`)}>
            接着写
            <ArrowRight size={16} />
          </button>
        </section>
      )}

      <section className="shelf-section">
        <div className="section-line">
          <h2>书架</h2>
          <span>{loading ? '正在整理' : `${projects.length} 本`}</span>
        </div>

        {loading ? (
          <div className="book-grid">
            {[0, 1, 2].map((index) => (
              <div className="book-skeleton" key={index} aria-hidden="true">
                <div className="skeleton-cover shimmer" />
                <div className="skeleton-line shimmer" />
                <div className="skeleton-line short shimmer" />
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <EmptyState
            icon={<BookPlus size={30} />}
            title="书架还是空的"
            description="给第一本书起个名字，剩下的交给今晚。"
            action={
              <button type="button" className="btn btn-primary" onClick={() => setNewOpen(true)}>
                <Plus size={16} />
                开一本新书
              </button>
            }
          />
        ) : (
          <div className="book-grid">
            {projects.map((project) => (
              <button
                type="button"
                key={project.id}
                className="book-card"
                onClick={() => navigate(`/project/${project.id}`)}
                aria-label={`打开《${project.title}》`}
              >
                <BookCover project={project} />
                <div className="book-caption">
                  <span>{project.lastChapter || '尚未开笔'}</span>
                  <span>{timeAgo(project.updatedAt)}</span>
                </div>
              </button>
            ))}
            <button type="button" className="book-card new-book-card" onClick={() => setNewOpen(true)}>
              <div className="new-book-cover">
                <Plus size={26} />
                <span>开一本新书</span>
                <small>先有一个名字就好</small>
              </div>
              <div className="book-caption">
                <span>空白稿纸</span>
                <span>随时</span>
              </div>
            </button>
          </div>
        )}
      </section>

      <section className="desk-bottom">
        <div className="desk-tools">
          <div className="section-line">
            <h2>今晚的工具</h2>
            <Link to="/skills">管理技能 <ArrowRight size={14} /></Link>
          </div>
          {enabledSkills.length ? (
            <ul className="tool-list">
              {enabledSkills.map((skill) => (
                <li key={skill.id}>
                  <span className="tool-mark" aria-hidden="true"><Feather size={15} /></span>
                  <div>
                    <strong>{skill.name}</strong>
                    <p>{skill.description}</p>
                  </div>
                  <span className="tool-chars">{formatNumber(skill.chars)} 字</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="tool-empty">
              <Sparkles size={18} />
              <p>还没有启用的技能。去挑几件趁手的工艺，生成时带上。</p>
              <Link to="/skills">去技能库</Link>
            </div>
          )}
        </div>

        <div className="desk-note">
          <span className="desk-note-label">写在页边</span>
          <blockquote>“先把人物放到一个他非做选择不可的位置，再决定这一章要写什么。”</blockquote>
          <p>来自《场景推进》</p>
          <div className="desk-note-foot">
            <span>{formatWords(totalWords)} 字</span>
            <span>{projects.length} 部作品</span>
            <span>{skills.filter((skill) => skill.enabled).length} 件工具</span>
          </div>
        </div>
      </section>

      <NewProjectModal open={newOpen} onClose={() => closeNew(false)} onCreated={() => undefined} />
    </div>
  );
}
