import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Sparkles } from 'lucide-react';
import { api } from '../api';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useToast } from '../context/ToastContext';
import { starterCodex } from '../local/codex';
import type { ProjectSummary } from '../types';

const genres = ['玄幻', '仙侠', '都市', '科幻', '悬疑', '历史', '言情', '其他'];
const targets = [
  { value: 100_000, label: '10 万' },
  { value: 1_000_000, label: '100 万' },
  { value: 3_000_000, label: '300 万' },
  { value: 5_000_000, label: '500 万' },
];
const cadences = ['日更连载', '周更', '写完再发', '不限'];
const povs = ['第三人称限知', '第一人称', '多视角'];
const structures = ['单主角 + 少量支线', '群像多线', '双主角', '单元剧'];
const steps = ['灵感', '方向', '项目卡'];
const accents = ['tide', 'amber', 'moss', 'ink', 'plum', 'clay'];

export function NewProjectModal({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (id: string) => void;
}) {
  const navigate = useNavigate();
  const toast = useToast();
  const [step, setStep] = useState(0);
  const [idea, setIdea] = useState('');
  const [genre, setGenre] = useState('玄幻');
  const [targetWords, setTargetWords] = useState(1_000_000);
  const [cadence, setCadence] = useState('日更连载');
  const [pov, setPov] = useState('第三人称限知');
  const [structure, setStructure] = useState('单主角 + 少量支线');
  const [title, setTitle] = useState('');
  const [accent, setAccent] = useState('tide');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function reset() {
    setStep(0);
    setIdea('');
    setGenre('玄幻');
    setTargetWords(1_000_000);
    setCadence('日更连载');
    setPov('第三人称限知');
    setStructure('单主角 + 少量支线');
    setTitle('');
    setAccent('tide');
    setError('');
  }

  useEffect(() => {
    if (open) reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function create(event?: FormEvent) {
    event?.preventDefault();
    if (!title.trim() || !idea.trim()) return;
    setBusy(true);
    setError('');
    try {
      const data = await api.post<{ project: ProjectSummary }>('/api/projects', {
        title: title.trim(),
        genre,
        premise: idea.trim(),
        accent,
        targetWords,
        pov,
        structure,
        updateCadence: cadence,
      });
      const project = data.project;
      const starter = starterCodex(
        { title: project.title, premise: project.premise, genre: project.genre },
        project.id,
      );
      await api.post(`/api/projects/${project.id}/codex/batch`, starter).catch(() => null);
      toast.success(`《${project.title}》已经开笔，灯灵先放了 8 条资料`);
      reset();
      onClose();
      onCreated(project.id);
      navigate(`/project/${project.id}`);
    } catch (err) {
      setError((err as Error).message || '新书没有开成，请稍后再试');
    } finally {
      setBusy(false);
    }
  }

  const question = step === 0
    ? '先用一句话告诉我：你想写一个什么样的故事？'
    : step === 1
      ? '给它定个方向。类型、篇幅和叙事方式都会影响我后面怎么帮你。'
      : '这是你的项目卡。书名可以改，确认后我就建书房，并先放 8 条可改的资料。';

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="开一本新书"
      description="灯灵会问六件事，不会一上来让你填二十个字段。"
      size="xl"
    >
      <div className="wizard">
        <aside className="wizard-ink">
          <div className="wizard-avatar"><Sparkles size={18} /></div>
          <span className="section-kicker">灯灵 / 开书</span>
          <h3>{question}</h3>
          <p>你只需要回答现在这一步。剩下的我来整理，确认之前不会写进书房。</p>
          <div className="wizard-steps">
            {steps.map((label, index) => (
              <div key={label} className={`wizard-step ${index === step ? 'active' : ''} ${index < step ? 'done' : ''}`}>
                <span>{index < step ? <Check size={11} /> : index + 1}</span>
                {label}
              </div>
            ))}
          </div>
        </aside>

        <form className="wizard-form" onSubmit={create}>
          {step === 0 ? (
            <div className="wizard-panel">
              <label className="field">
                <span>一句话故事</span>
                <textarea
                  value={idea}
                  onChange={(event) => setIdea(event.target.value)}
                  rows={6}
                  maxLength={600}
                  autoFocus
                  placeholder="例如：一个丢了影子的邮差，在雨夜收到一封写给自己的信。"
                />
              </label>
              <p className="form-hint">不用写完整梗概。谁想要什么、什么在拦他，这两件事有就行。</p>
            </div>
          ) : step === 1 ? (
            <div className="wizard-panel wizard-direction">
              <div className="field">
                <span>类型</span>
                <div className="wizard-chips">
                  {genres.map((item) => (
                    <button key={item} type="button" className={genre === item ? 'selected' : ''} onClick={() => setGenre(item)}>{item}</button>
                  ))}
                </div>
              </div>
              <div className="field">
                <span>目标字数</span>
                <div className="wizard-chips">
                  {targets.map((item) => (
                    <button key={item.value} type="button" className={targetWords === item.value ? 'selected' : ''} onClick={() => setTargetWords(item.value)}>{item.label}</button>
                  ))}
                </div>
              </div>
              <div className="wizard-direction-grid">
                <label className="field">
                  <span>更新节奏</span>
                  <select value={cadence} onChange={(event) => setCadence(event.target.value)}>
                    {cadences.map((item) => <option key={item}>{item}</option>)}
                  </select>
                </label>
                <label className="field">
                  <span>叙事视角</span>
                  <select value={pov} onChange={(event) => setPov(event.target.value)}>
                    {povs.map((item) => <option key={item}>{item}</option>)}
                  </select>
                </label>
                <label className="field">
                  <span>结构</span>
                  <select value={structure} onChange={(event) => setStructure(event.target.value)}>
                    {structures.map((item) => <option key={item}>{item}</option>)}
                  </select>
                </label>
              </div>
            </div>
          ) : (
            <div className="wizard-panel">
              <div className="wizard-card">
                <span className="wizard-card-kicker">{genre} · {structure}</span>
                <h2>{title || '给这本书一个名字'}</h2>
                <p>{idea}</p>
                <div className="wizard-card-meta">
                  <span>{targets.find((item) => item.value === targetWords)?.label}字</span>
                  <span>{cadence}</span>
                  <span>{pov}</span>
                </div>
              </div>
              <label className="field">
                <span>书名</span>
                <input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={80} required autoFocus placeholder="现在可以改" />
              </label>
              <div className="field">
                <span>封面色</span>
                <div className="swatch-row">
                  {accents.map((item) => (
                    <button key={item} type="button" className={`swatch accent-${item} ${accent === item ? 'selected' : ''}`} onClick={() => setAccent(item)} aria-label={item} />
                  ))}
                </div>
              </div>
              <p className="form-hint">会先建第一章，并写入 8 条人物/地点/势力/物品/设定条目。你可以随时在“资料”里改。</p>
            </div>
          )}

          {error && <p className="form-error">{error}</p>}
          <footer className="wizard-actions">
            {step > 0 ? (
              <button type="button" className="btn btn-ghost" onClick={() => setStep(step - 1)} disabled={busy}>
                <ArrowLeft size={15} /> 上一步
              </button>
            ) : <span />}
            {step < 2 ? (
              <button
                type="button"
                className="btn btn-primary"
                disabled={step === 0 && !idea.trim()}
                onClick={() => setStep(step + 1)}
              >
                下一步 <ArrowRight size={15} />
              </button>
            ) : (
              <button type="submit" className="btn btn-primary" disabled={busy || !title.trim()}>
                {busy ? <Spinner size={15} /> : <Sparkles size={15} />}
                {busy ? '正在建书房…' : '建书并生成资料'}
              </button>
            )}
          </footer>
        </form>
      </div>
    </Modal>
  );
}
