import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Check,
  Download,
  HardDrive,
  History,
  KeyRound,
  LockKeyhole,
  Pencil,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  UserRound,
  Zap,
} from 'lucide-react';
import { api, getProviders } from '../api';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { Modal } from '../components/Modal';
import { Spinner } from '../components/Spinner';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatNumber } from '../lib/format';
import { clearEverything } from '../local/db';
import { clearImportRecovery, loadImportRecovery, saveImportRecovery } from '../local/recovery';
import { exportEncryptedWorkspace, exportWorkspace, importWorkspace, inspectWorkspace, isEncryptedBackup } from '../local/export';
import type { WorkspaceSummary } from '../local/export';
import { loadDemoWorkspace } from '../local/seed';
import type { Preset, Provider, RecoveryPoint } from '../types';

const kindLabel: Record<string, string> = {
  openai: 'OpenAI 兼容',
  anthropic: 'Anthropic',
  gemini: 'Gemini',
};

export function Settings() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [providers, setProviders] = useState<Provider[]>([]);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Provider | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Provider | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<Record<string, string>>({});
  const [displayName, setDisplayName] = useState(user.displayName);
  const [savingName, setSavingName] = useState(false);
  const [clearOpen, setClearOpen] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [preview, setPreview] = useState<{ file: File; passphrase: string; summary: WorkspaceSummary } | null>(null);
  const [recovery, setRecovery] = useState<RecoveryPoint | null>(null);
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [restoringRecovery, setRestoringRecovery] = useState(false);
  const [encryptedFile, setEncryptedFile] = useState<File | null>(null);
  const [passphraseOpen, setPassphraseOpen] = useState(false);
  const [passphraseMode, setPassphraseMode] = useState<'export' | 'import'>('export');
  const [passphrase, setPassphrase] = useState('');
  const [passphraseBusy, setPassphraseBusy] = useState(false);
  const [loadingDemo, setLoadingDemo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    setLoading(true);
    try {
      const data = await getProviders();
      setProviders(data.providers);
      setPresets(data.presets);
      setRecovery((await loadImportRecovery().catch(() => null)) ?? null);
    } catch (error) {
      toast.error((error as Error).message || '模型服务没有加载出来');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setDisplayName(user.displayName);
  }, [user.displayName]);

  const defaultProvider = providers.find((provider) => provider.isDefault);

  async function test(provider: Provider) {
    setTestingId(provider.id);
    setTestResult((current) => ({ ...current, [provider.id]: '' }));
    try {
      const result = await api.post<{ latencyMs: number; reply: string; model: string }>(`/api/providers/${provider.id}/test`, {});
      setTestResult((current) => ({
        ...current,
        [provider.id]: `连接正常 · ${result.latencyMs}ms${result.reply ? ` · ${result.reply.slice(0, 24)}` : ''}`,
      }));
      toast.success('模型服务连上了');
    } catch (error) {
      setTestResult((current) => ({ ...current, [provider.id]: (error as Error).message }));
      toast.error((error as Error).message || '连接失败');
    } finally {
      setTestingId(null);
    }
  }

  async function makeDefault(provider: Provider) {
    try {
      await api.patch(`/api/providers/${provider.id}`, { isDefault: true });
      await load();
      toast.success(`默认模型服务改为 ${provider.label}`);
    } catch (error) {
      toast.error((error as Error).message || '没有改成默认');
    }
  }

  async function removeProvider() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.delete(`/api/providers/${deleteTarget.id}`);
      toast.success(`已移除 ${deleteTarget.label}`);
      setDeleteTarget(null);
      await load();
      await refresh();
    } catch (error) {
      toast.error((error as Error).message || '没有移除');
    } finally {
      setDeleting(false);
    }
  }

  async function saveName(event: FormEvent) {
    event.preventDefault();
    setSavingName(true);
    try {
      await api.patch('/api/auth/me', { displayName });
      await refresh();
      toast.success('称呼已经改了');
    } catch (error) {
      toast.error((error as Error).message || '没有保存');
    } finally {
      setSavingName(false);
    }
  }

  async function clearAll() {
    setClearing(true);
    try {
      await clearEverything();
      toast.success('本机书房已清空');
      window.location.href = '/';
    } catch (error) {
      toast.error((error as Error).message || '没有清空');
    } finally {
      setClearing(false);
      setClearOpen(false);
    }
  }

  async function previewBackup(file: File, passphrase = '') {
    try {
      const summary = await inspectWorkspace(file, passphrase);
      setPreview({ file, passphrase, summary });
    } catch (error) {
      toast.error((error as Error).message || '备份没有读出来');
    }
  }

  async function importBackup(backupBeforeImport = true) {
    if (!preview) return;
    setImporting(true);
    try {
      if (backupBeforeImport) {
        await saveImportRecovery();
        await exportWorkspace();
      }
      const result = await importWorkspace(preview.file, preview.passphrase);
      await refresh();
      setRecovery((await loadImportRecovery().catch(() => null)) ?? null);
      toast.success(`已导入 ${result.projects} 部作品、${result.chapters} 章`);
      setPreview(null);
      navigate('/library');
    } catch (error) {
      toast.error((error as Error).message || '备份没有导入');
    } finally {
      setImporting(false);
    }
  }

  async function restoreRecovery() {
    if (!recovery) return;
    setRestoringRecovery(true);
    try {
      const file = new File([JSON.stringify(recovery.data)], 'import-recovery.json', { type: 'application/json' });
      const result = await importWorkspace(file);
      await refresh();
      toast.success(`已恢复导入前书房：${result.projects} 部作品、${result.chapters} 章`);
      setRestoreOpen(false);
      navigate('/library');
    } catch (error) {
      toast.error((error as Error).message || '恢复点没有恢复');
    } finally {
      setRestoringRecovery(false);
    }
  }

  async function forgetRecovery() {
    await clearImportRecovery();
    setRecovery(null);
    toast.success('导入恢复点已删除');
  }

  async function submitPassphrase() {
    setPassphraseBusy(true);
    try {
      if (passphraseMode === 'export') {
        await exportEncryptedWorkspace(passphrase);
        toast.success('加密备份已生成；密码没有保存，丢了打不开');
        setPassphraseOpen(false);
        setPassphrase('');
      } else {
        if (!encryptedFile) throw new Error('没有选择加密备份');
        await previewBackup(encryptedFile, passphrase);
        setPassphraseOpen(false);
        setPassphrase('');
        setEncryptedFile(null);
      }
    } catch (error) {
      toast.error((error as Error).message || '操作失败');
    } finally {
      setPassphraseBusy(false);
    }
  }

  async function loadDemo() {
    setLoadingDemo(true);
    try {
      const count = await loadDemoWorkspace();
      await refresh();
      toast.success(count ? `已载入 ${count} 本示例作品` : '示例书房已经在了');
      navigate('/library');
    } catch (error) {
      toast.error((error as Error).message || '示例没有载入');
    } finally {
      setLoadingDemo(false);
    }
  }

  return (
    <div className="settings-page page-enter">
      <header className="settings-head">
        <div>
          <p className="section-kicker">本机书桌</p>
          <h1>设置</h1>
          <p>没有账号，没有云端同步。作品、技能和 Key 都在这台浏览器里；公网部署只负责转发模型请求。</p>
        </div>
      </header>

      <section className="settings-section">
        <div className="settings-section-head">
          <div>
            <h2>模型服务</h2>
            <p>一个服务可以放多个模型 ID。Key 只存在当前浏览器，不会写入服务器。</p>
          </div>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              setEditing(null);
              setModalOpen(true);
            }}
          >
            <Plus size={16} />
            添加服务
          </button>
        </div>

        {loading ? (
          <div className="settings-loading"><Spinner size={18} /> 正在读配置</div>
        ) : providers.length === 0 ? (
          <div className="provider-empty">
            <span className="provider-empty-icon"><KeyRound size={24} /></span>
            <div>
              <h3>还没有接上任何模型</h3>
              <p>放入一个 DeepSeek、Claude、Gemini 或任意 OpenAI 兼容服务的 Key，就可以开始生成。</p>
            </div>
            <button
              type="button"
              className="btn btn-ink"
              onClick={() => {
                setEditing(null);
                setModalOpen(true);
              }}
            >
              添加第一个服务
            </button>
          </div>
        ) : (
          <div className="provider-list">
            {providers.map((provider) => (
              <article className="provider-row" key={provider.id}>
                <span className={`provider-mark kind-${provider.kind}`} aria-hidden="true">
                  {provider.label.slice(0, 1).toUpperCase()}
                </span>
                <div className="provider-main">
                  <div className="provider-title">
                    <h3>{provider.label}</h3>
                    {provider.isDefault && <span className="default-badge"><Check size={11} /> 默认</span>}
                    <span className="kind-badge">{kindLabel[provider.kind]}</span>
                  </div>
                  <p className="provider-url">{provider.baseUrl}</p>
                  <div className="provider-models">
                    {provider.models.slice(0, 4).map((model) => <span key={model.id}>{model.label}</span>)}
                    {provider.models.length > 4 && <span>+{provider.models.length - 4}</span>}
                  </div>
                  <p className={`provider-key ${provider.hasKey ? '' : 'missing'}`}>
                    {provider.hasKey ? `Key ${provider.keyHint}` : '尚未填写 API Key'}
                  </p>
                  {testResult[provider.id] && <p className="provider-test">{testResult[provider.id]}</p>}
                </div>
                <div className="provider-actions">
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => test(provider)} disabled={testingId === provider.id}>
                    {testingId === provider.id ? <Spinner size={14} /> : <Zap size={14} />}
                    测试
                  </button>
                  {!provider.isDefault && (
                    <button type="button" className="btn btn-quiet btn-sm" onClick={() => makeDefault(provider)}>
                      设为默认
                    </button>
                  )}
                  <button
                    type="button"
                    className="icon-button"
                    onClick={() => {
                      setEditing(provider);
                      setModalOpen(true);
                    }}
                    aria-label="编辑服务"
                    title="编辑"
                  >
                    <Pencil size={15} />
                  </button>
                  <button type="button" className="icon-button danger" onClick={() => setDeleteTarget(provider)} aria-label="移除服务" title="移除">
                    <Trash2 size={15} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
        <p className="settings-hint">
          <ShieldCheck size={14} /> Key 存在浏览器的 localStorage 里，公网代理只在请求瞬间使用，不存储、不写日志。默认服务：{defaultProvider?.label || '未设置'}。
        </p>
      </section>

      <section className="settings-section">
        <div className="settings-section-head">
          <div>
            <h2>本机资料</h2>
            <p>不需要邮箱或密码。称呼只显示在这台浏览器的书房里。</p>
          </div>
        </div>
        <div className="account-grid">
          <form className="settings-form" onSubmit={saveName}>
            <label className="field">
              <span>称呼</span>
              <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={30} required />
            </label>
            <button type="submit" className="btn btn-ghost" disabled={savingName || !displayName.trim() || displayName === user.displayName}>
              {savingName ? <Spinner size={15} /> : null}
              保存称呼
            </button>
          </form>
          <div className="account-side">
            <div className="account-line">
              <HardDrive size={17} />
              <div>
                <strong>只在这台浏览器</strong>
                <p>换设备、换浏览器或清理浏览器数据，书房不会自动跟过去。请定期导出备份。</p>
              </div>
            </div>
            <div className="account-line">
              <UserRound size={17} />
              <div>
                <strong>没有账号系统</strong>
                <p>任何人打开同一台设备的浏览器，都能看到你的本地书房；共用电脑请使用独立系统账户。</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="settings-section">
        <div className="settings-section-head">
          <div>
            <h2>本地数据</h2>
            <p>备份包含作品、章节、场景卡、Codex、时间线、文风版本、历史版本、技能和每日字数；不包含 API Key。</p>
          </div>
        </div>
        <div className="data-row">
          <button type="button" className="data-action" onClick={() => { void exportWorkspace(); }}>
            <Download size={18} />
            <div>
              <strong>导出全部备份</strong>
              <p>JSON 文件，可换设备导入</p>
            </div>
          </button>
          <button type="button" className="data-action" onClick={() => { setPassphraseMode('export'); setPassphrase(''); setPassphraseOpen(true); }}>
            <LockKeyhole size={18} />
            <div>
              <strong>导出加密备份</strong>
              <p>密码不保存；适合放网盘/U 盘</p>
            </div>
          </button>
          <button type="button" className="data-action" onClick={() => fileInputRef.current?.click()}>
            <Upload size={18} />
            <div>
              <strong>导入备份</strong>
              <p>会替换当前本地书房</p>
            </div>
          </button>
          {recovery && (
            <button type="button" className="data-action" onClick={() => setRestoreOpen(true)}>
              <History size={18} />
              <div>
                <strong>恢复导入前书房</strong>
                <p>
                  {new Date(recovery.createdAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  {' · '}
                  {recovery.data?.projects?.length || 0} 部作品 · {recovery.data?.chapters?.length || 0} 章
                </p>
              </div>
            </button>
          )}
          <button type="button" className="data-action" onClick={loadDemo} disabled={loadingDemo}>
            {loadingDemo ? <Spinner size={18} /> : <Sparkles size={18} />}
            <div>
              <strong>载入示例书房</strong>
              <p>三本示例小说与内置技能</p>
            </div>
          </button>
          <button type="button" className="data-action danger" onClick={() => setClearOpen(true)}>
            <Trash2 size={18} />
            <div>
              <strong>清空本机书房</strong>
              <p>删除全部本地作品与设置</p>
            </div>
          </button>
          <button type="button" className="data-action" onClick={() => { void load(); toast.info('刷新完成'); }}>
            <RefreshCw size={18} />
            <div>
              <strong>刷新配置</strong>
              <p>重新读取模型服务列表</p>
            </div>
          </button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".json,application/json"
          hidden
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) {
              void (async () => {
                if (await isEncryptedBackup(file)) {
                  setEncryptedFile(file);
                  setPassphraseMode('import');
                  setPassphrase('');
                  setPassphraseOpen(true);
                } else {
                  void previewBackup(file);
                }
              })();
            }
            event.target.value = '';
          }}
        />
      </section>

      <ProviderModal
        open={modalOpen}
        provider={editing}
        presets={presets}
        onClose={() => setModalOpen(false)}
        onSaved={async () => {
          setModalOpen(false);
          await load();
          await refresh();
          toast.success(editing ? '模型服务已更新' : '模型服务已接入');
        }}
      />
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="移除这个模型服务？"
        message={`${deleteTarget?.label || ''} 的地址与 Key 会从这台浏览器删除。已经生成的作品不受影响。`}
        confirmLabel="移除"
        danger
        busy={deleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={removeProvider}
      />
      <ImportPreviewModal
        open={Boolean(preview)}
        fileName={preview?.file.name || ''}
        summary={preview?.summary || null}
        busy={importing}
        onCancel={() => setPreview(null)}
        onConfirm={(backup) => { void importBackup(backup); }}
      />
      <ConfirmDialog
        open={restoreOpen}
        title="恢复导入前书房？"
        message={`会用 ${recovery?.data?.projects?.length || 0} 部作品、${recovery?.data?.chapters?.length || 0} 章的本地恢复点替换当前书房。恢复点保留，可再次恢复。`}
        confirmLabel="恢复"
        danger
        busy={restoringRecovery}
        onCancel={() => setRestoreOpen(false)}
        onConfirm={restoreRecovery}
      />
      <ConfirmDialog
        open={clearOpen}
        title="清空本机书房？"
        message="所有本地作品、章节、历史版本、技能和每日字数都会删除，不能恢复。建议先导出备份。"
        confirmLabel="清空"
        danger
        busy={clearing}
        onCancel={() => setClearOpen(false)}
        onConfirm={clearAll}
      />
      <Modal
        open={passphraseOpen}
        onClose={() => { if (!passphraseBusy) { setPassphraseOpen(false); setPassphrase(''); setEncryptedFile(null); } }}
        title={passphraseMode === 'export' ? '导出加密备份' : '打开加密备份'}
        description={passphraseMode === 'export'
          ? '用这段密码加密整份书房。密码不会保存，忘记就无法恢复。'
          : '这份备份已加密。输入当时设置的密码；不会上传到服务器。'}
        size="sm"
        footer={
          <>
            <span className="modal-foot-spacer" />
            <button type="button" className="btn btn-ghost" onClick={() => { setPassphraseOpen(false); setPassphrase(''); setEncryptedFile(null); }} disabled={passphraseBusy}>取消</button>
            <button type="button" className="btn btn-primary" onClick={() => { void submitPassphrase(); }} disabled={passphraseBusy || passphrase.length < 6}>
              {passphraseBusy ? <Spinner size={14} /> : <LockKeyhole size={14} />}
              {passphraseMode === 'export' ? '生成加密文件' : '解密并导入'}
            </button>
          </>
        }
      >
        <label className="field">
          <span>备份密码</span>
          <input
            type="password"
            value={passphrase}
            onChange={(event) => setPassphrase(event.target.value)}
            placeholder="至少 6 位"
            autoFocus
            onKeyDown={(event) => { if (event.key === 'Enter' && passphrase.length >= 6 && !passphraseBusy) { event.preventDefault(); void submitPassphrase(); } }}
          />
        </label>
        <p className="form-hint">
          AES-GCM 加密在浏览器本地完成。文件里仍然没有 API Key。密码丢了，这份备份无法恢复。
        </p>
      </Modal>
    </div>
  );
}

function ImportPreviewModal({
  open,
  fileName,
  summary,
  busy,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  fileName: string;
  summary: WorkspaceSummary | null;
  busy: boolean;
  onCancel: () => void;
  onConfirm: (backupBeforeImport: boolean) => void;
}) {
  const [backup, setBackup] = useState(true);
  useEffect(() => {
    if (open) setBackup(true);
  }, [open]);
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title="导入备份并替换当前书房？"
      description="先看清这份备份里有什么，再决定是否覆盖。"
      size="lg"
      footer={
        <>
          <span className="modal-foot-spacer" />
          <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={busy}>取消</button>
          <button type="button" className="btn btn-danger" onClick={() => onConfirm(backup)} disabled={busy || !summary}>
            {busy ? <Spinner size={14} /> : null}
            导入并替换
          </button>
        </>
      }
    >
      {summary && (
        <div className="import-preview">
          <p className="import-preview-file">{fileName}</p>
          <div className="import-preview-stats">
            <span><strong>{summary.projects}</strong> 部作品</span>
            <span><strong>{summary.chapters}</strong> 章</span>
            <span><strong>{formatNumber(summary.words)}</strong> 字</span>
            <span><strong>{summary.codex}</strong> 条 Codex</span>
            <span><strong>{summary.timeline}</strong> 条时间线</span>
            <span><strong>{summary.styleVersions}</strong> 个文风版本</span>
            <span><strong>{summary.reportSnapshots}</strong> 张体检快照</span>
            <span><strong>{summary.skills}</strong> 件技能</span>
          </div>
          <div className="import-preview-titles">
            {summary.titles.length > 0 && <p>作品：{summary.titles.join('、')}</p>}
            {summary.chapterTitles.length > 0 && <p>章节：{summary.chapterTitles.join('、')}{summary.chapters > summary.chapterTitles.length ? '…' : ''}</p>}
            {summary.codexNames.length > 0 && <p>Codex：{summary.codexNames.join('、')}{summary.codex > summary.codexNames.length ? '…' : ''}</p>}
          </div>
          <label className="import-backup-check">
            <input type="checkbox" checked={backup} onChange={(event) => setBackup(event.target.checked)} />
            <span><strong>导入前先导出当前书房</strong><em>会额外下载一份当前备份，再覆盖。</em></span>
          </label>
          <p className="form-hint">导入会清空当前 IndexedDB 里的作品、章节、技能和本地数据。取消不会改动任何内容。</p>
        </div>
      )}
    </Modal>
  );
}

function ProviderModal({
  open,
  provider,
  presets,
  onClose,
  onSaved,
}: {
  open: boolean;
  provider: Provider | null;
  presets: Preset[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [presetId, setPresetId] = useState('deepseek');
  const [label, setLabel] = useState('');
  const [baseUrl, setBaseUrl] = useState('');
  const [kind, setKind] = useState<'openai' | 'anthropic' | 'gemini'>('openai');
  const [models, setModels] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [isDefault, setIsDefault] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    if (provider) {
      setPresetId(provider.presetId || 'custom');
      setLabel(provider.label);
      setBaseUrl(provider.baseUrl);
      setKind(provider.kind);
      setModels(provider.models.map((model) => model.id).join('\n'));
      setApiKey('');
      setIsDefault(provider.isDefault);
    } else {
      const preset = presets.find((item) => item.id === 'deepseek') || presets[0];
      setPresetId(preset?.id || 'custom');
      setLabel(preset?.label || '');
      setBaseUrl(preset?.baseUrl || '');
      setKind(preset?.kind || 'openai');
      setModels(preset?.models.map((model) => model.id).join('\n') || '');
      setApiKey('');
      setIsDefault(false);
    }
    setError('');
  }, [open, provider, presets]);

  function choosePreset(preset: Preset) {
    setPresetId(preset.id);
    setLabel(preset.label);
    setBaseUrl(preset.baseUrl);
    setKind(preset.kind);
    setModels(preset.models.map((model) => model.id).join('\n'));
  }

  async function save(event?: FormEvent) {
    event?.preventDefault();
    setError('');
    if (!label.trim() || !baseUrl.trim() || !models.trim()) {
      setError('服务名称、接口地址和至少一个模型 ID 都要填');
      return;
    }
    if (!provider && !apiKey.trim() && !baseUrl.includes('127.0.0.1') && !baseUrl.includes('localhost')) {
      setError('新服务需要填写 API Key。本地 Ollama 可以留空。');
      return;
    }
    setBusy(true);
    try {
      const payload: Record<string, unknown> = {
        presetId,
        label: label.trim(),
        baseUrl: baseUrl.trim(),
        kind,
        models: models.split(/[\n,，]/).map((item) => item.trim()).filter(Boolean),
        isDefault,
      };
      if (apiKey.trim()) payload.apiKey = apiKey.trim();
      if (provider) {
        await api.patch(`/api/providers/${provider.id}`, payload);
      } else {
        await api.post('/api/providers', payload);
      }
      setApiKey('');
      onSaved();
    } catch (err) {
      setError((err as Error).message || '没有保存成功');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={provider ? '编辑模型服务' : '接入一个模型'}
      description="选一个预设，或填任何 OpenAI 兼容的接口。模型 ID 以服务商文档为准。"
      size="xl"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            取消
          </button>
          <button type="button" className="btn btn-primary" onClick={() => save()} disabled={busy}>
            {busy ? <Spinner size={16} /> : null}
            {busy ? '正在保存…' : provider ? '保存修改' : '接入'}
          </button>
        </>
      }
    >
      <form className="provider-form" onSubmit={save}>
        <div className="preset-grid" role="listbox" aria-label="模型服务预设">
          {presets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              className={`preset-card ${presetId === preset.id ? 'selected' : ''}`}
              onClick={() => choosePreset(preset)}
            >
              <span className="preset-initial">{preset.label.slice(0, 1)}</span>
              <span>
                <strong>{preset.label}</strong>
                <small>{preset.blurb}</small>
              </span>
            </button>
          ))}
        </div>

        <div className="editor-row">
          <label className="field">
            <span>显示名称</span>
            <input value={label} onChange={(event) => setLabel(event.target.value)} placeholder="我的 DeepSeek" required />
          </label>
          <label className="field">
            <span>协议</span>
            <select value={kind} onChange={(event) => setKind(event.target.value as typeof kind)}>
              <option value="openai">OpenAI 兼容</option>
              <option value="anthropic">Anthropic Messages</option>
              <option value="gemini">Google Gemini</option>
            </select>
          </label>
        </div>
        <label className="field">
          <span>接口地址</span>
          <input value={baseUrl} onChange={(event) => setBaseUrl(event.target.value)} placeholder="https://api.deepseek.com/v1" required />
          <small>OpenAI 兼容服务通常以 /v1 结尾。Anthropic 填根地址即可。</small>
        </label>
        <label className="field">
          <span>模型 ID</span>
          <textarea
            value={models}
            onChange={(event) => setModels(event.target.value)}
            rows={3}
            placeholder={'deepseek-flash\ndeepseek-v4-pro'}
            required
          />
          <small>
            每行一个。生成时可以在灯下面板切换。
            {presetId === 'deepseek' && ' DeepSeek 官方当前请用 deepseek-flash 或 deepseek-v4-pro；deepseek-v4.1-flash 会被 400 拒绝。'}
          </small>
        </label>
        <label className="field">
          <span>API Key {provider ? '（留空不修改）' : ''}</span>
          <input
            type="password"
            value={apiKey}
            onChange={(event) => setApiKey(event.target.value)}
            placeholder={provider?.hasKey ? `已保存 ${provider.keyHint}，留空保留` : 'sk-…'}
            autoComplete="off"
          />
          <small>Key 只保存在当前浏览器；公网代理只在请求瞬间使用。</small>
        </label>
        <label className="check-line">
          <input type="checkbox" checked={isDefault} onChange={(event) => setIsDefault(event.target.checked)} />
          <span>设为默认服务</span>
        </label>
        {error && <p className="form-error">{error}</p>}
      </form>
    </Modal>
  );
}
