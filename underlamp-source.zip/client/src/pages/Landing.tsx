import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, BookOpen, Feather, FolderOpen, Sparkles } from 'lucide-react';
import { Brand } from '../components/Brand';
import { Spinner } from '../components/Spinner';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { hasDemoWorkspace, loadDemoWorkspace } from '../local/seed';

const sampleParagraphs = [
  '雨停的时候，巷子里的水还没退。她把伞收起来，站在门口，先听见屋里的钟停了。',
  '她没有立刻推门。门上贴着一张旧封条，日期是七年前，字迹却很新。',
];

export function Landing() {
  const navigate = useNavigate();
  const { loading } = useAuth();
  const toast = useToast();
  const [demoBusy, setDemoBusy] = useState(false);

  async function enterDemo() {
    setDemoBusy(true);
    try {
      if (await hasDemoWorkspace()) {
        toast.info('示例书房已经在书架上');
      } else {
        const count = await loadDemoWorkspace();
        toast.success(count ? `已载入 ${count} 本示例作品` : '示例书房已就绪');
      }
      navigate('/library');
    } catch (error) {
      toast.error((error as Error).message || '示例书房暂时进不去');
    } finally {
      setDemoBusy(false);
    }
  }

  return (
    <div className="landing">
      <div className="landing-glow" aria-hidden="true" />
      <header className="landing-header">
        <Brand />
        <nav className="landing-nav" aria-label="主导航">
          <a href="#how">怎么工作</a>
          <a href="#skills">技能</a>
          <button type="button" className="landing-login" onClick={() => navigate('/settings')}>
            本地保存
          </button>
          <button type="button" className="btn btn-lamp btn-sm" onClick={() => navigate('/library')}>
            进入书房
          </button>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="hero-kicker reveal reveal-1">给长篇小说的一张书桌</p>
            <h1 className="reveal reveal-2">
              长夜有灯，
              <br />
              故事有岸。
            </h1>
            <p className="hero-sub reveal reveal-3">
              把设定、人物、章节和写作技能放在同一张书桌上。接上你信任的模型，从第一句写到最后一章。
            </p>
            <div className="hero-actions reveal reveal-4">
              <button type="button" className="btn btn-lamp btn-lg" onClick={() => navigate('/library?new=1')} disabled={loading}>
                开一本新书
                <ArrowRight size={17} />
              </button>
              <button type="button" className="btn btn-quiet btn-lg" onClick={enterDemo} disabled={demoBusy || loading}>
                {demoBusy ? <Spinner size={16} /> : <FolderOpen size={17} />}
                载入示例书房
              </button>
            </div>
            <p className="hero-note reveal reveal-5">无需账号，数据只保存在这台浏览器。自带 API Key，支持 DeepSeek、Claude、Gemini 与任意 OpenAI 兼容服务。</p>
          </div>

          <div className="hero-paper-wrap reveal reveal-3" aria-label="稿纸示例">
            <div className="hero-lamp" aria-hidden="true" />
            <article className="hero-paper">
              <div className="paper-margin" aria-hidden="true" />
              <div className="paper-head">
                <span>示例开篇</span>
                <span>第一章 · 雨停</span>
              </div>
              <h2>潮痕</h2>
              {sampleParagraphs.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
              <p className="paper-fade">母亲给一个住在她自己家里的人，写了二十一年信。</p>
              <span className="paper-seal" aria-hidden="true">
                灯下
              </span>
              <span className="paper-folio">01</span>
              <span className="paper-note" aria-hidden="true">
                一个不该
                <br />
                存在的人。
              </span>
            </article>
            <div className="hero-paper-shadow" aria-hidden="true" />
          </div>
        </section>

        <section className="workflow" id="how">
          <div className="section-intro">
            <p className="section-kicker">写作不是一次问答</p>
            <h2>一张书桌，三件事。</h2>
          </div>
          <div className="workflow-steps">
            <article>
              <span className="step-number">01</span>
              <h3>把设定摆好</h3>
              <p>世界、人物、大纲、禁忌。每次生成都带上它们，模型不必从零猜你的故事。</p>
            </article>
            <article>
              <span className="step-number">02</span>
              <h3>装上你的工艺</h3>
              <p>上传 SKILL.md、Word、PDF，或整包技能。开篇、对话、去 AI 味，用你自己的标准。</p>
            </article>
            <article>
              <span className="step-number">03</span>
              <h3>接着写下去</h3>
              <p>续写、润色、拆章、对谈。选中一段改一段，写完的每个字都留在你的浏览器里。</p>
            </article>
          </div>
        </section>

        <section className="craft" id="skills">
          <div className="craft-copy">
            <p className="section-kicker">技能是可携带的手艺</p>
            <h2>你积累的写作方法，不该锁在别人的产品里。</h2>
            <p>
              灯下把技能当成一等公民：一份 Markdown、一份编辑规范、一本你想模仿的语气样张，都可以随时装进书桌。生成时自己决定带哪几件。
            </p>
            <ul className="craft-list">
              <li>
                <Feather size={17} />
                <span>支持 `.md`、`.txt`、`.docx`、`.pdf`，以及带 `SKILL.md` 的整包 zip。</span>
              </li>
              <li>
                <BookOpen size={17} />
                <span>技能与资料分开：前者是工艺要求，后者只作为事实和语感参考。</span>
              </li>
              <li>
                <Sparkles size={17} />
                <span>内置十件中文长篇工艺，开箱可用，也能改成你自己的版本。</span>
              </li>
            </ul>
          </div>
          <div className="skill-stack" aria-label="技能示例">
            <div className="skill-sheet skill-sheet-1">
              <span>SKILL / 01</span>
              <h3>开篇三章</h3>
              <p>先给承诺，再给缺口。第一章结束时，至少有一件事回不去了。</p>
            </div>
            <div className="skill-sheet skill-sheet-2">
              <span>SKILL / 07</span>
              <h3>去 AI 味</h3>
              <p>删掉每段最后的升华。让具体的动作替人物说话。</p>
            </div>
            <div className="skill-sheet skill-sheet-3">
              <span>REFERENCE</span>
              <h3>示例语气样张</h3>
              <p>短句。具体的物象。不解释情绪。章末停在局面改变的一瞬。</p>
            </div>
          </div>
        </section>

        <section className="closing">
          <div>
            <p className="section-kicker">今晚</p>
            <h2>先写第一章。</h2>
          </div>
          <button type="button" className="btn btn-lamp btn-lg" onClick={() => navigate('/library?new=1')}>
            开一间自己的书房
            <ArrowRight size={17} />
          </button>
        </section>
      </main>

      <footer className="landing-footer">
        <Brand compact />
        <p>本地优先。数据在浏览器。随时可以导出备份。</p>
        <span>Underlamp 2026</span>
      </footer>
    </div>
  );
}
