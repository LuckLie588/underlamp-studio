export function Spinner({ size = 18, className = '' }: { size?: number; className?: string }) {
  return <span className={`spinner ${className}`} style={{ width: size, height: size }} aria-hidden="true" />;
}

export function FullPageLoader({ label = '正在铺开稿纸' }: { label?: string }) {
  return (
    <div className="page-loader">
      <span className="page-loader-mark" aria-hidden="true" />
      <p>{label}</p>
    </div>
  );
}
