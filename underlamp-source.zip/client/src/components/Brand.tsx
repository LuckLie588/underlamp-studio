import type { CSSProperties } from 'react';

export function LampMark({ size = 30, className = '' }: { size?: number; className?: string }) {
  return (
    <svg
      className={`lamp-mark ${className}`}
      width={size}
      height={size}
      viewBox="0 0 36 36"
      fill="none"
      aria-hidden="true"
    >
      <path d="M11.2 15.4 14.8 7.8h6.4l3.6 7.6H11.2Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <circle cx="18" cy="12.1" r="2.15" fill="var(--lamp, #d7a552)" />
      <path d="M18 15.4V27.2M11.8 29.2h12.4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M14.2 32h7.6" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" opacity=".38" />
    </svg>
  );
}

export function Brand({
  compact = false,
  className = '',
  style,
}: {
  compact?: boolean;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <span className={`brand ${compact ? 'brand-compact' : ''} ${className}`} style={style}>
      <LampMark size={compact ? 24 : 30} />
      <span className="brand-type">
        <strong>灯下</strong>
        {!compact && <em>Underlamp</em>}
      </span>
    </span>
  );
}
