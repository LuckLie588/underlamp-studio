import type {
  AgentResult,
  AiDone,
  AiMeta,
  AiStreamPayload,
  MeResponse,
  Preset,
  Provider,
} from './types';
import { buildExtractPayload, buildStreamPayload, previewLocalContext } from './local/ai';
import { localRequest } from './local/router';
import { getLocalPresets, getLocalProviders, getProviderConfig } from './local/providers';

export class ApiError extends Error {
  status: number;
  details?: unknown;

  constructor(message: string, status = 500, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

type RequestOptions = {
  method?: string;
  body?: unknown;
  signal?: AbortSignal;
};

export async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  if (path.startsWith('/api/ai/')) {
    throw new ApiError('这个接口需要专用的流式调用', 400);
  }
  if (path.startsWith('/api/tools/')) {
    throw new ApiError('这个接口需要文件或导出上下文', 400);
  }
  try {
    return await localRequest<T>(path, { method: options.method, body: options.body });
  } catch (error) {
    const status = Number((error as { status?: number }).status || 400);
    throw new ApiError((error as Error).message || '本地操作失败', status);
  }
}

export const api = {
  get: <T>(path: string, signal?: AbortSignal) => request<T>(path, { signal }),
  post: <T>(path: string, body?: unknown, signal?: AbortSignal) =>
    request<T>(path, { method: 'POST', body: body ?? {}, signal }),
  patch: <T>(path: string, body?: unknown) => request<T>(path, { method: 'PATCH', body: body ?? {} }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
};

export async function uploadSkillFiles(
  files: File[],
  kind: 'auto' | 'skill' | 'reference',
  onProgress?: (percent: number) => void,
): Promise<{ skills: any[]; errors: Array<{ filename: string; message: string }> }> {
  const form = new FormData();
  for (const file of files) form.append('files', file);
  const docs = await new Promise<any[]>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/tools/extract');
    xhr.setRequestHeader('x-requested-with', 'underlamp');
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && onProgress) onProgress(Math.round((event.loaded / event.total) * 90));
    };
    xhr.onload = () => {
      let data: any = null;
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        data = null;
      }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data?.docs || []);
      else reject(new ApiError(data?.error || `文件解析失败（${xhr.status}）`, xhr.status));
    };
    xhr.onerror = () => reject(new ApiError('网络连接中断，文件没有上传完成'));
    xhr.send(form);
  });
  onProgress?.(95);
  const skills: any[] = [];
  const errors: Array<{ filename: string; message: string }> = [];
  for (const doc of docs) {
    try {
      const saved = await request<{ skill: any }>('/api/skills/text', {
        method: 'POST',
        body: {
          name: doc.name,
          description: doc.description,
          tags: doc.tags,
          content: doc.content,
          kind: kind === 'auto' ? doc.kind : kind,
          collection: doc.collection || '',
          sourceFilename: doc.sourceFilename,
        },
      });
      skills.push(saved.skill);
    } catch (error) {
      errors.push({ filename: doc.sourceFilename || doc.name, message: (error as Error).message });
    }
  }
  onProgress?.(100);
  return { skills, errors };
}

export type StreamHandlers = {
  onMeta?: (meta: AiMeta) => void;
  onDelta?: (delta: { text: string; reasoning: string }) => void;
  onDone?: (done: AiDone) => void;
  onError?: (error: ApiError) => void;
};

function parseSseBlock(block: string): { event: string; data: string } | null {
  const lines = block.split(/\r?\n/);
  let event = 'message';
  const data: string[] = [];
  for (const line of lines) {
    if (line.startsWith('event:')) event = line.slice(6).trim();
    else if (line.startsWith('data:')) data.push(line.slice(5).trimStart());
  }
  if (!data.length) return null;
  return { event, data: data.join('\n') };
}

export async function streamSse(
  path: string,
  payload: unknown,
  handlers: StreamHandlers,
  signal?: AbortSignal,
): Promise<void> {
  const response = await fetch(path, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-requested-with': 'underlamp',
    },
    body: JSON.stringify(payload),
    signal,
  });
  if (!response.ok) {
    let message = `生成请求失败（${response.status}）`;
    try {
      const data = await response.json();
      message = data?.error || message;
    } catch {
      /* ignore */
    }
    throw new ApiError(message, response.status);
  }
  if (!response.body) throw new ApiError('浏览器没有收到流式响应');

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let streamError: ApiError | null = null;
  let gotDone = false;

  const dispatch = (block: string) => {
    const parsed = parseSseBlock(block);
    if (!parsed) return;
    let data: any;
    try {
      data = JSON.parse(parsed.data);
    } catch {
      return;
    }
    if (parsed.event === 'meta') handlers.onMeta?.(data as AiMeta);
    else if (parsed.event === 'delta') handlers.onDelta?.(data);
    else if (parsed.event === 'done') {
      gotDone = true;
      handlers.onDone?.(data as AiDone);
    } else if (parsed.event === 'error') {
      streamError = new ApiError(data?.message || '生成失败', data?.status || 500);
      handlers.onError?.(streamError);
    }
  };

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const blocks = buffer.split(/\r?\n\r?\n/);
      buffer = blocks.pop() || '';
      for (const block of blocks) dispatch(block);
    }
    buffer += decoder.decode();
    if (buffer.trim()) dispatch(buffer);
  } catch (error) {
    if ((error as Error)?.name === 'AbortError') throw error;
    throw error instanceof ApiError ? error : new ApiError((error as Error)?.message || '流式连接中断');
  }
  if (streamError) throw streamError;
  if (!gotDone) throw new ApiError('生成连接提前中断，结果可能不完整。请重试。', 502);
}

export async function streamAi(payload: AiStreamPayload, handlers: StreamHandlers, signal?: AbortSignal) {
  const built = await buildStreamPayload(payload);
  return streamSse('/api/ai/stream', built, handlers, signal);
}

export async function streamExtract(
  payload: { projectId: string; providerId: string; model: string; contextChars?: number },
  handlers: StreamHandlers,
  signal?: AbortSignal,
) {
  const built = await buildExtractPayload(payload.projectId);
  const provider = getProviderConfig(payload.providerId);
  return streamSse(
    '/api/ai/extract',
    {
      ...built,
      provider: {
        label: provider.label,
        kind: provider.kind,
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
      },
      model: payload.model,
      contextChars: payload.contextChars || 30_000,
    },
    handlers,
    signal,
  );
}

export async function previewContext(payload: AiStreamPayload) {
  return previewLocalContext(payload);
}

export async function completeAgent({
  providerId,
  model,
  system,
  messages,
  temperature = 0.35,
  maxTokens = 4000,
}: {
  providerId: string;
  model: string;
  system: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  temperature?: number;
  maxTokens?: number;
}): Promise<AgentResult> {
  const provider = getProviderConfig(providerId);
  const response = await fetch('/api/ai/agent', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify({
      provider: {
        label: provider.label,
        kind: provider.kind,
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
      },
      model,
      system,
      messages,
      temperature,
      maxTokens,
    }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(data?.error || '灯灵没有回应', response.status);
  return data as AgentResult;
}

export async function loadMe(): Promise<MeResponse> {
  return request<MeResponse>('/api/auth/me');
}

export async function getPresets(): Promise<{ presets: Preset[]; note: string }> {
  return getLocalPresets();
}

export async function getProviders(): Promise<{ providers: Provider[]; presets: Preset[]; migrations?: string[] }> {
  return getLocalProviders();
}

export type { AiStreamPayload };
