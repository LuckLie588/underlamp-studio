import type { ProjectSummary, Skill } from '../types';
import { getAll, getAllByIndex, putMany, clearStore, type ChapterRow, type ProjectRow, type SkillRow, type StatRow, type VersionRow } from './db';
import { restoreBuiltinSkills } from './seed';
import { decryptWorkspace, encryptWorkspace } from './crypto';
import { countWords } from '../lib/format';

function safeName(value: string, fallback = 'manuscript') {
  return String(value || '').replace(/[\\/:*?"<>|\r\n]/g, '').trim().slice(0, 60) || fallback;
}

export function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function downloadText(filename: string, text: string, type = 'text/plain;charset=utf-8') {
  downloadBlob(filename, new Blob([text], { type }));
}

export async function downloadSkill(skill: Skill) {
  const frontmatter = `---\nname: ${skill.name}\ndescription: ${skill.description}\ntags: [${(skill.tags || []).join(', ')}]\n---\n\n`;
  downloadText(`${safeName(skill.name, 'skill')}.md`, frontmatter + (skill.content || ''), 'text/markdown;charset=utf-8');
}

function projectMarkdown(project: ProjectRow, chapters: ChapterRow[], withBible = true) {
  const lines = [
    `# ${project.title}`,
    project.subtitle ? `> ${project.subtitle}` : '',
    '',
    project.genre ? `类型：${project.genre}` : '',
    project.premise ? `故事：${project.premise}` : '',
    '',
    '---',
    '',
  ];
  for (const chapter of chapters) {
    lines.push(`## ${chapter.title}`, '');
    lines.push(chapter.content.trim() || '（本章尚未落笔）', '');
    lines.push('---', '');
  }
  if (withBible) {
    lines.push(
      '# 设定集',
      '',
      '## 世界',
      project.bible.world || '（未填写）',
      '',
      '## 人物',
      project.bible.characters || '（未填写）',
      '',
      '## 大纲',
      project.bible.outline || '（未填写）',
      '',
      '## 规则',
      project.bible.rules || '（未填写）',
      '',
      '## 主题',
      project.bible.themes || '（未填写）',
    );
  }
  return lines.join('\n');
}

function projectText(project: ProjectRow, chapters: ChapterRow[]) {
  const lines = [project.title, project.subtitle || '', '', project.premise || ''];
  for (const chapter of chapters) {
    lines.push('', chapter.title, '', chapter.content.trim() || '（本章尚未落笔）');
  }
  return lines.join('\n');
}

export async function loadProjectForExport(projectId: string) {
  const projects = await getAll<ProjectRow>('projects');
  const chapters = await getAllByIndex<ChapterRow>('chapters', 'projectId', projectId);
  const project = projects.find((item) => item.id === projectId);
  if (!project) throw new Error('作品不存在');
  return { project, chapters: chapters.sort((a, b) => a.sort - b.sort) };
}

export async function downloadProject(projectId: string, format: 'md' | 'txt' | 'json' | 'docx') {
  const { project, chapters } = await loadProjectForExport(projectId);
  const base = safeName(project.title);
  if (format === 'md') {
    downloadText(`${base}.md`, projectMarkdown(project, chapters), 'text/markdown;charset=utf-8');
    return;
  }
  if (format === 'txt') {
    downloadText(`${base}.txt`, projectText(project, chapters), 'text/plain;charset=utf-8');
    return;
  }
  if (format === 'json') {
    downloadText(
      `${base}.json`,
      JSON.stringify(
        {
          format: 'underlamp-project',
          version: 1,
          exportedAt: new Date().toISOString(),
          project,
          chapters,
        },
        null,
        2,
      ),
      'application/json;charset=utf-8',
    );
    return;
  }
  const response = await fetch('/api/tools/docx', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify({ project, chapters }),
  });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data?.error || 'Word 导出失败');
  }
  downloadBlob(`${base}.docx`, await response.blob());
}

export async function collectWorkspaceData() {
  const [projects, chapters, versions, skills, stats, codex, timeline, styleVersions, reportSnapshots] = await Promise.all([
    getAll<ProjectRow>('projects'),
    getAll<ChapterRow>('chapters'),
    getAll<VersionRow>('versions'),
    getAll<SkillRow>('skills'),
    getAll<StatRow>('stats'),
    getAll('codex'),
    getAll('timeline'),
    getAll('styleVersions'),
    getAll('reportSnapshots'),
  ]);
  return {
    format: 'underlamp-local-backup',
    version: 4,
    exportedAt: new Date().toISOString(),
    note: 'API Key 不包含在备份中，换设备后需要重新填写。',
    projects,
    chapters,
    versions,
    skills: skills.map((skill) => ({ ...skill })),
    stats,
    codex,
    timeline,
    styleVersions,
    reportSnapshots,
  };
}

export async function exportWorkspace() {
  const data = await collectWorkspaceData();
  downloadText(
    `underlamp-backup-${new Date().toISOString().slice(0, 10)}.json`,
    JSON.stringify(data, null, 2),
    'application/json;charset=utf-8',
  );
}

export async function exportEncryptedWorkspace(passphrase: string) {
  const data = await collectWorkspaceData();
  const encrypted = await encryptWorkspace(data, passphrase);
  downloadText(
    `underlamp-encrypted-${new Date().toISOString().slice(0, 10)}.json`,
    JSON.stringify(encrypted, null, 2),
    'application/json;charset=utf-8',
  );
}

export async function isEncryptedBackup(file: File) {
  try {
    const data = JSON.parse(await file.text());
    return data?.format === 'underlamp-encrypted-backup';
  } catch {
    return false;
  }
}

export interface WorkspaceSummary {
  format: string;
  version: number;
  exportedAt: string;
  projects: number;
  chapters: number;
  skills: number;
  codex: number;
  timeline: number;
  styleVersions: number;
  reportSnapshots: number;
  words: number;
  titles: string[];
  chapterTitles: string[];
  codexNames: string[];
  snapshotNames: string[];
}

async function readWorkspace(file: File, passphrase = '') {
  const text = await file.text();
  let data: any;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('这不是有效的 JSON 备份文件');
  }
  if (data?.format === 'underlamp-encrypted-backup') {
    data = await decryptWorkspace(data, passphrase);
  }
  if (!data || !Array.isArray(data.projects) || !Array.isArray(data.chapters)) {
    throw new Error('备份格式不正确，缺少作品或章节');
  }
  return data;
}

export async function inspectWorkspace(file: File, passphrase = ''): Promise<WorkspaceSummary> {
  const data = await readWorkspace(file, passphrase);
  const words = data.chapters.reduce((sum: number, chapter: any) => sum + (Number(chapter.wordCount) || countWords(chapter.content || '')), 0);
  return {
    format: String(data.format || 'unknown'),
    version: Number(data.version || 0),
    exportedAt: String(data.exportedAt || ''),
    projects: data.projects.length,
    chapters: data.chapters.length,
    skills: Array.isArray(data.skills) ? data.skills.length : 0,
    codex: Array.isArray(data.codex) ? data.codex.length : 0,
    timeline: Array.isArray(data.timeline) ? data.timeline.length : 0,
    styleVersions: Array.isArray(data.styleVersions) ? data.styleVersions.length : 0,
    reportSnapshots: Array.isArray(data.reportSnapshots) ? data.reportSnapshots.length : 0,
    words,
    titles: data.projects.slice(0, 5).map((project: any) => String(project.title || '未命名')),
    chapterTitles: data.chapters.slice(0, 8).map((chapter: any) => String(chapter.title || '未命名')),
    codexNames: (Array.isArray(data.codex) ? data.codex : []).slice(0, 8).map((entry: any) => String(entry.name || '未命名')),
    snapshotNames: (Array.isArray(data.reportSnapshots) ? data.reportSnapshots : []).slice(0, 5).map((snapshot: any) => String(snapshot.name || '未命名快照')),
  };
}

export async function importWorkspace(file: File, passphrase = '') {
  const data = await readWorkspace(file, passphrase);
  const projects: ProjectRow[] = data.projects.map((project: any) => ({
    ...project,
    bible: project.bible || { world: '', characters: '', outline: '', rules: '', themes: '', updatedAt: Date.now() },
  }));
  const chapters: ChapterRow[] = data.chapters.map((chapter: any) => ({
    ...chapter,
    beats: chapter.beats || '',
    wordCount: chapter.wordCount || countWords(chapter.content || ''),
  }));
  await Promise.all(['projects', 'chapters', 'versions', 'skills', 'stats', 'codex', 'timeline', 'styleVersions', 'reportSnapshots'].map((store) => clearStore(store as any)));
  await putMany('projects', projects);
  await putMany('chapters', chapters);
  if (Array.isArray(data.versions)) await putMany('versions', data.versions);
  if (Array.isArray(data.codex)) await putMany('codex', data.codex);
  if (Array.isArray(data.timeline)) await putMany('timeline', data.timeline);
  if (Array.isArray(data.styleVersions)) await putMany('styleVersions', data.styleVersions);
  if (Array.isArray(data.reportSnapshots)) await putMany('reportSnapshots', data.reportSnapshots);
  if (Array.isArray(data.skills)) {
    const skills: SkillRow[] = data.skills.map((skill: any) => ({
      ...skill,
      tags: Array.isArray(skill.tags) ? skill.tags : [],
      builtin: Boolean(skill.builtin),
      enabled: skill.enabled !== false,
    }));
    await putMany('skills', skills);
  }
  if (!Array.isArray(data.skills) || !data.skills.length) await restoreBuiltinSkills();
  if (Array.isArray(data.stats)) await putMany('stats', data.stats);
  return { projects: projects.length, chapters: chapters.length };
}

export function projectExportFilename(project: ProjectSummary) {
  return safeName(project.title);
}
