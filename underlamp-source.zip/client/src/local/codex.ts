import type { CodexEntry, CodexKind, TimelineEvent } from '../types';
import type { Bible } from '../types';

const KIND_HINTS = `kind 只能是 character / location / faction / item / concept。
character 需要 name, aliases, role, summary, desire, fear, secret, voice, state, relationships（name/label/note）。
其他类型需要 name, aliases, summary, details。
timeline 需要 storyTime, title, description, participants, consequences。`;

export function emptyCodexEntry(projectId: string, kind: CodexKind = 'character'): CodexEntry {
  const t = Date.now();
  return {
    id: '',
    projectId,
    kind,
    name: '',
    aliases: [],
    role: '',
    summary: '',
    details: '',
    desire: '',
    fear: '',
    secret: '',
    voice: '',
    state: '',
    relationships: [],
    tags: [],
    pinned: false,
    firstChapterId: null,
    lastChapterId: null,
    createdAt: t,
    updatedAt: t,
  };
}

export function starterCodex(project: { title: string; premise: string; genre: string }, projectId: string) {  const idea = project.premise || `${project.title}的故事`;
  const rows: Array<Partial<CodexEntry> & { kind: CodexKind; name: string }> = [
    {
      kind: 'character',
      name: '主角',
      role: '视角人物',
      summary: idea.slice(0, 180),
      desire: '得到自己想要的东西，并活下来',
      fear: '失去自己真正重视的人或东西',
      secret: '身上有一个不能让族人知道的秘密',
      voice: '短句，少解释，先观察再行动',
      state: '故事开始时，处境不利，但还没有被逼到绝路',
      aliases: [],
      pinned: true,
    },
    { kind: 'character', name: '对手', role: '主要阻力', summary: '掌握主角命运的人，表面善意，实际有自己的账。', pinned: false },
    { kind: 'character', name: '同伴', role: '同行者', summary: '和主角互相需要，但目标并不完全一致。', pinned: false },
    { kind: 'location', name: '主城', role: '', summary: '故事开始的地方，规则森严，资源集中在少数人手里。', pinned: false },
    { kind: 'location', name: '禁地', role: '', summary: '所有人都不愿提起的地方，埋着故事真正的旧账。', pinned: false },
    { kind: 'faction', name: '主家', role: '', summary: '表面维持秩序，实际用旧规则吃人。', pinned: false },
    { kind: 'item', name: '关键物件', role: '', summary: '一件看起来不起眼的东西，能把主角和旧事连起来。', pinned: false },
    { kind: 'concept', name: '核心规则', role: '', summary: '这个世界最不能违反的一条规则，违反的人都要付代价。', pinned: false },
  ];
  return {
    entries: rows.map((row) => ({
      ...emptyCodexEntry(projectId, row.kind),
      ...row,
      summary: String(row.summary || '').slice(0, 1200),
    })) as CodexEntry[],
    timeline: [] as TimelineEvent[],
  };
}

export function extractCodexFromBible(
  project: { title: string; premise: string; genre: string },
  bible: Bible,
  projectId: string,
) {
  const world = `${bible.world}\n${bible.outline}\n${bible.characters}`;
  const sentenceFor = (term: string) => {
    const sentence = world.split(/[。！？\n]/).find((item) => item.includes(term));
    return (sentence || '').trim().slice(0, 240);
  };
  const seen = new Set<string>();
  const entries: any[] = [];
  const add = (kind: CodexKind, name: string, summary: string, details = '', pinned = false) => {
    const clean = name.replace(/^[在从到进去出回了的]+/, '').trim();
    if (!clean || clean.length < 2 || clean.length > 24 || seen.has(`${kind}:${clean}`)) return;
    seen.add(`${kind}:${clean}`);
    entries.push({
      ...emptyCodexEntry(projectId, kind),
      kind,
      name: clean,
      summary: summary || `从现有设定整理：${clean}`,
      details: details || '从现有 Bible 自动整理，待作者确认。',
      pinned,
    });
  };

  const characterLines = String(bible.characters || '').split(/\r?\n/);
  for (const line of characterLines) {
    const match = line.match(/^\s*([^：:\n]{2,16})[：:]\s*(.+)$/);
    if (!match || /^[#\-*]/.test(line.trim())) continue;
    const name = match[1].replace(/[（(].*?[）)]/g, '').trim();
    if (['人物', '角色', '设定'].includes(name)) continue;
    add('character', name, match[2].slice(0, 240), match[2], entries.length === 0);
  }

  const places = [...world.matchAll(/([\u4e00-\u9fa5]{2,6}(?:洲|州|城|谷|山|殿|堂|院|楼|阁|海|原|宫|洞|塔|镇|村))/g)]
    .map((match) => match[1].trim())
    .filter((name) => name.length >= 2 && name.length <= 8)
    .filter((name) => !/^(这里|那里|哪里|进门|出门|回门|大门|房门|院门|山门)$/.test(name))
    .filter((name) => !/氏|族|长老|先祖|世代|守门|是|表面|大族|带着|离开|来到|前往|回到|赶往/.test(name));
  for (const place of [...new Set(places)].slice(0, 12)) add('location', place, sentenceFor(place));

  const cleanTerm = (name: string) => name
    .replace(/^(?:一把|一柄|一盏|一枚|一张|那|这|他的|她的|我的|捡起|拿起|看见|发现|取出|掏出|摸出)/, '')
    .trim();
  const terms = (pattern: RegExp, max = 8) => [...new Set(
    [...world.matchAll(pattern)]
      .map((match) => cleanTerm(match[1] || ''))
      .filter((name) => name.length >= 2 && name.length <= 8)
      .filter((name) => !/^(?:他们|她们|我们|你们|自己|什么|这个|那个|一个|没有|已经|还是|就是)/.test(name)),
  )].slice(0, max);

  for (const term of terms(/([\u4e00-\u9fa5]{2,8}(?:宗|门|派|族|会|盟|堂|阁|殿|帮|教|军|朝|国))/g)) {
    add('faction', term, sentenceFor(term));
  }

  for (const term of terms(/([\u4e00-\u9fa5]{1,6}(?:剑|刀|枪|弓|符|印|镜|珠|丹|书|琴|笛|铃|钉|针|环|镯|盘|袋|令|牌|旗|图|卷|匣|鼎|炉|塔|碑|灯|盏|杯|壶|扇|伞|甲|袍))/g)) {
    add('item', term, sentenceFor(term));
  }

  for (const term of terms(/([\u4e00-\u9fa5]{1,6}(?:之道|法则|境界|体系|心法|功法|术|诀|功|灵息|煞气|异象|规则))/g)) {
    add('concept', term, sentenceFor(term));
  }

  const timeline: any[] = [];
  for (const match of String(bible.outline || '').matchAll(/第[一二三四五六七八九十百\d]+章[《<]?([^》>：:\n]+)[》>]?[：:]\s*([^\n]+)/g)) {
    const description = match[2].trim();
    timeline.push({
      id: '',
      projectId,
      storyTime: '',
      title: `第${match[0].match(/^第[一二三四五六七八九十百\d]+章/)?.[0]?.replace(/^第/, '').replace(/章$/, '') || ''}章 ${match[1].trim()}`,
      description,
      participants: entries
        .filter((entry) => entry.kind === 'character' && description.includes(entry.name))
        .map((entry) => entry.name),
      chapterId: null,
      consequences: '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  }

  return {
    entries: entries.slice(0, 30),
    timeline: timeline.slice(0, 12),
  };
}

export async function scanCodexWithAgent({
  project,
  bible,
  chapters,
  providerId,
  model,
}: {
  project: { title: string; premise: string; genre: string };
  bible: Bible;
  chapters: Array<{ title: string; content: string; summary?: string }>;
  providerId: string;
  model: string;
}) {
  const { completeAgent } = await import('../api');
  const source = [
    `书名：${project.title}`,
    `类型：${project.genre}`,
    `一句话故事：${project.premise}`,
    `世界：${bible.world}`,
    `人物：${bible.characters}`,
    `大纲：${bible.outline}`,
    `规则：${bible.rules}`,
    `主题：${bible.themes}`,
    ...chapters.slice(0, 10).map((chapter) => `\n【${chapter.title}】\n${chapter.content.slice(0, 12000)}`),
  ].join('\n');
  const result = await completeAgent({
    providerId,
    model,
    system: `你是中文长篇小说的资料编辑。请从作者已有文本中提取可复用的 Codex。只输出一个合法 JSON 对象，不要 Markdown 代码块，不要解释。\nJSON 结构：{"entries":[...],"timeline":[...]}。\n${KIND_HINTS}\n最多 20 个 entries、12 个 timeline。不要编造文本中没有依据的内容；不确定的放 details 并标注“待确认”。`,
    messages: [{ role: 'user', content: `请整理以下作品资料：\n${source}` }],
    temperature: 0.2,
    maxTokens: 7000,
  });
  return parseCodexJson(result.text);
}

function parseCodexJson(text: string) {
  const raw = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('灯灵没有返回结构化资料，请重试');
  let data: any;
  try {
    data = JSON.parse(raw.slice(start, end + 1));
  } catch {
    throw new Error('灯灵返回的 JSON 不完整，请重试');
  }
  const entries = Array.isArray(data.entries) ? data.entries : [];
  const timeline = Array.isArray(data.timeline) ? data.timeline : [];
  return {
    entries: entries
      .filter((entry: any) => entry && entry.name && ['character', 'location', 'faction', 'item', 'concept'].includes(entry.kind))
      .slice(0, 20),
    timeline: timeline.filter((event: any) => event && event.title).slice(0, 12),
  };
}
