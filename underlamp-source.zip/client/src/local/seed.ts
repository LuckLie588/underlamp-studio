import { countWords } from '../lib/format';
import { newId } from './id';
import { demoProjects, demoReference } from './demo';
import { dayKey, shiftDayKey } from './time';
import {
  getAll,
  getMeta,
  put,
  putMany,
  setMeta,
  type ChapterRow,
  type ProjectRow,
  type SkillRow,
  type StatRow,
  type VersionRow,
} from './db';

const rawSkills = import.meta.glob('./skills/*.md', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;

export const LOCAL_PROFILE_KEY = 'underlamp.profile';
export const DEFAULT_PROFILE = { displayName: '本地写作者' };

function parseFrontmatter(raw: string) {
  const text = raw.replace(/^\uFEFF/, '');
  const match = /^---\s*\n([\s\S]*?)\n---\s*\n?/.exec(text);
  if (!match) return { meta: {} as Record<string, string | string[]>, body: text };
  const meta: Record<string, string | string[]> = {};
  for (const line of match[1].split(/\n/)) {
    const item = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line.trim());
    if (!item) continue;
    const key = item[1].toLowerCase();
    let value = item[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (key === 'tags') {
      meta.tags = value
        .replace(/^\[|\]$/g, '')
        .split(/[,，]/)
        .map((tag) => tag.trim().replace(/^['"]|['"]$/g, ''))
        .filter(Boolean);
    } else {
      meta[key] = value;
    }
  }
  return { meta, body: text.slice(match[0].length) };
}

function builtinSkillRows(): SkillRow[] {
  const now = Date.now();
  return Object.entries(rawSkills)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([path, raw], index) => {
      const { meta, body } = parseFrontmatter(raw);
      const title = /^#\s+(.+)$/m.exec(body)?.[1]?.trim() || path.split('/').pop()?.replace(/\.md$/, '') || '未命名技能';
      const description = typeof meta.description === 'string' ? meta.description : '';
      const tags = Array.isArray(meta.tags) ? meta.tags : [];
      return {
        id: newId(),
        name: typeof meta.name === 'string' && meta.name ? meta.name : title,
        description,
        tags,
        content: body.trim(),
        kind: 'skill' as const,
        collection: '内置',
        sourceFilename: path.split('/').pop() || '',
        builtin: true,
        enabled: true,
        createdAt: now + index,
        updatedAt: now + index,
      };
    });
}

let readyPromise: Promise<void> | null = null;

export function ensureLocalReady(): Promise<void> {
  if (readyPromise) return readyPromise;
  readyPromise = (async () => {
    const initialized = await getMeta<boolean>('initialized');
    if (!initialized) {
      await putMany('skills', builtinSkillRows());
      await setMeta('initialized', true);
    }
    if (!localStorage.getItem(LOCAL_PROFILE_KEY)) {
      localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(DEFAULT_PROFILE));
    }
  })();
  return readyPromise;
}

export function getLocalProfile() {
  try {
    const raw = localStorage.getItem(LOCAL_PROFILE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return {
      displayName: String(parsed?.displayName || DEFAULT_PROFILE.displayName).slice(0, 30) || DEFAULT_PROFILE.displayName,
    };
  } catch {
    return { ...DEFAULT_PROFILE };
  }
}

export function saveLocalProfile(profile: { displayName: string }) {
  const displayName = String(profile.displayName || '').trim().slice(0, 30) || DEFAULT_PROFILE.displayName;
  localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify({ displayName }));
  return { displayName };
}

export async function restoreBuiltinSkills(): Promise<number> {
  const existing = await getAll<SkillRow>('skills');
  const names = new Set(existing.filter((skill) => skill.builtin).map((skill) => skill.name));
  const missing = builtinSkillRows().filter((skill) => !names.has(skill.name));
  if (missing.length) await putMany('skills', missing);
  return missing.length;
}

export async function loadDemoWorkspace(): Promise<number> {
  const done = await getMeta<boolean>('demo_loaded');
  if (done) return 0;
  const now = Date.now();
  const projects: ProjectRow[] = [];
  const chapters: ChapterRow[] = [];
  const versions: VersionRow[] = [];

  demoProjects.forEach((project, projectIndex) => {
    const projectId = newId();
    const createdAt = now - (projectIndex + 1) * 6 * 24 * 60 * 60 * 1000;
    const updatedAt = now - projectIndex * 2 * 60 * 60 * 1000;
    projects.push({
      id: projectId,
      title: project.title,
      subtitle: project.subtitle,
      genre: project.genre,
      premise: project.premise,
      styleGuide: project.style_guide,
      status: (['writing', 'paused', 'done', 'idea'].includes(project.status) ? project.status : 'writing') as ProjectRow['status'],
      accent: project.accent,
      createdAt,
      updatedAt,
      bible: {
        world: project.bible.world || '',
        characters: project.bible.characters || '',
        outline: project.bible.outline || '',
        foreshadowing: (project.bible as { foreshadowing?: string }).foreshadowing || '',
        style: (project.bible as { style?: string }).style || '',
        rules: project.bible.rules || '',
        themes: project.bible.themes || '',
        updatedAt,
      },
    });
    (project.chapters || []).forEach((chapter, index) => {
      const chapterId = newId();
      const chapterUpdatedAt = updatedAt - ((project.chapters || []).length - index) * 60 * 60 * 1000;
      const content = chapter.content || '';
      chapters.push({
        id: chapterId,
        projectId,
        title: chapter.title,
        content,
        summary: chapter.summary || '',
        beats: chapter.beats || '',
        status: (['draft', 'final', 'outline'].includes(chapter.status) ? chapter.status : 'draft') as ChapterRow['status'],
        sort: index,
        wordCount: countWords(content),
        createdAt: createdAt + index * 24 * 60 * 60 * 1000,
        updatedAt: chapterUpdatedAt,
      });
      if (content.trim()) {
        versions.push({
          id: newId(),
          chapterId,
          content,
          wordCount: countWords(content),
          createdAt: chapterUpdatedAt - 30 * 60 * 1000,
        });
      }
    });
  });

  await putMany('projects', projects);
  await putMany('chapters', chapters);
  await putMany('versions', versions);

  const existingReference = (await getAll<SkillRow>('skills')).find(
    (skill) => skill.kind === 'reference' && skill.name === demoReference.name,
  );
  if (!existingReference) {
    await put<SkillRow>('skills', {
      id: newId(),
      name: demoReference.name,
      description: demoReference.description,
      tags: demoReference.tags,
      content: demoReference.content,
      kind: 'reference',
      sourceFilename: `${demoReference.name}.md`,
      builtin: true,
      enabled: true,
      createdAt: now,
      updatedAt: now,
    });
  }

  const demoStats: StatRow[] = [
    [0, 320],
    [1, 880],
    [2, 1450],
    [4, 620],
    [5, 990],
    [8, 410],
    [11, 760],
  ].map(([offset, words]) => ({ day: shiftDayKey(dayKey(), -offset), words }));
  const existingStats = await getAll<StatRow>('stats');
  if (!existingStats.length) await putMany('stats', demoStats);
  await setMeta('demo_loaded', true);
  return projects.length;
}

export async function hasDemoWorkspace(): Promise<boolean> {
  return Boolean(await getMeta<boolean>('demo_loaded'));
}
