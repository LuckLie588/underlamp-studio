import type { Bible, ChapterMeta, CodexEntry, TimelineEvent } from '../types';
import { countWords } from '../lib/format';

export interface ChapterReport {
  id: string;
  title: string;
  words: number;
  dialogueRatio: number;
  summaryChars: number;
}

export interface RepeatedPhrase {
  phrase: string;
  count: number;
  chapters: number;
}

export interface ProjectReport {
  chapters: ChapterReport[];
  totalWords: number;
  averageWords: number;
  shortest: ChapterReport | null;
  longest: ChapterReport | null;
  dialogueRatio: number;
  repeated: RepeatedPhrase[];
  codexTotal: number;
  codexSeen: number;
  neverSeen: Array<{ id: string; name: string; kind: string }>;
  openThreads: number;
  timelineCount: number;
  styleReady: boolean;
}

export type MentionMap = Record<string, { count: number; chapters: Array<{ id: string; title: string; count: number }> }>;

const STOP_PHRASES = new Set([
  '一个', '没有', '什么', '自己', '不是', '就是', '知道', '看着', '这个', '那个',
  '时候', '已经', '还是', '可以', '这样', '那样', '起来', '出来', '过来', '回去',
  '如果', '因为', '所以', '但是', '而且', '然后', '现在', '这里', '那里', '他们',
  '她们', '我们', '你们', '的人', '的事', '的东西', '的时候', '已经', '一样', '似乎',
]);

function dialogueRatio(content: string) {
  if (!content) return 0;
  const matches = content.match(/[“"「][^”"」]*[”"」]/g) || [];
  const chars = matches.reduce((sum, item) => sum + item.length, 0);
  return chars / Math.max(1, content.length);
}

function repeatedPhrases(chapters: Array<{ content: string }>) {
  const counts = new Map<string, { count: number; chapters: Set<number> }>();
  chapters.forEach((chapter, index) => {
    const clean = chapter.content.replace(/[^\u4e00-\u9fa5]/g, '');
    for (let i = 0; i < clean.length - 3; i += 1) {
      const phrase = clean.slice(i, i + 4);
      if (STOP_PHRASES.has(phrase)) continue;
      const row = counts.get(phrase) || { count: 0, chapters: new Set<number>() };
      row.count += 1;
      row.chapters.add(index);
      counts.set(phrase, row);
    }
  });
  return [...counts.entries()]
    .filter(([, row]) => row.count >= 4 && row.chapters.size >= 2)
    .map(([phrase, row]) => ({ phrase, count: row.count, chapters: row.chapters.size }))
    .sort((a, b) => b.count - a.count || b.chapters - a.chapters)
    .filter((row, index, list) => !list.some((other, otherIndex) => otherIndex < index && other.phrase.includes(row.phrase)))
    .slice(0, 8);
}

export function buildProjectReport({
  bible,
  chapters,
  codex,
  timeline,
  mentions,
}: {
  bible: Bible;
  chapters: Array<ChapterMeta & { content: string }>;
  codex: CodexEntry[];
  timeline: TimelineEvent[];
  mentions: MentionMap;
}): ProjectReport {
  const rows = chapters.map((chapter) => ({
    id: chapter.id,
    title: chapter.title,
    words: countWords(chapter.content),
    dialogueRatio: dialogueRatio(chapter.content),
    summaryChars: chapter.summary?.length || 0,
  }));
  const totalWords = rows.reduce((sum, row) => sum + row.words, 0);
  const dialogue = chapters.length
    ? chapters.reduce((sum, chapter) => sum + dialogueRatio(chapter.content), 0) / chapters.length
    : 0;
  const sorted = [...rows].sort((a, b) => a.words - b.words);
  const codexSeen = codex.filter((entry) => (mentions[entry.id]?.count || 0) > 0);
  return {
    chapters: rows,
    totalWords,
    averageWords: chapters.length ? Math.round(totalWords / chapters.length) : 0,
    shortest: sorted[0] || null,
    longest: sorted[sorted.length - 1] || null,
    dialogueRatio: dialogue,
    repeated: repeatedPhrases(chapters),
    codexTotal: codex.length,
    codexSeen: codexSeen.length,
    neverSeen: codex
      .filter((entry) => entry.kind === 'character' && (mentions[entry.id]?.count || 0) === 0)
      .map((entry) => ({ id: entry.id, name: entry.name, kind: entry.kind })),
    openThreads: (bible.foreshadowing?.match(/^\s*[-*]\s*\[\s\]/gm) || []).length,
    timelineCount: timeline.length,
    styleReady: Boolean(bible.style?.trim()),
  };
}
