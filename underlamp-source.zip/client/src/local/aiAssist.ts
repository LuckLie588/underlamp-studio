import { completeAgent } from '../api';

export type AssistMode = 'polish' | 'fill';

export async function assistText({
  providerId,
  model,
  mode,
  field,
  value,
  context,
}: {
  providerId: string;
  model: string;
  mode: AssistMode;
  field: string;
  value: string;
  context: string;
}) {
  const instruction = mode === 'polish'
    ? `请润色下面这段「${field}」。保持事实、人名、时间线不变；删掉空话、重复和解释性套话；更具体，保留作者语气。只输出润色后的文本，不要解释。`
    : `请根据作品上下文，补齐「${field}」。只写与已有设定不冲突、可以直接使用的具体内容；不要编造无法回收的大设定；只输出补齐后的文本，不要解释。`;
  const result = await completeAgent({
    providerId,
    model,
    system: '你是中文长篇小说的设定编辑。你的输出会被作者直接粘贴进资料库，所以必须具体、可执行、不解释。',
    messages: [{
      role: 'user',
      content: `【作品上下文】\n${context.slice(0, 14000)}\n\n【字段】${field}\n【当前内容】\n${value.slice(0, 8000) || '（空）'}\n\n${instruction}`,
    }],
    temperature: mode === 'polish' ? 0.25 : 0.5,
    maxTokens: 1600,
  });
  return result.text.trim();
}
