import { countWords } from '../lib/format';
import type { Chapter, ChapterMeta, CodexEntry, DeletedSnapshot, ProjectSummary, ReportSnapshot, Skill, StyleVersion, TimelineEvent } from '../types';
import { newId } from './id';
import {
  deleteMany,
  getAll,
  getAllByIndex,
  get,
  put,
  remove,
  type ChapterRow,
  type ProjectRow,
  type SkillRow,
  type VersionRow,
} from './db';
import { getLocalProfile, restoreBuiltinSkills, saveLocalProfile } from './seed';
import {
  createLocalProvider,
  deleteLocalProvider,
  getLocalPresets,
  getLocalProviders,
  testLocalProvider,
  updateLocalProvider,
} from './providers';
import { getWritingStats, recordWriting } from './stats';

class LocalError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

function now() {
  return Date.now();
}

function serializeChapter(row: ChapterRow, withContent = true): Chapter | ChapterMeta {
  return {
    id: row.id,
    projectId: row.projectId,
    title: row.title,
    summary: row.summary,
    beats: row.beats || '',
    status: row.status,
    sort: row.sort,
    wordCount: row.wordCount,
    targetWords: row.targetWords || 0,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    ...(withContent ? { content: row.content } : {}),
  };
}

async function getProjectChapters(projectId: string) {
  const rows = await getAllByIndex<ChapterRow>('chapters', 'projectId', projectId);
  return rows.sort((a, b) => a.sort - b.sort);
}

async function projectSummary(project: ProjectRow): Promise<ProjectSummary> {
  const chapters = await getProjectChapters(project.id);
  const words = chapters.reduce((sum, chapter) => sum + chapter.wordCount, 0);
  const written = chapters.filter((chapter) => chapter.content.trim());
  const lastWritten = written.at(-1);
  const last = chapters.at(-1);
  return {
    id: project.id,
    title: project.title,
    subtitle: project.subtitle,
    genre: project.genre,
    premise: project.premise,
    styleGuide: project.styleGuide,
    status: project.status,
    accent: project.accent,
    createdAt: project.createdAt,
    updatedAt: project.updatedAt,
    chapters: chapters.length,
    words,
    lastChapter: lastWritten?.title || last?.title || '',
    lastChapterId: lastWritten?.id || last?.id || null,
    targetWords: project.targetWords || 0,
    pov: project.pov || '',
    structure: project.structure || '',
    updateCadence: project.updateCadence || '',
    genrePackId: project.genrePackId || '',
  };
}

async function requireProject(id: string): Promise<ProjectRow> {
  const project = await get<ProjectRow>('projects', id);
  if (!project) throw new LocalError('作品不存在', 404);
  return project;
}

async function requireChapter(id: string): Promise<ChapterRow> {
  const chapter = await get<ChapterRow>('chapters', id);
  if (!chapter) throw new LocalError('章节不存在', 404);
  return chapter;
}

async function snapshotVersion(chapter: ChapterRow, force = false) {
  if (!force && !chapter.content.trim()) return;
  const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
  const latest = versions.sort((a, b) => b.createdAt - a.createdAt)[0];
  if (!force && latest && now() - latest.createdAt < 10 * 60 * 1000) return;
  await put<VersionRow>('versions', {
    id: newId(),
    chapterId: chapter.id,
    content: chapter.content,
    wordCount: chapter.wordCount,
    createdAt: now(),
  });
  const all = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
  const removeIds = all.sort((a, b) => b.createdAt - a.createdAt).slice(40).map((version) => version.id);
  if (removeIds.length) await deleteMany('versions', removeIds);
}

function serializeSkill(row: SkillRow, withContent = false): Skill {
  const plain = row.content
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/[*_>`#-]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    tags: row.tags,
    kind: row.kind,
    collection: row.collection || '',
    sourceFilename: row.sourceFilename,
    builtin: row.builtin,
    enabled: row.enabled,
    chars: row.content.length,
    preview: plain.slice(0, 180),
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    ...(withContent ? { content: row.content } : {}),
  };
}

async function makeSearch(projectId: string, query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return { query, count: 0, results: [] };
  const chapters = await getProjectChapters(projectId);
  const snippet = (value: string) => {
    const index = value.toLowerCase().indexOf(q);
    if (index < 0) return '';
    const start = Math.max(0, index - 56);
    const end = Math.min(value.length, index + q.length + 90);
    return `${start > 0 ? '…' : ''}${value.slice(start, end).replace(/\s+/g, ' ')}${end < value.length ? '…' : ''}`;
  };
  const results = chapters
    .map((row) => {
      const titleHit = row.title.toLowerCase().includes(q);
      const contentHit = row.content.toLowerCase().includes(q);
      const summaryHit = row.summary.toLowerCase().includes(q);
      const beatsHit = row.beats.toLowerCase().includes(q);
      const field = titleHit ? 'title' : contentHit ? 'content' : summaryHit ? 'summary' : beatsHit ? 'beats' : null;
      if (!field) return null;
      return {
        chapterId: row.id,
        title: row.title,
        chapterNumber: row.sort + 1,
        sort: row.sort,
        field,
        snippet: field === 'title' ? row.title : snippet(row[field as 'content' | 'summary' | 'beats']),
        status: row.status,
        wordCount: row.wordCount,
      };
    })
    .filter(Boolean)
    .slice(0, 30);
  return { query, count: results.length, results };
}

function bodyObject(body: unknown): Record<string, unknown> {
  return body && typeof body === 'object' && !Array.isArray(body) ? (body as Record<string, unknown>) : {};
}

function tagsList(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String).map((tag) => tag.trim()).filter(Boolean).slice(0, 8);
  if (typeof value === 'string') {
    return value.split(/[,，\n]/).map((tag) => tag.trim()).filter(Boolean).slice(0, 8);
  }
  return [];
}

const CODEX_KINDS = new Set(['character', 'location', 'faction', 'item', 'concept']);

function textList(value: unknown, max = 12): string[] {
  const items = Array.isArray(value) ? value : typeof value === 'string' ? value.split(/[,，、\n]/) : [];
  return [...new Set(items.map(String).map((item) => item.trim()).filter(Boolean))].slice(0, max);
}

function normalizeCodexEntry(body: Record<string, unknown>, projectId: string, existing?: CodexEntry): CodexEntry {
  const kind = CODEX_KINDS.has(String(body.kind)) ? (body.kind as CodexEntry['kind']) : existing?.kind || 'concept';
  const t = now();
  return {
    id: existing?.id || newId(),
    projectId,
    kind,
    name: String(body.name ?? existing?.name ?? '').trim().slice(0, 80),
    aliases: body.aliases !== undefined ? textList(body.aliases, 12) : existing?.aliases || [],
    role: String(body.role ?? existing?.role ?? '').slice(0, 80),
    summary: String(body.summary ?? existing?.summary ?? '').slice(0, 1200),
    details: String(body.details ?? existing?.details ?? '').slice(0, 8000),
    desire: String(body.desire ?? existing?.desire ?? '').slice(0, 800),
    fear: String(body.fear ?? existing?.fear ?? '').slice(0, 800),
    secret: String(body.secret ?? existing?.secret ?? '').slice(0, 800),
    voice: String(body.voice ?? existing?.voice ?? '').slice(0, 800),
    state: String(body.state ?? existing?.state ?? '').slice(0, 800),
    relationships: Array.isArray(body.relationships)
      ? body.relationships
          .map((item) => {
            const row = bodyObject(item);
            return { name: String(row.name || '').slice(0, 80), label: String(row.label || '').slice(0, 80), note: String(row.note || '').slice(0, 400) };
          })
          .filter((item) => item.name)
          .slice(0, 30)
      : existing?.relationships || [],
    tags: body.tags !== undefined ? tagsList(body.tags) : existing?.tags || [],
    pinned: body.pinned !== undefined ? Boolean(body.pinned) : existing?.pinned || false,
    firstChapterId: body.firstChapterId !== undefined ? String(body.firstChapterId || '') || null : existing?.firstChapterId || null,
    lastChapterId: body.lastChapterId !== undefined ? String(body.lastChapterId || '') || null : existing?.lastChapterId || null,
    createdAt: existing?.createdAt || t,
    updatedAt: t,
  };
}

function normalizeTimeline(body: Record<string, unknown>, projectId: string, existing?: TimelineEvent): TimelineEvent {
  const t = now();
  return {
    id: existing?.id || newId(),
    projectId,
    storyTime: String(body.storyTime ?? existing?.storyTime ?? '').slice(0, 120),
    title: String(body.title ?? existing?.title ?? '').slice(0, 160),
    description: String(body.description ?? existing?.description ?? '').slice(0, 4000),
    participants: body.participants !== undefined ? textList(body.participants, 20) : existing?.participants || [],
    chapterId: body.chapterId !== undefined ? String(body.chapterId || '') || null : existing?.chapterId || null,
    consequences: String(body.consequences ?? existing?.consequences ?? '').slice(0, 1200),
    createdAt: existing?.createdAt || t,
    updatedAt: t,
  };
}

export async function localRequest<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const method = (options.method || 'GET').toUpperCase();
  const url = new URL(path, 'http://local');
  const pathname = url.pathname;
  const body = bodyObject(options.body);
  let match: RegExpMatchArray | null;

  if (pathname === '/api/auth/me' && method === 'GET') {
    const profile = getLocalProfile();
    const projects = await getAll<ProjectRow>('projects');
    const skills = await getAll<SkillRow>('skills');
    const words = await Promise.all(projects.map(async (project) => {
      const chapters = await getProjectChapters(project.id);
      return chapters.reduce((sum, chapter) => sum + chapter.wordCount, 0);
    }));
    return {
      user: { id: 'local', email: 'local@browser', displayName: profile.displayName, createdAt: 0 },
      stats: {
        projects: projects.length,
        words: words.reduce((sum, value) => sum + value, 0),
        skills: skills.length,
      },
      providerCount: getLocalProviders().providers.length,
      isDemo: false,
      demoEnabled: false,
      registrationOpen: false,
    } as T;
  }

  if (pathname === '/api/auth/me' && method === 'PATCH') {
    const profile = saveLocalProfile({ displayName: String(body.displayName || '') });
    return { user: { id: 'local', email: 'local@browser', displayName: profile.displayName, createdAt: 0 } } as T;
  }

  if (pathname === '/api/projects' && method === 'GET') {
    const rows = await getAll<ProjectRow>('projects');
    const projects = await Promise.all(rows.sort((a, b) => b.updatedAt - a.updatedAt).map(projectSummary));
    return { projects } as T;
  }

  if (pathname === '/api/projects' && method === 'POST') {
    const t = now();
    const id = newId();
    const project: ProjectRow = {
      id,
      title: String(body.title || '未命名').slice(0, 80),
      subtitle: String(body.subtitle || '').slice(0, 120),
      genre: String(body.genre || '').slice(0, 60),
      premise: String(body.premise || '').slice(0, 2000),
      styleGuide: String(body.styleGuide || '').slice(0, 5000),
      status: (['writing', 'paused', 'done', 'idea'].includes(String(body.status)) ? body.status : 'writing') as ProjectRow['status'],
      accent: String(body.accent || 'tide'),
      createdAt: t,
      updatedAt: t,
      targetWords: Number(body.targetWords || 0) || 0,
      pov: String(body.pov || '').slice(0, 80),
      structure: String(body.structure || '').slice(0, 80),
      updateCadence: String(body.updateCadence || '').slice(0, 80),
      genrePackId: String(body.genrePackId || '').slice(0, 80),
      bible: { world: '', characters: '', outline: '', foreshadowing: '', style: '', rules: '', themes: '', updatedAt: t },
    };
    await put('projects', project);
    if (body.withFirstChapter !== false) {
      await put<ChapterRow>('chapters', {
        id: newId(),
        projectId: id,
        title: String(body.firstChapterTitle || '第一章').slice(0, 120),
        content: '',
        summary: '',
        beats: '',
        status: 'draft',
        sort: 0,
        wordCount: 0,
        createdAt: t,
        updatedAt: t,
      });
    }
    return { project: await projectSummary(project) } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') {
      const chapters = (await getProjectChapters(project.id)).map((row) => serializeChapter(row, false));
      return { project: await projectSummary(project), bible: project.bible, chapters } as T;
    }
    if (method === 'PATCH') {
      const next: ProjectRow = {
        ...project,
        title: body.title !== undefined ? String(body.title).slice(0, 80) : project.title,
        subtitle: body.subtitle !== undefined ? String(body.subtitle).slice(0, 120) : project.subtitle,
        genre: body.genre !== undefined ? String(body.genre).slice(0, 60) : project.genre,
        premise: body.premise !== undefined ? String(body.premise).slice(0, 2000) : project.premise,
        styleGuide: body.styleGuide !== undefined ? String(body.styleGuide).slice(0, 5000) : project.styleGuide,
        accent: body.accent !== undefined ? String(body.accent) : project.accent,
        status: body.status !== undefined ? String(body.status) as ProjectRow['status'] : project.status,
        targetWords: body.targetWords !== undefined ? Number(body.targetWords) || 0 : project.targetWords,
        pov: body.pov !== undefined ? String(body.pov).slice(0, 80) : project.pov,
        structure: body.structure !== undefined ? String(body.structure).slice(0, 80) : project.structure,
        updateCadence: body.updateCadence !== undefined ? String(body.updateCadence).slice(0, 80) : project.updateCadence,
        genrePackId: body.genrePackId !== undefined ? String(body.genrePackId).slice(0, 80) : project.genrePackId,
        updatedAt: now(),
      };
      await put('projects', next);
      return { project: await projectSummary(next) } as T;
    }
    if (method === 'DELETE') {
      const chapters = await getProjectChapters(project.id);
      for (const chapter of chapters) {
        const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
        await deleteMany('versions', versions.map((version) => version.id));
      }
      await deleteMany('chapters', chapters.map((chapter) => chapter.id));
      const codex = await getAllByIndex<CodexEntry>('codex', 'projectId', project.id);
      const timeline = await getAllByIndex<TimelineEvent>('timeline', 'projectId', project.id);
      const styleVersions = await getAllByIndex<StyleVersion>('styleVersions', 'projectId', project.id);
      const snapshots = await getAllByIndex<ReportSnapshot>('reportSnapshots', 'projectId', project.id);
      const undoRows = await getAllByIndex<DeletedSnapshot>('reportUndo', 'projectId', project.id);
      await deleteMany('codex', codex.map((entry) => entry.id));
      await deleteMany('timeline', timeline.map((event) => event.id));
      await deleteMany('styleVersions', styleVersions.map((version) => version.id));
      await deleteMany('reportSnapshots', snapshots.map((snapshot) => snapshot.id));
      await deleteMany('reportUndo', undoRows.map((row) => row.id));
      await remove('projects', project.id);
      return { ok: true } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/bible$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') return { bible: project.bible } as T;
    if (method === 'PATCH') {
      project.bible = {
        world: body.world !== undefined ? String(body.world) : project.bible.world,
        characters: body.characters !== undefined ? String(body.characters) : project.bible.characters,
        outline: body.outline !== undefined ? String(body.outline) : project.bible.outline,
        foreshadowing: body.foreshadowing !== undefined ? String(body.foreshadowing) : project.bible.foreshadowing || '',
        style: body.style !== undefined ? String(body.style) : project.bible.style || '',
        rules: body.rules !== undefined ? String(body.rules) : project.bible.rules,
        themes: body.themes !== undefined ? String(body.themes) : project.bible.themes,
        updatedAt: now(),
      };
      project.updatedAt = now();
      await put('projects', project);
      return { bible: project.bible } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/codex$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') {
      const entries = await getAllByIndex<CodexEntry>('codex', 'projectId', project.id);
      const timeline = await getAllByIndex<TimelineEvent>('timeline', 'projectId', project.id);
      return {
        entries: entries.sort((a, b) => Number(b.pinned) - Number(a.pinned) || a.kind.localeCompare(b.kind) || a.name.localeCompare(b.name)),
        timeline: timeline.sort((a, b) => a.storyTime.localeCompare(b.storyTime)),
      } as T;
    }
    if (method === 'POST') {
      const entry = normalizeCodexEntry(body, project.id);
      if (!entry.name) throw new LocalError('条目名称不能为空');
      await put('codex', entry);
      project.updatedAt = now();
      await put('projects', project);
      return { entry } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/codex\/batch$/)) && method === 'POST') {
    const project = await requireProject(match[1]);
    const entries = Array.isArray(body.entries) ? body.entries : [];
    const timeline = Array.isArray(body.timeline) ? body.timeline : [];
    const existingEntries = await getAllByIndex<CodexEntry>('codex', 'projectId', project.id);
    const existingTimeline = await getAllByIndex<TimelineEvent>('timeline', 'projectId', project.id);
    const entryKeys = new Set(existingEntries.map((entry) => `${entry.kind}:${entry.name.trim().toLowerCase()}`));
    const timelineKeys = new Set(existingTimeline.map((event) => `${event.storyTime}:${event.title}`.toLowerCase()));
    const created: CodexEntry[] = [];
    for (const value of entries.slice(0, 80)) {
      const entry = normalizeCodexEntry(bodyObject(value), project.id);
      if (!entry.name) continue;
      const key = `${entry.kind}:${entry.name.trim().toLowerCase()}`;
      if (entryKeys.has(key)) continue;
      entryKeys.add(key);
      await put('codex', entry);
      created.push(entry);
    }
    const createdTimeline: TimelineEvent[] = [];
    for (const value of timeline.slice(0, 80)) {
      const event = normalizeTimeline(bodyObject(value), project.id);
      if (!event.title) continue;
      const key = `${event.storyTime}:${event.title}`.toLowerCase();
      if (timelineKeys.has(key)) continue;
      timelineKeys.add(key);
      await put('timeline', event);
      createdTimeline.push(event);
    }
    project.updatedAt = now();
    await put('projects', project);
    return { entries: created, timeline: createdTimeline } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/codex\/mentions$/)) && method === 'GET') {
    const project = await requireProject(match[1]);
    const entries = await getAllByIndex<CodexEntry>('codex', 'projectId', project.id);
    const chapters = await getProjectChapters(project.id);
    const mentions: Record<string, { count: number; chapters: Array<{ id: string; title: string; count: number }> }> = {};
    for (const entry of entries) {
      const terms = [...new Set([entry.name, ...(entry.aliases || [])].filter((term) => term.length >= 2))];
      let total = 0;
      const chapterHits: Array<{ id: string; title: string; count: number }> = [];
      for (const chapter of chapters) {
        const haystack = `${chapter.title}\n${chapter.content}`.toLowerCase();
        let count = 0;
        for (const term of terms) {
          const needle = term.toLowerCase();
          let index = 0;
          while ((index = haystack.indexOf(needle, index)) !== -1) {
            count += 1;
            index += needle.length;
          }
        }
        if (count > 0) {
          total += count;
          chapterHits.push({ id: chapter.id, title: chapter.title, count });
        }
      }
      mentions[entry.id] = { count: total, chapters: chapterHits };
    }
    return { mentions } as T;
  }

  if ((match = pathname.match(/^\/api\/codex\/([^/]+)$/))) {
    const entry = await get<CodexEntry>('codex', match[1]);
    if (!entry) throw new LocalError('资料条目不存在', 404);
    if (method === 'PATCH') {
      const next = normalizeCodexEntry(body, entry.projectId, entry);
      await put('codex', next);
      return { entry: next } as T;
    }
    if (method === 'DELETE') {
      await remove('codex', entry.id);
      return { ok: true } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/style-versions$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') {
      const rows = await getAllByIndex<StyleVersion>('styleVersions', 'projectId', project.id);
      return { versions: rows.sort((a, b) => b.createdAt - a.createdAt).slice(0, 30) } as T;
    }
    if (method === 'POST') {
      const content = String(body.content || '').trim().slice(0, 12000);
      if (!content) throw new LocalError('文风卡还是空的');
      const version: StyleVersion = {
        id: newId(),
        projectId: project.id,
        content,
        source: body.source === 'extract' ? 'extract' : 'manual',
        model: String(body.model || '').slice(0, 120),
        providerLabel: String(body.providerLabel || '').slice(0, 120),
        sampleChapters: Array.isArray(body.sampleChapters) ? body.sampleChapters.map(String).slice(0, 10) : [],
        promptVersion: String(body.promptVersion || '').slice(0, 80),
        createdAt: now(),
      };
      await put('styleVersions', version);
      const all = await getAllByIndex<StyleVersion>('styleVersions', 'projectId', project.id);
      await deleteMany('styleVersions', all.sort((a, b) => b.createdAt - a.createdAt).slice(30).map((item) => item.id));
      return { version } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/style-versions\/([^/]+)$/)) && method === 'DELETE') {
    const version = await get<StyleVersion>('styleVersions', match[1]);
    if (!version) throw new LocalError('文风版本不存在', 404);
    await remove('styleVersions', version.id);
    return { ok: true } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/report-snapshots$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') {
      const rows = await getAllByIndex<ReportSnapshot>('reportSnapshots', 'projectId', project.id);
      return { snapshots: rows.sort((a, b) => b.createdAt - a.createdAt).slice(0, 10) } as T;
    }
    if (method === 'POST') {
      if (!body.report || typeof body.report !== 'object') throw new LocalError('缺少体检数据');
      const snapshot: ReportSnapshot = {
        id: newId(),
        projectId: project.id,
        name: String(body.name || '').slice(0, 80),
        report: body.report,
        createdAt: now(),
      };
      await put('reportSnapshots', snapshot);
      const all = await getAllByIndex<ReportSnapshot>('reportSnapshots', 'projectId', project.id);
      await deleteMany('reportSnapshots', all.sort((a, b) => b.createdAt - a.createdAt).slice(10).map((item) => item.id));
      return { snapshot } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/report-snapshots\/([^/]+)$/)) && method === 'PATCH') {
    const snapshot = await get<ReportSnapshot>('reportSnapshots', match[1]);
    if (!snapshot) throw new LocalError('体检快照不存在', 404);
    snapshot.name = body.name !== undefined ? String(body.name).slice(0, 80) : snapshot.name;
    await put('reportSnapshots', snapshot);
    return { snapshot } as T;
  }

  if ((match = pathname.match(/^\/api\/report-snapshots\/([^/]+)$/)) && method === 'DELETE') {
    const snapshot = await get<ReportSnapshot>('reportSnapshots', match[1]);
    if (!snapshot) throw new LocalError('体检快照不存在', 404);
    await remove('reportSnapshots', snapshot.id);
    return { ok: true } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/timeline$/))) {
    const project = await requireProject(match[1]);
    if (method === 'GET') {
      return { timeline: await getAllByIndex<TimelineEvent>('timeline', 'projectId', project.id) } as T;
    }
    if (method === 'POST') {
      const event = normalizeTimeline(body, project.id);
      if (!event.title) throw new LocalError('时间线标题不能为空');
      await put('timeline', event);
      return { event } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/timeline\/([^/]+)$/))) {
    const event = await get<TimelineEvent>('timeline', match[1]);
    if (!event) throw new LocalError('时间线事件不存在', 404);
    if (method === 'PATCH') {
      const next = normalizeTimeline(body, event.projectId, event);
      await put('timeline', next);
      return { event: next } as T;
    }
    if (method === 'DELETE') {
      await remove('timeline', event.id);
      return { ok: true } as T;
    }
  }  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/chapters$/)) && method === 'POST') {
    const project = await requireProject(match[1]);
    const chapters = await getProjectChapters(project.id);
    const t = now();
    const chapter: ChapterRow = {
      id: newId(),
      projectId: project.id,
      title: String(body.title || '未命名章节').slice(0, 120),
      content: '',
      summary: '',
      beats: '',
      status: 'draft',
      sort: chapters.length,
      wordCount: 0,
      createdAt: t,
      updatedAt: t,
    };
    await put('chapters', chapter);
    project.updatedAt = t;
    await put('projects', project);
    return { chapter: serializeChapter(chapter) } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/chapters\/reorder$/)) && method === 'POST') {
    const project = await requireProject(match[1]);
    const ids = Array.isArray(body.ids) ? body.ids.map(String) : [];
    const chapters = await getProjectChapters(project.id);
    if (ids.length !== chapters.length || new Set(ids).size !== ids.length) throw new LocalError('章节顺序数据不完整');
    const byId = new Map(chapters.map((chapter) => [chapter.id, chapter]));
    for (const [index, id] of ids.entries()) {
      const chapter = byId.get(id);
      if (!chapter) throw new LocalError('章节顺序数据不匹配');
      chapter.sort = index;
      await put('chapters', chapter);
    }
    project.updatedAt = now();
    await put('projects', project);
    return { ok: true } as T;
  }

  if ((match = pathname.match(/^\/api\/projects\/([^/]+)\/search$/)) && method === 'GET') {
    const project = await requireProject(match[1]);
    return (await makeSearch(project.id, url.searchParams.get('q') || '')) as T;
  }

  if ((match = pathname.match(/^\/api\/chapters\/([^/]+)$/))) {
    const chapter = await requireChapter(match[1]);
    if (method === 'GET') {
      const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
      return { chapter: serializeChapter(chapter), versionCount: versions.length } as T;
    }
    if (method === 'PATCH') {
      const old = { ...chapter };
      if (body.title !== undefined) chapter.title = String(body.title).slice(0, 120);
      if (body.content !== undefined) {
        chapter.content = String(body.content).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        chapter.wordCount = countWords(chapter.content);
      }
      if (body.summary !== undefined) chapter.summary = String(body.summary).slice(0, 4000);
      if (body.beats !== undefined) chapter.beats = String(body.beats).slice(0, 20_000);
      if (body.targetWords !== undefined) chapter.targetWords = Math.max(0, Number(body.targetWords) || 0);
      if (body.status !== undefined && ['draft', 'final', 'outline'].includes(String(body.status))) {
        chapter.status = String(body.status) as ChapterRow['status'];
      }
      chapter.updatedAt = now();
      await put('chapters', chapter);
      if (body.content !== undefined) {
        await snapshotVersion(old);
        await recordWriting(chapter.wordCount - old.wordCount);
      }
      const project = await requireProject(chapter.projectId);
      project.updatedAt = chapter.updatedAt;
      await put('projects', project);
      return { chapter: serializeChapter(chapter) } as T;
    }
    if (method === 'DELETE') {
      const project = await requireProject(chapter.projectId);
      const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
      await deleteMany('versions', versions.map((version) => version.id));
      await remove('chapters', chapter.id);
      const remaining = await getProjectChapters(project.id);
      for (const [index, row] of remaining.entries()) {
        row.sort = index;
        await put('chapters', row);
      }
      project.updatedAt = now();
      await put('projects', project);
      return { ok: true } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/chapters\/([^/]+)\/versions$/))) {
    const chapter = await requireChapter(match[1]);
    if (method === 'GET') {
      const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
      return {
        versions: versions
          .sort((a, b) => b.createdAt - a.createdAt)
          .slice(0, 40)
          .map((version) => ({
            id: version.id,
            wordCount: version.wordCount,
            createdAt: version.createdAt,
            preview: version.content.slice(0, 120),
          })),
      } as T;
    }
    if (method === 'POST') {
      await snapshotVersion(chapter, true);
      const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
      return { ok: true, versionCount: versions.length } as T;
    }
  }

  if ((match = pathname.match(/^\/api\/chapters\/([^/]+)\/versions\/([^/]+)$/)) && method === 'GET') {
    const chapter = await requireChapter(match[1]);
    const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
    const version = versions.find((item) => item.id === match![2]);
    if (!version) throw new LocalError('历史版本不存在', 404);
    return { version: { id: version.id, content: version.content, wordCount: version.wordCount, createdAt: version.createdAt } } as T;
  }

  if ((match = pathname.match(/^\/api\/chapters\/([^/]+)\/versions\/([^/]+)\/restore$/)) && method === 'POST') {
    const chapter = await requireChapter(match[1]);
    const versions = await getAllByIndex<VersionRow>('versions', 'chapterId', chapter.id);
    const version = versions.find((item) => item.id === match![2]);
    if (!version) throw new LocalError('历史版本不存在', 404);
    await snapshotVersion(chapter, true);
    chapter.content = version.content;
    chapter.wordCount = countWords(version.content);
    chapter.updatedAt = now();
    await put('chapters', chapter);
    const project = await requireProject(chapter.projectId);
    project.updatedAt = chapter.updatedAt;
    await put('projects', project);
    return { chapter: serializeChapter(chapter) } as T;
  }

  if (pathname === '/api/skills' && method === 'GET') {
    const rows = await getAll<SkillRow>('skills');
    const sorted = rows.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === 'skill' ? -1 : 1;
      if (a.builtin !== b.builtin) return a.builtin ? -1 : 1;
      return b.updatedAt - a.updatedAt;
    });
    return {
      skills: sorted.map((row) => serializeSkill(row)),
      counts: {
        skills: sorted.filter((row) => row.kind === 'skill').length,
        references: sorted.filter((row) => row.kind === 'reference').length,
        enabled: sorted.filter((row) => row.enabled).length,
      },
    } as T;
  }

  if (pathname === '/api/skills/text' && method === 'POST') {
    const t = now();
    const row: SkillRow = {
      id: newId(),
      name: String(body.name || '未命名技能').slice(0, 80),
      description: String(body.description || '').slice(0, 500),
      tags: tagsList(body.tags),
      content: String(body.content || ''),
      kind: body.kind === 'reference' ? 'reference' : 'skill',
      collection: String(body.collection || '').slice(0, 80),
      sourceFilename: String(body.sourceFilename || '').slice(0, 200),
      builtin: false,
      enabled: true,
      createdAt: t,
      updatedAt: t,
    };
    if (!row.content.trim()) throw new LocalError('技能正文不能为空');
    await put('skills', row);
    return { skill: serializeSkill(row, true) } as T;
  }

  if (pathname === '/api/skills/restore-builtins' && method === 'POST') {
    const added = await restoreBuiltinSkills();
    return { ok: true, added } as T;
  }

  if ((match = pathname.match(/^\/api\/skills\/([^/]+)$/))) {
    const row = await get<SkillRow>('skills', match[1]);
    if (!row) throw new LocalError('技能不存在', 404);
    if (method === 'GET') return { skill: serializeSkill(row, true) } as T;
    if (method === 'PATCH') {
      if (body.name !== undefined) row.name = String(body.name).slice(0, 80);
      if (body.description !== undefined) row.description = String(body.description).slice(0, 500);
      if (body.tags !== undefined) row.tags = tagsList(body.tags);
      if (body.content !== undefined) row.content = String(body.content);
      if (body.kind !== undefined) row.kind = body.kind === 'reference' ? 'reference' : 'skill';
      if (body.enabled !== undefined) row.enabled = Boolean(body.enabled);
      row.updatedAt = now();
      await put('skills', row);
      return { skill: serializeSkill(row, true) } as T;
    }
    if (method === 'DELETE') {
      await remove('skills', row.id);
      return { ok: true } as T;
    }
  }

  if (pathname === '/api/providers/presets' && method === 'GET') return getLocalPresets() as T;
  if (pathname === '/api/providers' && method === 'GET') return getLocalProviders() as T;
  if (pathname === '/api/providers' && method === 'POST') return { provider: createLocalProvider(body) } as T;

  if ((match = pathname.match(/^\/api\/providers\/([^/]+)\/test$/)) && method === 'POST') {
    return (await testLocalProvider(match[1], body.model ? String(body.model) : undefined)) as T;
  }

  if ((match = pathname.match(/^\/api\/providers\/([^/]+)$/))) {
    if (method === 'PATCH') return { provider: updateLocalProvider(match[1], body) } as T;
    if (method === 'DELETE') {
      deleteLocalProvider(match[1]);
      return { ok: true } as T;
    }
  }

  if (pathname === '/api/stats/writing' && method === 'GET') {
    return (await getWritingStats(Number(url.searchParams.get('days') || 14))) as T;
  }

  throw new LocalError(`本地接口不存在：${method} ${pathname}`, 404);
}
