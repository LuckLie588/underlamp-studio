import presetsJson from './presets.json';
import type { Preset, Provider } from '../types';
import { newId } from './id';

const STORAGE_KEY = 'underlamp.providers';

interface StoredProvider {
  id: string;
  label: string;
  kind: 'openai' | 'anthropic' | 'gemini';
  presetId: string;
  baseUrl: string;
  models: string[];
  isDefault: boolean;
  apiKey: string;
  createdAt: number;
  updatedAt: number;
}

export const LOCAL_PRESETS = presetsJson as Preset[];

const DEEPSEEK_ALIASES: Record<string, string> = {
  'deepseek-v4.1-flash': 'deepseek-flash',
  'deepseek-chat': 'deepseek-flash',
  'deepseek-reasoner': 'deepseek-flash',
};

let pendingMigrations: string[] = [];

function isOfficialDeepSeek(baseUrl: string) {
  try {
    return new URL(baseUrl).hostname === 'api.deepseek.com';
  } catch {
    return false;
  }
}

function migrateDeepSeekModels(row: StoredProvider) {
  if (!isOfficialDeepSeek(row.baseUrl)) return false;
  const next = [...new Set(row.models.map((model) => DEEPSEEK_ALIASES[model] || model))];
  const changed = next.length !== row.models.length || next.some((model, index) => model !== row.models[index]);
  if (!changed) return false;
  pendingMigrations.push(`${row.models.join(', ')} → ${next.join(', ')}`);
  row.models = next;
  row.updatedAt = Date.now();
  return true;
}

function normalizeModelIds(baseUrl: string, models: string[]) {
  const clean = models.map((model) => model.trim()).filter(Boolean);
  const mapped = isOfficialDeepSeek(baseUrl) ? clean.map((model) => DEEPSEEK_ALIASES[model] || model) : clean;
  return [...new Set(mapped)];
}

function read(): StoredProvider[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    let changed = false;
    for (const row of parsed) {
      if (row && Array.isArray(row.models) && migrateDeepSeekModels(row)) changed = true;
    }
    if (changed) write(parsed);
    return parsed;
  } catch {
    return [];
  }
}

function write(providers: StoredProvider[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(providers));
}

function keyHint(key: string) {
  if (!key) return '';
  return key.length <= 8 ? '••••' : `${key.slice(0, 3)}••••${key.slice(-4)}`;
}

export function normalizeProviderBaseUrl(input: string, kind: string) {
  let raw = String(input || '').trim();
  if (!raw) throw new Error('接口地址不能为空');
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error('接口地址格式不正确，需要 http:// 或 https:// 开头');
  }
  if (url.username || url.password) throw new Error('接口地址不能包含账号密码');
  url.hash = '';
  url.search = '';
  let pathname = url.pathname.replace(/\/+$/, '');
  if (kind === 'openai' && pathname.endsWith('/chat/completions')) {
    pathname = pathname.slice(0, -'/chat/completions'.length);
  }
  if (kind === 'anthropic' && pathname.endsWith('/v1/messages')) {
    pathname = pathname.slice(0, -'/v1/messages'.length);
  }
  url.pathname = pathname || '/';
  return url.toString().replace(/\/$/, '');
}

function labelFor(presetId: string, modelId: string) {
  const preset = LOCAL_PRESETS.find((item) => item.id === presetId);
  return preset?.models.find((model) => model.id === modelId)?.label || modelId;
}

function serialize(row: StoredProvider): Provider {
  return {
    id: row.id,
    label: row.label,
    kind: row.kind,
    presetId: row.presetId,
    baseUrl: row.baseUrl,
    models: row.models.map((id) => ({ id, label: labelFor(row.presetId, id) })),
    isDefault: row.isDefault,
    hasKey: Boolean(row.apiKey),
    keyHint: keyHint(row.apiKey),
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

export function getLocalPresets() {
  return { presets: LOCAL_PRESETS, note: '模型 ID 为常用示例，各服务商可能更新；保存前请按官方文档核对。' };
}

export function getLocalProviders(): { providers: Provider[]; presets: Preset[]; migrations: string[] } {
  const rows = read();
  const migrations = pendingMigrations;
  pendingMigrations = [];
  return { providers: rows.map(serialize), presets: LOCAL_PRESETS, migrations };
}

export function getProviderRow(id: string): StoredProvider | undefined {
  return read().find((row) => row.id === id);
}

export function getProviderConfig(id: string) {
  const row = getProviderRow(id);
  if (!row) throw new Error('模型服务不存在，请重新选择');
  return row;
}

export function createLocalProvider(input: Record<string, unknown>): Provider {
  const rows = read();
  if (rows.length >= 20) throw new Error('最多添加 20 个模型服务');
  const presetId = String(input.presetId || 'custom');
  const preset = LOCAL_PRESETS.find((item) => item.id === presetId);
  const kind = ['openai', 'anthropic', 'gemini'].includes(String(input.kind))
    ? (input.kind as StoredProvider['kind'])
    : preset?.kind || 'openai';
  const baseUrl = normalizeProviderBaseUrl(String(input.baseUrl || preset?.baseUrl || ''), kind);
  const rawModels = Array.isArray(input.models)
    ? input.models.map(String)
    : Array.isArray(preset?.models)
      ? preset.models.map((model) => model.id)
      : [];
  const models = normalizeModelIds(baseUrl, rawModels);
  if (!models.length) throw new Error('请至少填写一个模型 ID');
  const isDefault = input.isDefault === true || rows.length === 0;
  if (isDefault) rows.forEach((row) => (row.isDefault = false));
  const now = Date.now();
  const row: StoredProvider = {
    id: newId(),
    label: String(input.label || preset?.label || '模型服务').slice(0, 80),
    kind,
    presetId,
    baseUrl,
    models: [...new Set(models)].slice(0, 30),
    isDefault,
    apiKey: String(input.apiKey || '').trim().slice(0, 500),
    createdAt: now,
    updatedAt: now,
  };
  rows.push(row);
  write(rows);
  return serialize(row);
}

export function updateLocalProvider(id: string, input: Record<string, unknown>): Provider {
  const rows = read();
  const row = rows.find((item) => item.id === id);
  if (!row) throw new Error('模型服务不存在');
  const kind = ['openai', 'anthropic', 'gemini'].includes(String(input.kind)) ? (input.kind as StoredProvider['kind']) : row.kind;
  row.label = String(input.label ?? row.label).slice(0, 80) || row.label;
  row.kind = kind;
  row.presetId = String(input.presetId ?? row.presetId) || 'custom';
  row.baseUrl = normalizeProviderBaseUrl(String(input.baseUrl ?? row.baseUrl), kind);
  if (Array.isArray(input.models)) {
    const models = normalizeModelIds(row.baseUrl, input.models.map(String));
    if (!models.length) throw new Error('请至少填写一个模型 ID');
    row.models = models.slice(0, 30);
  }
  if (typeof input.apiKey === 'string' && input.apiKey.trim()) row.apiKey = input.apiKey.trim().slice(0, 500);
  if (input.clearKey === true) row.apiKey = '';
  if (input.isDefault === true) {
    rows.forEach((item) => (item.isDefault = false));
    row.isDefault = true;
  }
  row.updatedAt = Date.now();
  write(rows);
  return serialize(row);
}

export function deleteLocalProvider(id: string): void {
  const rows = read();
  const row = rows.find((item) => item.id === id);
  if (!row) throw new Error('模型服务不存在');
  const remaining = rows.filter((item) => item.id !== id);
  if (row.isDefault && remaining.length) remaining[0].isDefault = true;
  write(remaining);
}

export async function testLocalProvider(id: string, model?: string): Promise<{
  ok: boolean;
  latencyMs: number;
  model: string;
  reply: string;
}> {
  const row = getProviderRow(id);
  if (!row) throw new Error('模型服务不存在');
  let response: Response;
  try {
    response = await fetch('/api/ai/test', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
      body: JSON.stringify({
        provider: { label: row.label, kind: row.kind, baseUrl: row.baseUrl, apiKey: row.apiKey },
        model: model || row.models[0],
      }),
    });
  } catch {
    throw new Error('连不上本地服务。请先双击「启动灯下.bat」，确认 http://127.0.0.1:8787 能打开，再测试连接。');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || '连接测试失败');
  return data;
}
