import type { AiStreamPayload, Chapter, CodexEntry, ContextPreview } from '../types';
import { getAll, getAllByIndex, get, type ChapterRow, type ProjectRow, type SkillRow } from './db';
import { getProviderConfig } from './providers';
import { GENRE_PACK_BY_ID } from './genrePacks';

function projectForPrompt(project: ProjectRow) {
  return {
    id: project.id,
    title: project.title,
    subtitle: project.subtitle,
    genre: project.genre,
    premise: project.premise,
    style_guide: project.styleGuide,
  };
}

function chapterForPrompt(row: ChapterRow): Chapter {
  return {
    id: row.id,
    projectId: row.projectId,
    title: row.title,
    content: row.content,
    summary: row.summary,
    beats: row.beats,
    status: row.status,
    sort: row.sort,
    wordCount: row.wordCount,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

async function loadProject(id: string) {
  const project = await get<ProjectRow>('projects', id);
  if (!project) throw new Error('作品不存在');
  const chapters = (await getAllByIndex<ChapterRow>('chapters', 'projectId', id)).sort((a, b) => a.sort - b.sort);
  return { project, chapters };
}

function selectCodex(project: ProjectRow, entries: CodexEntry[], chapter: ChapterRow | null, instruction: string) {
  if (!entries.length) return [];
  const text = [
    chapter?.content || '',
    chapter?.beats || '',
    instruction || '',
    chapter ? '' : `${project.premise || ''}\n${project.bible?.outline || ''}`,
  ]
    .join('\n')
    .toLowerCase();
  const mentioned = entries.filter((entry) => {
    const terms = [entry.name, ...(entry.aliases || [])].filter((term) => term.length >= 2);
    return terms.some((term) => text.includes(term.toLowerCase()));
  });
  const chosen = [...entries.filter((entry) => entry.pinned), ...mentioned];
  const unique = [...new Map(chosen.map((entry) => [entry.id, entry])).values()].slice(0, 14);
  return unique;
}

function codexForPrompt(entry: CodexEntry) {
  return {
    id: entry.id,
    kind: entry.kind,
    name: entry.name,
    aliases: entry.aliases,
    role: entry.role,
    summary: entry.summary,
    details: entry.details,
    desire: entry.desire,
    fear: entry.fear,
    secret: entry.secret,
    voice: entry.voice,
    state: entry.state,
    relationships: entry.relationships,
    pinned: entry.pinned,
  };
}

export async function buildStreamPayload(payload: AiStreamPayload) {
  const { project, chapters } = await loadProject(payload.projectId);
  const chapter = payload.chapterId
    ? (await get<ChapterRow>('chapters', payload.chapterId)) || null
    : null;
  const provider = getProviderConfig(payload.providerId);
  const skillRows = await getAll<SkillRow>('skills');
  const skills = skillRows.filter((skill) => skill.enabled && (payload.skillIds || []).includes(skill.id));
  const codexRows = await getAllByIndex<CodexEntry>('codex', 'projectId', payload.projectId);
  const codex = selectCodex(project, codexRows, chapter, payload.instruction || '');
  const hasCodexCharacters = codex.some((entry) => entry.kind === 'character');
  const bibleForPrompt = hasCodexCharacters ? { ...project.bible, characters: '' } : project.bible;
  const pack = project.genrePackId ? GENRE_PACK_BY_ID.get(project.genrePackId) : null;
  const currentIndex = chapter ? chapters.findIndex((row) => row.id === chapter.id) : -1;
  const prior = currentIndex >= 0 ? chapters.slice(0, currentIndex) : chapters;
  const previous = prior.at(-1);
  const chaptersForPrompt = chapters.map((row) => {
    const meta = {
      id: row.id,
      title: row.title,
      summary: row.summary,
      beats: row.beats,
      sort: row.sort,
    };
    return previous?.id === row.id ? { ...meta, content: row.content } : meta;
  });
  return {
    provider: {
      label: provider.label,
      kind: provider.kind,
      baseUrl: provider.baseUrl,
      apiKey: provider.apiKey,
    },
    model: payload.model,
    action: payload.action,
    project: projectForPrompt(project),
    bible: bibleForPrompt,
    chapters: chaptersForPrompt,
    chapter: chapter ? chapterForPrompt(chapter) : null,
    skills: skills.map((skill) => ({
      id: skill.id,
      name: skill.name,
      kind: skill.kind,
      content: skill.content,
    })),
    codex: codex.map(codexForPrompt),
    genrePack: pack ? { id: pack.id, name: pack.name, tagline: pack.tagline, laws: pack.laws, bridges: pack.bridges } : null,
    instruction: payload.instruction || '',
    selection: payload.selection || '',
    history: payload.history || [],
    contextChars: payload.contextChars || 48_000,
  };
}

export async function buildExtractPayload(projectId: string) {
  const { project, chapters } = await loadProject(projectId);
  return {
    project: projectForPrompt(project),
    bible: project.bible,
    chapters: chapters
      .filter((chapter) => chapter.content.trim())
      .map((chapter) => ({
        title: chapter.title,
        content: chapter.content,
      })),
  };
}

export async function previewLocalContext(payload: AiStreamPayload): Promise<ContextPreview> {
  const builtPayload = await buildStreamPayload(payload);
  delete (builtPayload as { provider?: unknown }).provider;
  const response = await fetch('/api/ai/context', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify(builtPayload),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || '上下文读取失败');
  return data as ContextPreview;
}
