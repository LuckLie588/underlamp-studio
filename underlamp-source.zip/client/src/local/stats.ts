import { getAll, put, type StatRow } from './db';
import { dayKey, shiftDayKey } from './time';

export function recordWriting(delta: number): Promise<void> {
  if (!Number.isFinite(delta) || delta <= 0) return Promise.resolve();
  const day = dayKey();
  return (async () => {
    const rows = await getAll<StatRow>('stats');
    const existing = rows.find((row) => row.day === day);
    await put<StatRow>('stats', { day, words: (existing?.words || 0) + Math.round(delta) });
  })();
}

export async function getWritingStats(days = 14) {
  const span = Math.min(90, Math.max(1, Number(days) || 14));
  const rows = await getAll<StatRow>('stats');
  const byDay = new Map(rows.map((row) => [row.day, Number(row.words) || 0]));
  const today = dayKey();
  const yesterday = shiftDayKey(today, -1);
  const todayWords = byDay.get(today) || 0;
  const yesterdayWords = byDay.get(yesterday) || 0;

  let streak = 0;
  let cursor: string | null = todayWords > 0 ? today : yesterdayWords > 0 ? yesterday : null;
  while (cursor && (byDay.get(cursor) || 0) > 0) {
    streak += 1;
    cursor = shiftDayKey(cursor, -1);
  }

  const series = [];
  for (let index = span - 1; index >= 0; index -= 1) {
    const day = shiftDayKey(today, -index);
    series.push({ day, words: byDay.get(day) || 0 });
  }

  return {
    today,
    todayWords,
    yesterdayWords,
    streak,
    total: rows.reduce((sum, row) => sum + (Number(row.words) || 0), 0),
    span,
    totalInSpan: series.reduce((sum, item) => sum + item.words, 0),
    days: series,
  };
}
