import type { Bible, CodexEntry, TimelineEvent } from '../types';

export interface ProjectRow {
  id: string;
  title: string;
  subtitle: string;
  genre: string;
  premise: string;
  styleGuide: string;
  status: 'writing' | 'paused' | 'done' | 'idea';
  accent: string;
  createdAt: number;
  updatedAt: number;
  targetWords?: number;
  pov?: string;
  structure?: string;
  updateCadence?: string;
  genrePackId?: string;
  bible: Bible;
}

export interface ChapterRow {
  id: string;
  projectId: string;
  title: string;
  content: string;
  summary: string;
  beats: string;
  status: 'draft' | 'final' | 'outline';
  sort: number;
  wordCount: number;
  targetWords?: number;
  createdAt: number;
  updatedAt: number;
}

export interface SkillRow {
  id: string;
  name: string;
  description: string;
  tags: string[];
  content: string;
  kind: 'skill' | 'reference';
  collection?: string;
  sourceFilename: string;
  builtin: boolean;
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface VersionRow {
  id: string;
  chapterId: string;
  content: string;
  wordCount: number;
  createdAt: number;
}

export interface StatRow {
  day: string;
  words: number;
}

type StoreName = 'projects' | 'chapters' | 'skills' | 'versions' | 'stats' | 'meta' | 'codex' | 'timeline' | 'styleVersions' | 'reportSnapshots' | 'reportUndo' | 'recovery';

const DB_NAME = 'underlamp-local';
const DB_VERSION = 6;
let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('这个浏览器不支持 IndexedDB，无法保存本地书房'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('chapters')) {
        const store = db.createObjectStore('chapters', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('skills')) db.createObjectStore('skills', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('versions')) {
        const store = db.createObjectStore('versions', { keyPath: 'id' });
        store.createIndex('chapterId', 'chapterId');
      }
      if (!db.objectStoreNames.contains('stats')) db.createObjectStore('stats', { keyPath: 'day' });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
      if (!db.objectStoreNames.contains('codex')) {
        const store = db.createObjectStore('codex', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('timeline')) {
        const store = db.createObjectStore('timeline', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('styleVersions')) {
        const store = db.createObjectStore('styleVersions', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('reportSnapshots')) {
        const store = db.createObjectStore('reportSnapshots', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('reportUndo')) {
        const store = db.createObjectStore('reportUndo', { keyPath: 'id' });
        store.createIndex('projectId', 'projectId');
      }
      if (!db.objectStoreNames.contains('recovery')) db.createObjectStore('recovery', { keyPath: 'key' });
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(new Error('本地数据库打不开，请检查浏览器是否允许存储'));
  });
  return dbPromise;
}

function wrapRequest<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('本地存储读写失败'));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('本地存储事务失败'));
    tx.onabort = () => reject(tx.error || new Error('本地存储事务中断'));
  });
}

export async function getAll<T>(store: StoreName): Promise<T[]> {
  const db = await openDb();
  const tx = db.transaction(store, 'readonly');
  return wrapRequest(tx.objectStore(store).getAll());
}

export async function get<T>(store: StoreName, key: IDBValidKey): Promise<T | undefined> {
  const db = await openDb();
  const tx = db.transaction(store, 'readonly');
  return wrapRequest(tx.objectStore(store).get(key));
}

export async function put<T>(store: StoreName, value: T): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).put(value);
  await txDone(tx);
}

export async function putMany<T>(store: StoreName, values: T[]): Promise<void> {
  if (!values.length) return;
  const db = await openDb();
  const tx = db.transaction(store, 'readwrite');
  const objectStore = tx.objectStore(store);
  values.forEach((value) => objectStore.put(value));
  await txDone(tx);
}

export async function remove(store: StoreName, key: IDBValidKey): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).delete(key);
  await txDone(tx);
}

export async function getAllByIndex<T>(store: StoreName, indexName: string, value: IDBValidKey): Promise<T[]> {
  const db = await openDb();
  const tx = db.transaction(store, 'readonly');
  return wrapRequest(tx.objectStore(store).index(indexName).getAll(value));
}

export async function deleteMany(store: StoreName, keys: IDBValidKey[]): Promise<void> {
  if (!keys.length) return;
  const db = await openDb();
  const tx = db.transaction(store, 'readwrite');
  const objectStore = tx.objectStore(store);
  keys.forEach((key) => objectStore.delete(key));
  await txDone(tx);
}

export async function clearStore(store: StoreName): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).clear();
  await txDone(tx);
}

export async function clearEverything(): Promise<void> {
  await Promise.all(
    ['projects', 'chapters', 'skills', 'versions', 'stats', 'meta', 'codex', 'timeline', 'styleVersions', 'reportSnapshots', 'reportUndo', 'recovery'].map((store) =>
      clearStore(store as StoreName),
    ),
  );
  for (const key of Object.keys(localStorage)) {
    if (key.startsWith('underlamp.')) localStorage.removeItem(key);
  }
}

export async function getMeta<T>(key: string): Promise<T | undefined> {
  const row = await get<{ key: string; value: T }>('meta', key);
  return row?.value;
}

export async function setMeta(key: string, value: unknown): Promise<void> {
  await put('meta', { key, value });
}
