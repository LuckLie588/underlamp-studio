import { collectWorkspaceData } from './export';
import { get, put, remove } from './db';
import type { RecoveryPoint } from '../types';

const KEY = 'last-import';

export async function saveImportRecovery() {
  const data = await collectWorkspaceData();
  const point: RecoveryPoint = { key: KEY, createdAt: Date.now(), data };
  await put('recovery', point);
  return point;
}

export async function loadImportRecovery() {
  return get<RecoveryPoint>('recovery', KEY);
}

export async function clearImportRecovery() {
  await remove('recovery', KEY);
}
