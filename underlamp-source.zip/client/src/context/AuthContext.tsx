import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { loadMe } from '../api';
import { ensureLocalReady } from '../local/seed';
import type { User, UserStats } from '../types';

interface AuthValue {
  user: User;
  stats: UserStats;
  loading: boolean;
  providerCount: number;
  refresh: () => Promise<void>;
  setProviderCount: (count: number) => void;
}

const LOCAL_USER: User = {
  id: 'local',
  email: 'local@browser',
  displayName: '本地写作者',
  createdAt: 0,
};

const emptyStats: UserStats = { projects: 0, words: 0, skills: 0 };
const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(LOCAL_USER);
  const [stats, setStats] = useState<UserStats>(emptyStats);
  const [loading, setLoading] = useState(true);
  const [providerCount, setProviderCount] = useState(0);

  const refresh = useCallback(async () => {
    try {
      await ensureLocalReady();
      const data = await loadMe();
      if (data.user) setUser(data.user);
      if (data.stats) setStats(data.stats);
      setProviderCount(Number(data.providerCount || 0));
    } catch (error) {
      console.error('[underlamp] local workspace failed', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const value = useMemo<AuthValue>(
    () => ({
      user,
      stats,
      loading,
      providerCount,
      refresh,
      setProviderCount,
    }),
    [user, stats, loading, providerCount, refresh],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
