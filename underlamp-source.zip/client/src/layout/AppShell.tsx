import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { BookOpen, HardDrive, LibraryBig, Menu, Plus, Settings, Sparkles, X } from 'lucide-react';
import { Brand } from '../components/Brand';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/library', label: '书房', icon: LibraryBig },
  { to: '/skills', label: '技能与资料', icon: Sparkles },
  { to: '/settings', label: '设置', icon: Settings },
];

export function AppShell() {
  const { user, providerCount } = useAuth();
  const location = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    setDrawerOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && setDrawerOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [drawerOpen]);

  const initial = user.displayName.trim()?.[0] || '灯';

  return (
    <div className="shell">
      <header className="mobile-bar">
        <button type="button" className="icon-button" onClick={() => setDrawerOpen(true)} aria-label="打开菜单">
          <Menu size={21} />
        </button>
        <Brand compact />
        <Link to="/library?new=1" className="icon-button" aria-label="新建作品">
          <Plus size={20} />
        </Link>
      </header>

      {drawerOpen && <button type="button" className="drawer-scrim" aria-label="关闭菜单" onClick={() => setDrawerOpen(false)} />}

      <aside className={`shell-side ${drawerOpen ? 'is-open' : ''}`}>
        <div className="side-top">
          <Link to="/library" className="side-brand">
            <Brand />
          </Link>
          <button type="button" className="icon-button side-close" onClick={() => setDrawerOpen(false)} aria-label="关闭菜单">
            <X size={19} />
          </button>
        </div>

        <Link to="/library?new=1" className="new-book-button">
          <Plus size={16} />
          开一本新书
        </Link>

        <nav className="side-nav" aria-label="书房导航">
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}>
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="side-rule" />

        {providerCount === 0 ? (
          <Link to="/settings" className="side-callout">
            <span className="side-callout-mark" aria-hidden="true" />
            <strong>还没有接上模型</strong>
            <p>先放入一个 API Key，灯下才有笔。</p>
            <span className="side-callout-link">去接入</span>
          </Link>
        ) : (
          <Link to="/settings" className="side-callout side-callout-quiet">
            <BookOpen size={17} />
            <p>
              已接入 <strong>{providerCount}</strong> 个模型服务
            </p>
          </Link>
        )}

        <div className="side-user">
          <span className="avatar" aria-hidden="true">{initial}</span>
          <div className="side-user-meta">
            <strong>{user.displayName}</strong>
            <span>数据只保存在这台浏览器</span>
          </div>
          <span className="icon-button" title="本地保存" aria-label="本地保存">
            <HardDrive size={16} />
          </span>
        </div>
      </aside>

      <main className="shell-main">
        <Outlet />
      </main>
    </div>
  );
}
