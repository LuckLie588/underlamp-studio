import dns from 'node:dns/promises';
import net from 'node:net';
import { config } from './config.js';
import { HttpError } from './util.js';

/**
 * Model IDs move quickly. These are starting points, deliberately editable in
 * the UI. The platform itself is provider-agnostic.
 */
export const PROVIDER_PRESETS = [
  {
    id: 'deepseek',
    label: 'DeepSeek 深度求索',
    kind: 'openai',
    baseUrl: 'https://api.deepseek.com/v1',
    blurb: 'V4.1 Flash / V4 Pro，中文小说常用',
    models: [
      { id: 'deepseek-flash', label: 'DeepSeek V4.1 Flash' },
      { id: 'deepseek-v4-pro', label: 'DeepSeek V4 Pro' },
      { id: 'deepseek-v4-flash', label: 'V4 Flash 兼容名' },
    ],
  },
  {
    id: 'openai',
    label: 'OpenAI',
    kind: 'openai',
    baseUrl: 'https://api.openai.com/v1',
    blurb: 'GPT 系列，结构化能力稳',
    models: [
      { id: 'gpt-4.1', label: 'GPT-4.1' },
      { id: 'gpt-4.1-mini', label: 'GPT-4.1 mini' },
      { id: 'gpt-4o', label: 'GPT-4o' },
      { id: 'o4-mini', label: 'o4-mini' },
    ],
  },
  {
    id: 'anthropic',
    label: 'Anthropic Claude',
    kind: 'anthropic',
    baseUrl: 'https://api.anthropic.com',
    blurb: '长文连贯，文风细腻',
    models: [
      { id: 'claude-sonnet-4-5', label: 'Claude Sonnet 4.5' },
      { id: 'claude-opus-4-1', label: 'Claude Opus 4.1' },
      { id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5' },
    ],
  },
  {
    id: 'gemini',
    label: 'Google Gemini',
    kind: 'gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    blurb: '超长上下文，适合整卷通读',
    models: [
      { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
      { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
    ],
  },
  {
    id: 'moonshot',
    label: 'Kimi / Moonshot',
    kind: 'openai',
    baseUrl: 'https://api.moonshot.cn/v1',
    blurb: '国内长上下文，中文语感好',
    models: [
      { id: 'kimi-k2-0905-preview', label: 'Kimi K2' },
      { id: 'kimi-k2-turbo-preview', label: 'Kimi K2 Turbo' },
      { id: 'moonshot-v1-128k', label: 'Moonshot 128K' },
    ],
  },
  {
    id: 'zhipu',
    label: '智谱 GLM',
    kind: 'openai',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    blurb: 'GLM 系列，性价比高',
    models: [
      { id: 'glm-4.6', label: 'GLM-4.6' },
      { id: 'glm-4.5', label: 'GLM-4.5' },
      { id: 'glm-4.5-air', label: 'GLM-4.5 Air' },
    ],
  },
  {
    id: 'qwen',
    label: '通义千问 Qwen',
    kind: 'openai',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    blurb: 'Qwen 系列，中文创作稳',
    models: [
      { id: 'qwen3-max', label: 'Qwen3 Max' },
      { id: 'qwen-plus', label: 'Qwen Plus' },
      { id: 'qwen-long', label: 'Qwen Long' },
    ],
  },
  {
    id: 'siliconflow',
    label: '硅基流动 SiliconFlow',
    kind: 'openai',
    baseUrl: 'https://api.siliconflow.cn/v1',
    blurb: '一个 Key 调多家开源模型',
    models: [
      { id: 'deepseek-ai/DeepSeek-V3.1', label: 'DeepSeek V3.1' },
      { id: 'Qwen/Qwen3-235B-A22B-Instruct-2507', label: 'Qwen3 235B' },
      { id: 'moonshotai/Kimi-K2-Instruct', label: 'Kimi K2' },
    ],
  },
  {
    id: 'openrouter',
    label: 'OpenRouter',
    kind: 'openai',
    baseUrl: 'https://openrouter.ai/api/v1',
    blurb: '一个入口聚合主流模型',
    models: [
      { id: 'deepseek/deepseek-chat-v3.1', label: 'DeepSeek V3.1' },
      { id: 'anthropic/claude-sonnet-4.5', label: 'Claude Sonnet 4.5' },
      { id: 'google/gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
    ],
  },
  {
    id: 'ollama',
    label: 'Ollama（本地）',
    kind: 'openai',
    baseUrl: 'http://127.0.0.1:11434/v1',
    blurb: '本机模型，数据不出门',
    models: [
      { id: 'qwen3:8b', label: 'Qwen3 8B' },
      { id: 'deepseek-r1:8b', label: 'DeepSeek R1 8B' },
      { id: 'llama3.3:70b', label: 'Llama 3.3 70B' },
    ],
  },
  {
    id: 'custom',
    label: '自定义 OpenAI 兼容',
    kind: 'openai',
    baseUrl: '',
    blurb: '任何 /chat/completions 服务',
    models: [],
  },
];

export function presetById(id) {
  return PROVIDER_PRESETS.find((p) => p.id === id) || null;
}

export function presetForProvider(row) {
  if (row.preset_id) {
    const found = presetById(row.preset_id);
    if (found) return found;
  }
  const normalized = String(row.base_url || '').replace(/\/+$/, '');
  return PROVIDER_PRESETS.find((p) => p.baseUrl.replace(/\/+$/, '') === normalized) || null;
}

export function modelLabelFor(row, modelId) {
  const preset = presetForProvider(row);
  return preset?.models.find((m) => m.id === modelId)?.label || modelId;
}

export function serializeProvider(row, { exposeKey = false, apiKey = '', keyHint: hint = '' } = {}) {
  const preset = presetForProvider(row);
  let modelIds = [];
  try {
    modelIds = JSON.parse(row.models || '[]');
  } catch {
    modelIds = [];
  }
  if (!Array.isArray(modelIds)) modelIds = [];
  return {
    id: row.id,
    label: row.label,
    kind: row.kind,
    presetId: row.preset_id || preset?.id || 'custom',
    baseUrl: row.base_url,
    models: modelIds.map((id) => ({ id, label: modelLabelFor(row, id) })),
    isDefault: Boolean(row.is_default),
    hasKey: Boolean(row.api_key_enc),
    keyHint: hint || row.key_hint || '',
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    ...(exposeKey ? { apiKey } : {}),
  };
}

export function normalizeBaseUrl(input, kind) {
  let raw = String(input || '').trim();
  if (!raw) throw new HttpError(400, '接口地址不能为空');
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new HttpError(400, '接口地址格式不正确');
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new HttpError(400, '接口地址只支持 http/https');
  }
  if (url.username || url.password) throw new HttpError(400, '接口地址不能包含账号密码');
  url.hash = '';
  url.search = '';
  let pathname = url.pathname.replace(/\/+$/, '');
  if (kind === 'openai' && pathname.endsWith('/chat/completions')) {
    pathname = pathname.slice(0, -'/chat/completions'.length);
  }
  if (kind === 'anthropic' && pathname.endsWith('/v1/messages')) {
    pathname = pathname.slice(0, -'/v1/messages'.length);
  }
  if (kind === 'gemini' && pathname.includes('/models/')) {
    pathname = pathname.slice(0, pathname.indexOf('/models/'));
  }
  url.pathname = pathname || '/';
  return url.toString().replace(/\/$/, '');
}

function isIp(value) {
  return net.isIP(value) !== 0;
}

function isBlockedIp(ip) {
  if (net.isIPv4(ip)) {
    const parts = ip.split('.').map(Number);
    const [a, b] = parts;
    if (a === 0 || a === 127) return true;
    if (a === 10) return true;
    if (a === 169 && b === 254) return true; // link-local, includes metadata services
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    if (a >= 224) return true;
    return false;
  }
  const normalized = ip.toLowerCase();
  if (normalized === '::' || normalized === '::1') return true;
  if (normalized.startsWith('fc') || normalized.startsWith('fd')) return true;
  if (normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb')) return true;
  if (normalized.startsWith('::ffff:')) return isBlockedIp(normalized.slice(7));
  return false;
}

function isLoopbackHost(host) {
  return host === 'localhost' || host === '127.0.0.1' || host === '::1' || host.endsWith('.localhost');
}

function isLinkLocalIp(ip) {
  if (net.isIPv4(ip)) return ip.startsWith('169.254.');
  const normalized = ip.toLowerCase();
  if (normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb')) return true;
  if (normalized.startsWith('::ffff:')) return isLinkLocalIp(normalized.slice(7));
  return false;
}

const ALWAYS_BLOCKED_HOSTS = /(^|\.)(metadata\.google\.internal|metadata\.azure\.internal|instance-data\.ec2\.internal|internal)$/i;

/** Best-effort SSRF guard: protocol, credentials, hostname class and DNS answers. */
export async function assertSafeProviderUrl(baseUrl) {
  const url = new URL(baseUrl);
  const host = url.hostname.toLowerCase();
  if (ALWAYS_BLOCKED_HOSTS.test(host)) throw new HttpError(400, '该接口地址不被允许');
  if (isLoopbackHost(host)) {
    if (!config.allowLocalProviders) throw new HttpError(400, '当前部署不允许连接本机模型服务');
    return;
  }
  if (isIp(host)) {
    if (isLinkLocalIp(host)) throw new HttpError(400, '接口地址不能指向链路本地 / 云元数据地址');
    if (isBlockedIp(host) && !config.allowLocalProviders) {
      throw new HttpError(400, '接口地址不能指向内网');
    }
    return;
  }
  let records;
  try {
    records = await dns.lookup(host, { all: true, verbatim: true });
  } catch {
    throw new HttpError(400, '无法解析接口地址的域名');
  }
  if (!records.length) throw new HttpError(400, '无法解析接口地址的域名');
  if (records.some((r) => isLinkLocalIp(r.address))) {
    throw new HttpError(400, '接口地址解析到链路本地 / 云元数据地址，已阻止');
  }
  if (!config.allowLocalProviders && records.some((r) => isBlockedIp(r.address))) {
    throw new HttpError(400, '接口地址解析到内网，已阻止');
  }
}

function openaiEndpoint(baseUrl) {
  const base = baseUrl.replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(base)) return base;
  let url;
  try {
    url = new URL(base);
  } catch {
    return `${base}/chat/completions`;
  }
  if (url.pathname === '/' || url.pathname === '') {
    base = `${base}/v1`;
  }
  return `${base.replace(/\/+$/, '')}/chat/completions`;
}

function anthropicEndpoint(baseUrl) {
  const base = baseUrl.replace(/\/+$/, '');
  if (/\/v1\/messages$/.test(base)) return base;
  if (/\/v1$/.test(base)) return `${base}/messages`;
  return `${base}/v1/messages`;
}

function geminiEndpoint(baseUrl, model, stream) {
  const base = baseUrl.replace(/\/+$/, '');
  const action = stream ? 'streamGenerateContent' : 'generateContent';
  const suffix = stream ? '?alt=sse' : '';
  return `${base}/models/${encodeURIComponent(model)}:${action}${suffix}`;
}

function cleanUpstreamError(status, raw) {
  let message = '';
  try {
    const parsed = JSON.parse(raw);
    message = parsed?.error?.message || parsed?.message || parsed?.error || '';
  } catch {
    message = raw;
  }
  message = String(message || '').replace(/\s+/g, ' ').slice(0, 280);
  if (status === 401 || status === 403) return `上游拒绝访问（${status}）。请检查 API Key 与权限。${message ? ` ${message}` : ''}`;
  if (status === 404) return `上游找不到接口或模型（404）。请检查 Base URL 和模型 ID。${message ? ` ${message}` : ''}`;
  if (status === 429) return `上游限流或余额不足（429）。${message ? ` ${message}` : ''}`;
  if (status >= 500) return `上游服务异常（${status}）。${message ? ` ${message}` : ''}`;
  return `上游请求失败（${status}）。${message ? ` ${message}` : ''}`;
}

async function postJson(url, headers, body, signal) {
  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal,
    redirect: 'error',
  });
  if (!response.ok) {
    const raw = await response.text().catch(() => '');
    throw new HttpError(response.status >= 500 ? 502 : 400, cleanUpstreamError(response.status, raw));
  }
  return response;
}

function normalizeMessages(system, messages) {
  return [
    ...(system ? [{ role: 'system', content: String(system) }] : []),
    ...(messages || [])
      .filter((m) => m && (m.role === 'user' || m.role === 'assistant'))
      .map((m) => ({ role: m.role, content: String(m.content || '') })),
  ];
}

export function buildProviderRequest({ provider, apiKey, model, system, messages, temperature, maxTokens, stream }) {
  const key = apiKey || '';
  if (provider.kind === 'anthropic') {
    const sys = [system, ...messages.filter((m) => m.role === 'system').map((m) => m.content)].filter(Boolean).join('\n\n');
    const turns = messages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role, content: String(m.content || '') }));
    if (!turns.length) turns.push({ role: 'user', content: '你好' });
    return {
      url: anthropicEndpoint(provider.base_url),
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        accept: stream ? 'text/event-stream' : 'application/json',
      },
      body: {
        model,
        max_tokens: maxTokens,
        ...(temperature == null ? {} : { temperature }),
        ...(sys ? { system: sys } : {}),
        messages: turns,
        stream: Boolean(stream),
      },
    };
  }

  if (provider.kind === 'gemini') {
    const contents = messages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content || '') }] }));
    if (!contents.length) contents.push({ role: 'user', parts: [{ text: '你好' }] });
    return {
      url: geminiEndpoint(provider.base_url, model, stream),
      headers: {
        'content-type': 'application/json',
        'x-goog-api-key': key,
        accept: stream ? 'text/event-stream' : 'application/json',
      },
      body: {
        ...(system ? { system_instruction: { parts: [{ text: String(system) }] } } : {}),
        contents,
        generationConfig: {
          maxOutputTokens: maxTokens,
          ...(temperature == null ? {} : { temperature }),
        },
      },
    };
  }

  const allMessages = normalizeMessages(system, messages);
  const extraHeaders = {};
  let officialDeepSeek = false;
  try {
    const host = new URL(provider.base_url).hostname;
    officialDeepSeek = host === 'api.deepseek.com';
    if (host.includes('openrouter.ai')) {
      extraHeaders['HTTP-Referer'] = 'https://underlamp.app';
      extraHeaders['X-Title'] = 'Underlamp';
    }
  } catch {
    /* ignore */
  }
  const reasoningModel = /^(o1|o3|o4)/i.test(model) || /reasoner/i.test(model);
  const openAIReasoning = /^(o1|o3|o4)/i.test(model);
  return {
    url: openaiEndpoint(provider.base_url),
    headers: {
      'content-type': 'application/json',
      ...(key ? { authorization: `Bearer ${key}` } : {}),
      accept: stream ? 'text/event-stream' : 'application/json',
      ...extraHeaders,
    },
    body: {
      model,
      messages: allMessages,
      ...(openAIReasoning ? { max_completion_tokens: maxTokens } : { max_tokens: maxTokens }),
      stream: Boolean(stream),
      ...(reasoningModel || temperature == null ? {} : { temperature }),
      // DeepSeek V4 Flash/Pro think by default; reasoning tokens eat the
      // max_tokens budget and can leave only a few hundred characters of prose.
      // This writing app wants the full budget for output, not hidden thought.
      ...(officialDeepSeek ? { thinking: { type: 'disabled' } } : {}),
    },
  };
}

function textFromOpenAI(json) {
  const choice = json?.choices?.[0];
  const content = choice?.message?.content ?? choice?.delta?.content ?? '';
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map((part) => part?.text || '').join('');
  return '';
}

function usageFromOpenAI(json) {
  const u = json?.usage;
  if (!u) return null;
  return {
    input: u.prompt_tokens ?? u.input_tokens ?? null,
    output: u.completion_tokens ?? u.output_tokens ?? null,
  };
}

/**
 * Stream a completion. Calls onDelta({text, reasoning}) as data arrives and
 * resolves with {text, reasoning, usage, model}.
 */
export async function streamChat({
  provider,
  apiKey,
  model,
  system,
  messages,
  temperature = 0.85,
  maxTokens = 4096,
  signal,
  onDelta = () => {},
}) {
  await assertSafeProviderUrl(provider.base_url);
  const req = buildProviderRequest({
    provider,
    apiKey,
    model,
    system,
    messages,
    temperature,
    maxTokens,
    stream: true,
  });

  const controller = new AbortController();
  const onAbort = () => controller.abort();
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener('abort', onAbort, { once: true });
  }
  let idleTimer;
  const refreshIdle = () => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => controller.abort(new Error('上游超过 120 秒没有返回数据')), 120_000);
  };
  refreshIdle();

  try {
    const response = await postJson(req.url, req.headers, req.body, controller.signal);
    const contentType = response.headers.get('content-type') || '';

    if (contentType.includes('application/json')) {
      const json = await response.json();
      let text = '';
      let reasoning = '';
      if (provider.kind === 'anthropic') {
        text = (json.content || []).map((part) => part.text || '').join('');
      } else if (provider.kind === 'gemini') {
        const parts = json.candidates?.[0]?.content?.parts || [];
        text = parts.filter((p) => !p.thought).map((p) => p.text || '').join('');
        reasoning = parts.filter((p) => p.thought).map((p) => p.text || '').join('');
      } else {
        text = textFromOpenAI(json);
        reasoning = json.choices?.[0]?.message?.reasoning_content || '';
      }
      if (text) onDelta({ text, reasoning });
      return { text, reasoning, usage: null, model };
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let text = '';
    let reasoning = '';
    let usage = null;

    const handleData = (data) => {
      if (!data || data === '[DONE]') return;
      let json;
      try {
        json = JSON.parse(data);
      } catch {
        return;
      }
      if (json?.error) {
        throw new HttpError(400, cleanUpstreamError(400, JSON.stringify(json)));
      }
      if (provider.kind === 'anthropic') {
        if (json.type === 'content_block_delta') {
          const part = json.delta?.text || '';
          const think = json.delta?.thinking || '';
          if (part) {
            text += part;
            onDelta({ text: part, reasoning: '' });
          }
          if (think) {
            reasoning += think;
            onDelta({ text: '', reasoning: think });
          }
        }
        if (json.type === 'message_start' && json.message?.usage) {
          usage = {
            input: json.message.usage.input_tokens ?? null,
            output: json.message.usage.output_tokens ?? null,
          };
        }
        if (json.type === 'message_delta' && json.usage) {
          usage = {
            input: usage?.input ?? null,
            output: json.usage.output_tokens ?? null,
          };
        }
        return;
      }
      if (provider.kind === 'gemini') {
        if (json.usageMetadata) {
          usage = {
            input: json.usageMetadata.promptTokenCount ?? null,
            output: json.usageMetadata.candidatesTokenCount ?? null,
          };
        }
        const parts = json.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
          if (!part?.text) continue;
          if (part.thought) {
            reasoning += part.text;
            onDelta({ text: '', reasoning: part.text });
          } else {
            text += part.text;
            onDelta({ text: part.text, reasoning: '' });
          }
        }
        return;
      }
      const choice = json.choices?.[0];
      if (choice?.delta) {
        const content = choice.delta.content;
        const piece = typeof content === 'string'
          ? content
          : Array.isArray(content)
            ? content.map((p) => p?.text || '').join('')
            : '';
        const think = choice.delta.reasoning_content || choice.delta.reasoning || '';
        if (piece) {
          text += piece;
          onDelta({ text: piece, reasoning: '' });
        }
        if (think) {
          reasoning += think;
          onDelta({ text: '', reasoning: think });
        }
      }
      if (json.usage) usage = usageFromOpenAI(json);
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      refreshIdle();
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue;
        if (!trimmed.startsWith('data:')) continue;
        const data = trimmed.slice(5).trim();
        if (data === '[DONE]') continue;
        handleData(data);
      }
    }
    const tail = buffer.trim();
    if (tail.startsWith('data:')) handleData(tail.slice(5).trim());
    return { text, reasoning, usage, model };
  } catch (error) {
    if (error instanceof HttpError && apiKey) {
      error.message = error.message.split(apiKey).join('[key]');
    }
    if (error?.name === 'AbortError') {
      if (signal?.aborted) throw new HttpError(499, '已停止生成');
      throw new HttpError(504, '模型响应超时，请重试或换一个模型');
    }
    if (error instanceof HttpError) throw error;
    throw new HttpError(502, `连接模型服务失败：${String(error?.message || error).slice(0, 200)}`);
  } finally {
    clearTimeout(idleTimer);
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}

/** Non-streaming completion, used for connection tests and short utility calls. */
export async function completeChat({
  provider,
  apiKey,
  model,
  system,
  messages,
  temperature = 0.3,
  maxTokens = 64,
  signal,
}) {
  await assertSafeProviderUrl(provider.base_url);
  const req = buildProviderRequest({
    provider,
    apiKey,
    model,
    system,
    messages,
    temperature,
    maxTokens,
    stream: false,
  });
  const started = Date.now();
  let response;
  try {
    response = await postJson(req.url, req.headers, req.body, signal);
  } catch (error) {
    if (error instanceof HttpError && apiKey) {
      error.message = error.message.split(apiKey).join('[key]');
    }
    throw error;
  }
  const json = await response.json();
  let text = '';
  let reasoning = '';
  if (provider.kind === 'anthropic') {
    text = (json.content || []).map((part) => part.text || '').join('');
  } else if (provider.kind === 'gemini') {
    const parts = json.candidates?.[0]?.content?.parts || [];
    text = parts.map((p) => p.text || '').join('');
  } else {
    text = textFromOpenAI(json);
    reasoning = json.choices?.[0]?.message?.reasoning_content || '';
  }
  return { text, reasoning, latencyMs: Date.now() - started, model, usage: usageFromOpenAI(json) };
}

export async function testProviderConnection({ provider, apiKey, model }) {
  if (!model) throw new HttpError(400, '请先填写一个模型 ID');
  const result = await completeChat({
    provider,
    apiKey,
    model,
    system: 'You are a connection test.',
    messages: [{ role: 'user', content: 'Reply with exactly: OK' }],
    temperature: 0,
    maxTokens: 8,
  });
  return {
    ok: true,
    latencyMs: result.latencyMs,
    model,
    reply: (result.text || result.reasoning || '').trim().slice(0, 40),
  };
}
