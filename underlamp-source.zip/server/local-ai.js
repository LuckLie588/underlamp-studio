import express from 'express';
import { config } from './config.js';
import { rateLimit } from './rate-limit.js';
import { asyncRoute, clampNumber, countWords, HttpError, now } from './util.js';
import {
  ACTIONS,
  buildExtractContext,
  buildGenerationContext,
  buildSummaryContext,
} from './context.js';
import { completeChat, streamChat, testProviderConnection } from './providers.js';

export const aiRouter = express.Router();

const activeByIp = new Map();

function beginRequest(req) {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const active = activeByIp.get(ip) || 0;
  if (active >= 2) throw new HttpError(429, '同一网络同时只能跑两段生成，等一段结束再试');
  activeByIp.set(ip, active + 1);
  return () => {
    const current = (activeByIp.get(ip) || 1) - 1;
    if (current <= 0) activeByIp.delete(ip);
    else activeByIp.set(ip, current);
  };
}

function readProvider(body) {
  const raw = body?.provider;
  if (!raw || typeof raw !== 'object') throw new HttpError(400, '缺少模型服务配置');
  const kind = ['openai', 'anthropic', 'gemini'].includes(String(raw.kind)) ? String(raw.kind) : 'openai';
  const baseUrl = String(raw.baseUrl || raw.base_url || '').trim();
  const apiKey = String(raw.apiKey || raw.api_key || '').trim();
  if (!baseUrl) throw new HttpError(400, '模型接口地址不能为空');
  if (apiKey.length > 500) throw new HttpError(400, 'API Key 格式不正确');
  return {
    id: 'local',
    label: String(raw.label || '本地模型').slice(0, 80),
    kind,
    base_url: baseUrl,
  };
}

function readModel(body) {
  const model = String(body?.model || '').trim();
  if (!model) throw new HttpError(400, '请先选择模型');
  if (model.length > 160) throw new HttpError(400, '模型 ID 太长');
  return model;
}

function readAction(body) {
  const action = String(body?.action || 'continue');
  if (!ACTIONS[action]) throw new HttpError(400, '不支持这个写作动作');
  return action;
}

function readChapters(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 1000).map((chapter) => ({
    id: String(chapter?.id || ''),
    title: String(chapter?.title || '').slice(0, 160),
    summary: String(chapter?.summary || '').slice(0, 4000),
    beats: String(chapter?.beats || '').slice(0, 20000),
    content: String(chapter?.content || ''),
    sort: Number(chapter?.sort || 0),
  }));
}

function readChapter(value) {
  if (!value || typeof value !== 'object') return null;
  return {
    id: String(value.id || ''),
    title: String(value.title || '').slice(0, 160),
    summary: String(value.summary || '').slice(0, 4000),
    beats: String(value.beats || '').slice(0, 20000),
    content: String(value.content || ''),
    sort: Number(value.sort || 0),
  };
}

function readSkills(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 20).map((skill) => ({
    id: String(skill?.id || ''),
    name: String(skill?.name || '未命名技能').slice(0, 80),
    kind: skill?.kind === 'reference' ? 'reference' : 'skill',
    content: String(skill?.content || ''),
  }));
}

function readCodex(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 14).map((entry) => ({
    id: String(entry?.id || ''),
    kind: ['character', 'location', 'faction', 'item', 'concept'].includes(String(entry?.kind)) ? String(entry.kind) : 'concept',
    name: String(entry?.name || '').slice(0, 80),
    aliases: Array.isArray(entry?.aliases) ? entry.aliases.map(String).slice(0, 12) : [],
    role: String(entry?.role || '').slice(0, 80),
    summary: String(entry?.summary || '').slice(0, 1200),
    details: String(entry?.details || '').slice(0, 8000),
    desire: String(entry?.desire || '').slice(0, 800),
    fear: String(entry?.fear || '').slice(0, 800),
    secret: String(entry?.secret || '').slice(0, 800),
    voice: String(entry?.voice || '').slice(0, 800),
    state: String(entry?.state || '').slice(0, 800),
    relationships: Array.isArray(entry?.relationships) ? entry.relationships.slice(0, 30) : [],
    pinned: Boolean(entry?.pinned),
  }));
}

function readGenrePack(value) {
  if (!value || typeof value !== 'object' || !String(value.name || '').trim()) return null;
  return {
    id: String(value.id || ''),
    name: String(value.name || '').slice(0, 80),
    tagline: String(value.tagline || '').slice(0, 300),
    laws: Array.isArray(value.laws) ? value.laws.map(String).slice(0, 10) : [],
    bridges: Array.isArray(value.bridges) ? value.bridges.map(String).slice(0, 13) : [],
  };
}

function readHistory(value) {  if (!Array.isArray(value)) return [];
  return value
    .slice(-40)
    .map((message) => ({
      role: message?.role === 'assistant' ? 'assistant' : 'user',
      content: String(message?.content || '').slice(0, 12000),
    }))
    .filter((message) => message.content.trim());
}

function buildContext(body) {
  const project = body?.project;
  if (!project || typeof project !== 'object' || !String(project.title || '').trim()) {
    throw new HttpError(400, '作品数据不完整，请刷新后重试');
  }
  const action = readAction(body);
  const chapter = readChapter(body.chapter);
  if (['continue', 'polish', 'expand', 'condense', 'rewrite', 'summarize', 'continuity', 'diagnose'].includes(action) && !chapter) {
    throw new HttpError(400, '请先打开一个章节');
  }
  if (action === 'summarize' && !String(chapter.content || '').trim()) {
    throw new HttpError(400, '这一章还没有正文，先写一点再生成摘要');
  }
  if (
    ['polish', 'expand', 'condense', 'rewrite'].includes(action) &&
    !String(body?.selection || '').trim() &&
    !String(chapter.content || '').trim()
  ) {
    throw new HttpError(400, '这一章还没有正文，先写一点，或选中要处理的段落');
  }
  const contextChars = clampNumber(body?.contextChars, 10_000, 70_000, 48_000);
  const common = {
    project: {
      title: String(project.title || ''),
      subtitle: String(project.subtitle || ''),
      genre: String(project.genre || ''),
      premise: String(project.premise || ''),
      style_guide: String(project.style_guide || project.styleGuide || ''),
    },
    bible: {
      world: String(body?.bible?.world || ''),
      characters: String(body?.bible?.characters || ''),
      outline: String(body?.bible?.outline || ''),
      foreshadowing: String(body?.bible?.foreshadowing || ''),
      style: String(body?.bible?.style || ''),
      rules: String(body?.bible?.rules || ''),
      themes: String(body?.bible?.themes || ''),
    },
  };

  if (action === 'extract') {
    const built = buildExtractContext({
      ...common,
      chapters: readChapters(body?.chapters).filter((item) => item.content.trim()),
      maxChars: contextChars,
    });
    return { action, ...common, chapter: null, ...built };
  }
  if (action === 'summarize') {
    const built = buildSummaryContext({
      project: common.project,
      chapter,
      maxChars: Math.min(contextChars, 30_000),
    });
    return { action, ...common, chapter, ...built };
  }
  const built = buildGenerationContext({
    ...common,
    chapters: readChapters(body?.chapters),
    chapter,
    skills: readSkills(body?.skills),
    codex: readCodex(body?.codex),
    genrePack: readGenrePack(body?.genrePack),
    action,
    instruction: String(body?.instruction || '').slice(0, 20_000),
    selection: String(body?.selection || '').slice(0, 20_000),
    history: readHistory(body?.history),
    maxChars: contextChars,
  });
  return { action, ...common, chapter, ...built };
}

function prepareSSE(res) {
  res.status(200);
  res.setHeader('content-type', 'text/event-stream; charset=utf-8');
  res.setHeader('cache-control', 'no-cache, no-transform');
  res.setHeader('connection', 'keep-alive');
  res.setHeader('x-accel-buffering', 'no');
  res.flushHeaders?.();
  let closed = false;
  const send = (event, data) => {
    if (closed || res.writableEnded) return;
    try {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    } catch {
      closed = true;
    }
  };
  const close = () => {
    if (!closed && !res.writableEnded) {
      try {
        res.end();
      } catch {
        /* ignore */
      }
    }
    closed = true;
  };
  res.on('close', () => {
    if (!res.writableEnded) closed = true;
  });
  return { send, close, isClosed: () => closed };
}

async function runStream({ req, res, provider, apiKey, model, built, action, temperature, maxTokens }) {
  const release = beginRequest(req);
  const controller = new AbortController();
  res.on('close', () => {
    if (!res.writableEnded) controller.abort();
  });
  const sse = prepareSSE(res);
  const started = Date.now();
  const heartbeat = setInterval(() => {
    if (!sse.isClosed()) {
      try {
        res.write(': ping\n\n');
      } catch {
        /* ignore */
      }
    }
  }, 15_000);
  heartbeat.unref?.();
  sse.send('meta', {
    action,
    actionLabel: ACTIONS[action]?.label || action,
    model,
    provider: { id: provider.id, label: provider.label, kind: provider.kind },
    stats: built.stats,
    startedAt: started,
  });

  try {
    const result = await streamChat({
      provider,
      apiKey,
      model,
      system: built.system,
      messages: built.messages,
      temperature,
      maxTokens,
      signal: controller.signal,
      onDelta: (delta) => sse.send('delta', delta),
    });
    if (sse.isClosed()) return;
    sse.send('done', {
      usage: result.usage,
      outputChars: countWords(result.text),
      elapsedMs: Date.now() - started,
      finishedAt: now(),
    });
  } catch (error) {
    if (!sse.isClosed() && !controller.signal.aborted) {
      console.warn(
        `[underlamp] ai ${action} failed (${provider.kind}/${model}): ${String(error?.message || error).slice(0, 300)}`,
      );
      sse.send('error', {
        message: error?.message || '生成失败',
        status: error?.status || 500,
      });
    }
  } finally {
    clearInterval(heartbeat);
    release();
    sse.close();
  }
}

aiRouter.post(
  '/stream',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: config.aiRatePerHour,
    keyFn: (req) => req.ip,
    message: '生成太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const provider = readProvider(req.body);
    const model = readModel(req.body);
    const built = buildContext(req.body);
    await runStream({
      req,
      res,
      provider,
      apiKey: String(req.body?.provider?.apiKey || req.body?.provider?.api_key || '').trim(),
      model,
      built,
      action: built.action,
      temperature: built.action === 'summarize' || built.action === 'extract' ? 0.2 : 0.85,
      maxTokens: built.maxTokens ?? (built.action === 'summarize' ? 700 : ACTIONS[built.action]?.maxTokens ?? 4096),
    });
  }),
);

aiRouter.post(
  '/extract',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: Math.max(10, Math.floor(config.aiRatePerHour / 2)),
    keyFn: (req) => req.ip,
    message: '提取太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const provider = readProvider(req.body);
    const model = readModel(req.body);
    const built = buildContext({ ...req.body, action: 'extract' });
    await runStream({
      req,
      res,
      provider,
      apiKey: String(req.body?.provider?.apiKey || req.body?.provider?.api_key || '').trim(),
      model,
      built,
      action: 'extract',
      temperature: 0.2,
      maxTokens: 3000,
    });
  }),
);

aiRouter.post(
  '/context',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: Math.max(30, config.aiRatePerHour),
    keyFn: (req) => req.ip,
    message: '预览太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const built = buildContext(req.body);
    res.json({
      action: built.action,
      actionLabel: ACTIONS[built.action]?.label || built.action,
      project: { title: built.project.title },
      chapter: built.chapter ? { title: built.chapter.title } : null,
      system: built.system,
      user: built.user,
      messages: built.messages,
      stats: built.stats,
      estimatedTokens: Math.ceil((built.stats?.contextChars || 0) / 1.5),
      contextChars: built.stats?.contextChars || 0,
    });
  }),
);

aiRouter.post(
  '/agent',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: Math.max(20, Math.floor(config.aiRatePerHour / 2)),
    keyFn: (req) => req.ip,
    message: '灯灵请求太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const provider = readProvider(req.body);
    const model = readModel(req.body);
    const messages = Array.isArray(req.body?.messages)
      ? req.body.messages
          .slice(-30)
          .map((message) => ({
            role: message?.role === 'assistant' ? 'assistant' : 'user',
            content: String(message?.content || '').slice(0, 30000),
          }))
          .filter((message) => message.content.trim())
      : [];
    if (!messages.length) throw new HttpError(400, '缺少对话内容');
    const result = await completeChat({
      provider,
      apiKey: String(req.body?.provider?.apiKey || req.body?.provider?.api_key || '').trim(),
      model,
      system: String(req.body?.system || '').slice(0, 20000),
      messages,
      temperature: clampNumber(req.body?.temperature, 0, 1.2, 0.4),
      maxTokens: clampNumber(req.body?.maxTokens, 300, 12000, 4000),
    });
    res.json({
      text: result.text,
      reasoning: result.reasoning,
      usage: result.usage,
      latencyMs: result.latencyMs,
      model,
    });
  }),
);

aiRouter.post(
  '/test',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 40,
    keyFn: (req) => req.ip,
    message: '测试太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const provider = readProvider(req.body);
    const model = readModel(req.body);
    const apiKey = String(req.body?.provider?.apiKey || req.body?.provider?.api_key || '').trim();
    const result = await testProviderConnection({ provider, apiKey, model });
    res.json(result);
  }),
);
