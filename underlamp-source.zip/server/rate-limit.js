const buckets = new Map();

let lastSweep = Date.now();

function sweep() {
  const t = Date.now();
  if (t - lastSweep < 60_000) return;
  lastSweep = t;
  for (const [key, bucket] of buckets) {
    if (bucket.reset < t) buckets.delete(key);
  }
}

/**
 * Small in-memory fixed-window limiter. Adequate for a single-process deployment.
 * If you scale to multiple instances, move this to Redis.
 */
export function rateLimit({ windowMs, max, keyFn, message = '请求过于频繁，请稍后再试' }) {
  return (req, res, next) => {
    sweep();
    const identity = keyFn ? keyFn(req) : req.ip;
    const key = `${req.method}:${req.baseUrl}${req.path}:${identity}`;
    const t = Date.now();
    let bucket = buckets.get(key);
    if (!bucket || bucket.reset < t) {
      bucket = { count: 0, reset: t + windowMs };
      buckets.set(key, bucket);
    }
    bucket.count += 1;
    const remaining = Math.max(0, max - bucket.count);
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(remaining));
    if (bucket.count > max) {
      res.setHeader('Retry-After', String(Math.ceil((bucket.reset - t) / 1000)));
      return res.status(429).json({ error: message });
    }
    next();
  };
}
