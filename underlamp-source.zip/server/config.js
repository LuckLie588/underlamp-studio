import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(here, '..');
export const isProduction = process.env.NODE_ENV === 'production';

export const config = {
  isProduction,
  port: Number(process.env.PORT || 8787),
  host: process.env.HOST || '0.0.0.0',
  appOrigin: (process.env.APP_ORIGIN || '').trim().replace(/\/$/, ''),
  clientDist: path.join(ROOT, 'dist'),
  maxUploadBytes: Number(process.env.MAX_UPLOAD_MB || 40) * 1024 * 1024,
  trustProxy: process.env.TRUST_PROXY === 'true' || isProduction,
  aiRatePerHour: Number(process.env.AI_RATE_PER_HOUR || 120),
  appUser: process.env.APP_USER || 'friend',
  appPassword: process.env.APP_PASSWORD || '',
  allowLocalProviders: process.env.ALLOW_LOCAL_PROVIDERS
    ? process.env.ALLOW_LOCAL_PROVIDERS === 'true'
    : !isProduction,
};
