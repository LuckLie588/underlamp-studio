import express from 'express';
import multer from 'multer';
import {
  AlignmentType,
  Document,
  HeadingLevel,
  PageBreak,
  Packer,
  Paragraph,
  TextRun,
} from 'docx';
import { config } from './config.js';
import { rateLimit } from './rate-limit.js';
import { asyncRoute, HttpError, slugifyFilename } from './util.js';
import { extractUpload } from './extract.js';

export const toolsRouter = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadBytes, files: 12 },
});

const skillSearchCache = new Map();

toolsRouter.get(
  '/skill-finder/search',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 30,
    keyFn: (req) => req.ip,
    message: '找技能太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const query = String(req.query.q || '').trim().slice(0, 80);
    if (query.length < 2) throw new HttpError(400, '至少输入两个字符');
    const cacheKey = query.toLowerCase();
    const cached = skillSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.at < 60_000) {
      return res.json({ query, results: cached.results, cached: true });
    }
    let response;
    try {
      response = await fetch(`https://skills.sh/api/search?q=${encodeURIComponent(query)}&limit=8`, {
        headers: { 'user-agent': 'Underlamp/2.22 skill-finder' },
        signal: AbortSignal.timeout(9000),
      });
    } catch {
      throw new HttpError(502, 'skills.sh 暂时连不上，先检查网络');
    }
    if (!response.ok) throw new HttpError(502, `skills.sh 返回 ${response.status}`);
    const data = await response.json();
    const results = (Array.isArray(data.skills) ? data.skills : []).map((skill) => ({
      id: String(skill.id || ''),
      name: String(skill.name || skill.skillId || '未命名技能'),
      source: String(skill.source || ''),
      skillId: String(skill.skillId || ''),
      installs: Number(skill.installs || 0),
      url: `https://skills.sh/${skill.source || ''}/${skill.skillId || ''}`,
      installCommand: `npx skills add ${skill.source || ''}@${skill.skillId || ''}`,
    })).filter((skill) => skill.source && skill.skillId);
    skillSearchCache.set(cacheKey, { at: Date.now(), results });
    if (skillSearchCache.size > 40) {
      const oldest = [...skillSearchCache.entries()].sort((a, b) => a[1].at - b[1].at)[0];
      if (oldest) skillSearchCache.delete(oldest[0]);
    }
    res.json({ query, results, cached: false });
  }),
);

toolsRouter.post(
  '/extract',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 60,
    keyFn: (req) => req.ip,
    message: '导入太频繁，请稍后再试',
  }),
  upload.array('files', 12),
  asyncRoute(async (req, res) => {
    const files = Array.isArray(req.files) ? req.files : [];
    if (!files.length) throw new HttpError(400, '没有收到文件');
    const totalBytes = files.reduce((sum, file) => sum + Number(file.size || 0), 0);
    if (totalBytes > 80 * 1024 * 1024) throw new HttpError(413, '一次导入的文件总大小不能超过 80MB');
    const docs = [];
    const errors = [];
    for (const file of files) {
      try {
        const extracted = await extractUpload(file);
        docs.push(...extracted);
      } catch (error) {
        errors.push({ filename: file.originalname || '未命名文件', message: error?.message || '解析失败' });
      }
    }
    if (!docs.length) {
      throw new HttpError(400, errors[0]?.message || '这些文件里没有可读取的文字');
    }
    res.json({ docs, errors });
  }),
);

function setDownload(res, filename, contentType) {
  res.setHeader('content-type', contentType);
  res.setHeader(
    'content-disposition',
    `attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(filename)}`,
  );
}

async function docxBuffer(project, bible, chapters) {
  const children = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 2400, after: 280 },
      children: [new TextRun({ text: project.title, size: 48, bold: true })],
    }),
  ];
  if (project.subtitle) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 360 },
        children: [new TextRun({ text: project.subtitle, size: 24, color: '666666' })],
      }),
    );
  }
  if (project.genre) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 1200 },
        children: [new TextRun({ text: project.genre, size: 21, color: '888888' })],
      }),
    );
  }
  if (project.premise) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 2400 },
        children: [new TextRun({ text: project.premise, size: 22, italics: true })],
      }),
    );
  }
  children.push(new Paragraph({ children: [new PageBreak()] }));

  for (const chapter of chapters) {
    children.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 480, after: 300 },
        children: [new TextRun({ text: chapter.title || '未命名章节', bold: true })],
      }),
    );
    const paragraphs = (String(chapter.content || '').trim() || '（本章尚未落笔）').split(/\n+/);
    for (const paragraph of paragraphs) {
      children.push(
        new Paragraph({
          spacing: { after: 160, line: 380 },
          children: [new TextRun({ text: paragraph })],
        }),
      );
    }
    children.push(new Paragraph({ children: [new PageBreak()] }));
  }
  children.pop();

  if (bible?.world || bible?.characters || bible?.outline) {
    children.push(
      new Paragraph({
        pageBreakBefore: true,
        heading: HeadingLevel.HEADING_1,
        spacing: { after: 280 },
        children: [new TextRun({ text: '设定集', bold: true })],
      }),
    );
    for (const [label, value] of [
      ['世界', bible.world],
      ['人物', bible.characters],
      ['大纲', bible.outline],
      ['规则', bible.rules],
      ['主题', bible.themes],
    ]) {
      if (!value) continue;
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 280, after: 120 },
          children: [new TextRun({ text: label, bold: true })],
        }),
      );
      for (const paragraph of String(value).split(/\n+/)) {
        children.push(new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: paragraph })] }));
      }
    }
  }

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: { font: 'Noto Serif CJK SC', size: 24, color: '1A1A1A' },
          paragraph: { spacing: { line: 380 } },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
          },
        },
        children,
      },
    ],
  });
  return Packer.toBuffer(doc);
}

toolsRouter.post(
  '/docx',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 60,
    keyFn: (req) => req.ip,
    message: '导出太频繁，请稍后再试',
  }),
  asyncRoute(async (req, res) => {
    const body = req.body || {};
    const project = body.project;
    if (!project || typeof project !== 'object' || !String(project.title || '').trim()) {
      throw new HttpError(400, '导出数据不完整');
    }
    const chapters = Array.isArray(body.chapters) ? body.chapters.slice(0, 500) : [];
    if (!chapters.length) throw new HttpError(400, '这本书还没有章节');
    const bible = project.bible || body.bible || {};
    const buffer = await docxBuffer(
      {
        title: String(project.title).slice(0, 120),
        subtitle: String(project.subtitle || '').slice(0, 200),
        genre: String(project.genre || '').slice(0, 80),
        premise: String(project.premise || '').slice(0, 3000),
      },
      bible,
      chapters.map((chapter) => ({
        title: String(chapter?.title || '').slice(0, 160),
        content: String(chapter?.content || ''),
      })),
    );
    setDownload(res, `${slugifyFilename(project.title)}.docx`, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.send(buffer);
  }),
);
