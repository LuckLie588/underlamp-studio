import path from 'node:path';
import mammoth from 'mammoth';
import JSZip from 'jszip';
import { HttpError } from './util.js';

const TEXT_EXTS = new Set(['.md', '.markdown', '.mdx', '.txt', '.text', '.html', '.htm', '.json', '.yaml', '.yml', '.csv']);
const MAX_CONTENT = 220_000;

function cleanText(value) {
  return String(value || '')
    .replace(/\u0000/g, '')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();
}

function stripHtml(html) {
  const withoutScripts = String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');
  return withoutScripts
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]{2,}/g, ' ');
}

export function parseFrontmatter(raw) {
  const text = String(raw || '').replace(/^\uFEFF/, '');
  const match = /^---\s*\n([\s\S]*?)\n---\s*\n?/.exec(text);
  if (!match) return { meta: {}, body: text };
  const meta = {};
  for (const line of match[1].split(/\n/)) {
    const m = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line.trim());
    if (!m) continue;
    const key = m[1].toLowerCase();
    let value = m[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (key === 'tags') {
      value = value
        .replace(/^\[|\]$/g, '')
        .split(/[,，]/)
        .map((t) => t.trim().replace(/^['"]|['"]$/g, ''))
        .filter(Boolean);
    }
    meta[key] = value;
  }
  return { meta, body: text.slice(match[0].length) };
}

function deriveMeta({ raw, filename, fallbackKind }) {
  const ext = path.extname(filename || '').toLowerCase();
  const { meta, body } = parseFrontmatter(raw);
  const h1 = /^#\s+(.+)$/m.exec(body)?.[1]?.trim();
  const firstParagraph = body
    .split(/\n{2,}/)
    .map((p) => p.replace(/^#+\s*/, '').trim())
    .find((p) => p && !p.startsWith('```') && !p.startsWith('|'));
  const base = path.basename(filename || '未命名', ext);
  const name = String(meta.name || h1 || base || '未命名').slice(0, 80);
  const description = String(meta.description || firstParagraph || '').replace(/\s+/g, ' ').slice(0, 220);
  const tags = Array.isArray(meta.tags) ? meta.tags.slice(0, 8) : [];
  const isSkill = Boolean(meta.name && meta.description) || /^SKILL\.md$/i.test(path.basename(filename || ''));
  return {
    name,
    description,
    tags,
    kind: isSkill ? 'skill' : fallbackKind,
    body: cleanText(body),
  };
}

function guessKind(filename) {
  const ext = path.extname(filename || '').toLowerCase();
  if (ext === '.pdf' || ext === '.docx') return 'reference';
  return 'reference';
}

async function extractPdf(buffer) {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const task = pdfjs.getDocument({
    data: new Uint8Array(buffer),
    useSystemFonts: true,
    disableFontFace: true,
    isEvalSupported: false,
  });
  const doc = await task.promise;
  const pages = Math.min(doc.numPages, 300);
  const parts = [];
  for (let i = 1; i <= pages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    let line = '';
    const lines = [];
    for (const item of content.items) {
      if (!('str' in item)) continue;
      line += item.str;
      if (item.hasEOL) {
        lines.push(line);
        line = '';
      }
    }
    if (line) lines.push(line);
    parts.push(lines.join('\n'));
  }
  await doc.destroy();
  return parts.join('\n\n');
}

async function extractZip(buffer, archiveName = '') {
  const zip = await JSZip.loadAsync(buffer);
  const entries = Object.values(zip.files).filter((f) => !f.dir);
  if (entries.length > 300) throw new HttpError(400, '压缩包内文件过多');
  const isText = (name) => TEXT_EXTS.has(path.extname(name).toLowerCase()) || /\.docx$/i.test(name);
  const skillEntry = entries.find((f) => /(^|\/)SKILL\.md$/i.test(f.name));
  const readable = entries.filter((f) => isText(f.name)).slice(0, 40);
  const archiveBase = path.basename(String(archiveName || '技能包'), path.extname(String(archiveName || ''))).trim() || '技能包';
  const topLevels = [...new Set(entries.filter((f) => f.name.includes('/')).map((f) => f.name.split('/')[0]).filter(Boolean))];
  const collection = topLevels.length === 1 ? topLevels[0] : archiveBase;

  if (skillEntry) {
    const raw = await skillEntry.async('string');
    const derived = deriveMeta({ raw, filename: skillEntry.name, fallbackKind: 'skill' });
    const referenceParts = [];
    let budget = 90_000;
    for (const entry of readable) {
      if (entry.name === skillEntry.name) continue;
      if (budget <= 0) break;
      let text = '';
      try {
        if (/\.docx$/i.test(entry.name)) {
          const buffer = await entry.async('nodebuffer');
          text = (await mammoth.extractRawText({ buffer })).value;
        } else {
          text = await entry.async('string');
          if (/\.html?$/i.test(entry.name)) text = stripHtml(text);
        }
      } catch {
        continue;
      }
      const cleaned = cleanText(text);
      if (!cleaned) continue;
      const slice = cleaned.slice(0, Math.min(30_000, budget));
      budget -= slice.length;
      referenceParts.push(`\n\n## 参考文件：${entry.name}\n\n${slice}`);
    }
    return [
      {
        ...derived,
        kind: 'skill',
        collection,
        content: cleanText(`${derived.body}${referenceParts.join('')}`).slice(0, MAX_CONTENT),
        sourceFilename: skillEntry.name,
      },
    ];
  }

  const results = [];
  for (const entry of readable.slice(0, 12)) {
    if (path.extname(entry.name).toLowerCase() === '.zip') continue;
    try {
      let raw = '';
      if (/\.docx$/i.test(entry.name)) {
        const buffer = await entry.async('nodebuffer');
        raw = (await mammoth.extractRawText({ buffer })).value;
      } else {
        raw = await entry.async('string');
        if (/\.html?$/i.test(entry.name)) raw = stripHtml(raw);
      }
      if (!cleanText(raw)) continue;
      const derived = deriveMeta({ raw, filename: entry.name, fallbackKind: guessKind(entry.name) });
      if (!derived.body) continue;
      results.push({
        ...derived,
        kind: derived.kind === 'skill' ? 'skill' : 'reference',
        collection: derived.kind === 'skill' ? collection : '',
        content: derived.body.slice(0, MAX_CONTENT),
        sourceFilename: entry.name,
      });
    } catch {
      /* skip unreadable entry */
    }
  }
  return results;
}

/**
 * Extract one uploaded buffer into one or more skill/reference drafts.
 * @returns {Promise<Array<{name,description,tags,kind,content,sourceFilename}>>}
 */
export async function extractUpload({ buffer, originalname, mimetype }) {
  const filename = String(originalname || '未命名文件');
  const ext = path.extname(filename).toLowerCase();
  if (!buffer?.length) throw new HttpError(400, `文件「${filename}」为空`);
  if (buffer.length > 40 * 1024 * 1024) throw new HttpError(400, `文件「${filename}」超过 40MB`);

  if (ext === '.zip') {
    const docs = await extractZip(buffer, filename);
    if (!docs.length) throw new HttpError(400, `压缩包「${filename}」中没有可读取的 Markdown/文本/Word 文件`);
    return docs;
  }

  if (ext === '.pdf' || mimetype === 'application/pdf') {
    const raw = await extractPdf(buffer);
    if (!raw.trim()) throw new HttpError(400, `PDF「${filename}」没有可提取的文字（可能是扫描件）`);
    const derived = deriveMeta({ raw, filename, fallbackKind: 'reference' });
    return [{
      ...derived,
      kind: 'reference',
      content: derived.body.slice(0, MAX_CONTENT),
      sourceFilename: filename,
    }];
  }

  if (ext === '.docx') {
    const raw = (await mammoth.extractRawText({ buffer })).value;
    if (!raw.trim()) throw new HttpError(400, `Word 文档「${filename}」没有可提取的文字`);
    const derived = deriveMeta({ raw, filename, fallbackKind: 'reference' });
    return [{
      ...derived,
      kind: derived.kind || 'reference',
      content: derived.body.slice(0, MAX_CONTENT),
      sourceFilename: filename,
    }];
  }

  if (!TEXT_EXTS.has(ext) && !String(mimetype || '').startsWith('text/')) {
    throw new HttpError(400, `暂不支持「${ext || '未知'}」格式。可导入 .md / .txt / .docx / .pdf / .zip。`);
  }

  let raw = buffer.toString('utf8');
  if (ext === '.html' || ext === '.htm') raw = stripHtml(raw);
  if (!raw.trim()) throw new HttpError(400, `文件「${filename}」没有可读取的文字`);
  const derived = deriveMeta({ raw, filename, fallbackKind: guessKind(filename) });
  return [{
    ...derived,
    content: derived.body.slice(0, MAX_CONTENT),
    sourceFilename: filename,
  }];
}
