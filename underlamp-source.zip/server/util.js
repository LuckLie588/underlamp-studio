export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

export function text(value, max = 1000, { required = false, name = '内容' } = {}) {
  if (value === undefined || value === null) {
    if (required) throw new HttpError(400, `${name}不能为空`);
    return '';
  }
  if (typeof value !== 'string') throw new HttpError(400, `${name}格式不正确`);
  const trimmed = value.trim();
  if (required && !trimmed) throw new HttpError(400, `${name}不能为空`);
  if (trimmed.length > max) throw new HttpError(400, `${name}不能超过 ${max} 个字符`);
  return trimmed;
}

export function oneOf(value, allowed, fallback) {
  return allowed.includes(value) ? value : fallback;
}

export function now() {
  return Date.now();
}

export function slugifyFilename(name, fallback = 'manuscript') {
  const cleaned = String(name || '')
    .replace(/[\\/:*?"<>|\r\n]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60);
  return cleaned || fallback;
}

export function countWords(input) {
  const s = String(input || '');
  if (!s.trim()) return 0;
  const cjk = (s.match(/[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/g) || []).length;
  const latin = (s.match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g) || []).length;
  return cjk + latin;
}

export function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export function csvList(value, maxItems = 20) {
  if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean).slice(0, maxItems);
  return String(value || '')
    .split(/[,，、\n]/)
    .map((v) => v.trim())
    .filter(Boolean)
    .slice(0, maxItems);
}

export function safeJsonParse(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}
