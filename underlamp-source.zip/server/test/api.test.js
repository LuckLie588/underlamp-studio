import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const port = 8799;

function startMock() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let raw = '';
      req.on('data', (chunk) => (raw += chunk));
      req.on('end', () => {
        let body = {};
        try {
          body = JSON.parse(raw);
        } catch {
          body = {};
        }
        if (body.stream === false) {
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify({ choices: [{ message: { content: 'OK' } }], usage: { total_tokens: 3 } }));
          return;
        }
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
        for (const piece of ['门外的男人', '没有再敲。', '沈砚把耳朵从门板上挪开。']) {
          res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: piece } }] })}\n\n`);
        }
        res.write('data: [DONE]\n\n');
        res.end();
      });
    });
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port }));
  });
}

function waitForHealth(timeout = 12_000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      fetch(`http://127.0.0.1:${port}/api/health`)
        .then((response) => (response.ok ? response.json() : Promise.reject(new Error('not ready'))))
        .then(resolve)
        .catch(() => {
          if (Date.now() - started > timeout) reject(new Error('server did not start'));
          else setTimeout(tick, 180);
        });
    };
    tick();
  });
}

function basePayload(mockPort) {
  const chapter = {
    id: 'c1',
    title: '第一章',
    summary: '沈砚收到一封信。',
    beats: '目标：拆信。阻力：不敢。',
    content: '渡轮靠岸的时候，雾还没散。',
    sort: 0,
  };
  return {
    provider: {
      label: '测试模型',
      kind: 'openai',
      baseUrl: `http://127.0.0.1:${mockPort}/v1`,
      apiKey: 'sk-test',
    },
    model: 'mock-novel',
    action: 'continue',
    project: { title: '雾港无信', subtitle: '', genre: '悬疑', premise: '一封信', style_guide: '短句。' },
    bible: { world: '雾港。', characters: '沈砚。', outline: '', rules: '只写沈砚视角。', themes: '' },
    chapters: [chapter],
    chapter,
    skills: [],
    codex: [{
      id: 'x1',
      kind: 'character',
      name: '沈砚',
      aliases: ['阿砚'],
      role: '主角',
      summary: '回港的女儿。',
      desire: '找到母亲。',
      fear: '被当成疯子。',
      secret: '她记得灯塔。',
      voice: '短句。',
      state: '手里有信。',
      relationships: [],
      pinned: true,
    }],
    instruction: '',
    selection: '',
    contextChars: 48000,
  };
}

test('stateless API: health, context, provider test, SSE, extract and docx', async (t) => {
  const mock = await startMock();
  const child = spawn(process.execPath, ['server/index.js'], {
    cwd: root,
    env: {
      ...process.env,
      NODE_ENV: 'test',
      HOST: '127.0.0.1',
      PORT: String(port),
      ALLOW_LOCAL_PROVIDERS: 'true',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  t.after(() => {
    child.kill();
    mock.server.close();
  });
  await waitForHealth();

  const health = await (await fetch(`http://127.0.0.1:${port}/api/health`)).json();
  assert.equal(health.ok, true);
  assert.equal(health.mode, 'local-first');

  const blocked = await fetch(`http://127.0.0.1:${port}/api/ai/context`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(basePayload(mock.port)),
  });
  assert.equal(blocked.status, 403);

  const contextResponse = await fetch(`http://127.0.0.1:${port}/api/ai/context`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify(basePayload(mock.port)),
  });
  assert.equal(contextResponse.status, 200);
  const context = await contextResponse.json();
  assert.equal(context.actionLabel, '续写');
  assert.match(context.system, /只写沈砚视角/);
  assert.match(context.system, /Codex·人物：沈砚/);
  assert.equal(context.stats.codex[0].name, '沈砚');
  assert.match(context.user, /渡轮靠岸/);
  assert.ok(context.stats.contextChars > 100);
  assert.equal(context.stats.skills.length, 0);

  const testResponse = await fetch(`http://127.0.0.1:${port}/api/ai/test`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify({ provider: basePayload(mock.port).provider, model: 'mock-novel' }),
  });
  assert.equal(testResponse.status, 200);
  const testData = await testResponse.json();
  assert.equal(testData.ok, true);
  assert.match(testData.reply, /OK/);

  const agentResponse = await fetch(`http://127.0.0.1:${port}/api/ai/agent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify({
      provider: basePayload(mock.port).provider,
      model: 'mock-novel',
      system: '你是资料编辑。',
      messages: [{ role: 'user', content: '整理 Codex。' }],
      temperature: 0.2,
      maxTokens: 1200,
    }),
  });
  assert.equal(agentResponse.status, 200);
  const agentData = await agentResponse.json();
  assert.equal(agentData.text, 'OK');
  assert.equal(agentData.model, 'mock-novel');

  const streamResponse = await fetch(`http://127.0.0.1:${port}/api/ai/stream`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify(basePayload(mock.port)),
  });
  assert.equal(streamResponse.status, 200);
  const sse = await streamResponse.text();
  assert.match(sse, /event: meta/);
  assert.match(sse, /门外的男人/);
  assert.match(sse, /event: done/);

  const form = new FormData();
  form.append('files', new Blob(['---\nname: 测试技能\ndescription: 测试用\n---\n\n# 测试技能\n\n写短句。'], { type: 'text/markdown' }), 'test-skill.md');
  const extractResponse = await fetch(`http://127.0.0.1:${port}/api/tools/extract`, {
    method: 'POST',
    headers: { 'x-requested-with': 'underlamp' },
    body: form,
  });
  assert.equal(extractResponse.status, 200);
  const extracted = await extractResponse.json();
  assert.equal(extracted.docs.length, 1);
  assert.match(extracted.docs[0].content, /写短句/);

  const docxResponse = await fetch(`http://127.0.0.1:${port}/api/tools/docx`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-requested-with': 'underlamp' },
    body: JSON.stringify({
      project: { title: '雾港无信', subtitle: '', genre: '悬疑', premise: '一封信', bible: { world: '雾港' } },
      chapters: [{ title: '第一章', content: '渡轮靠岸的时候，雾还没散。' }],
    }),
  });
  assert.equal(docxResponse.status, 200);
  const docx = Buffer.from(await docxResponse.arrayBuffer());
  assert.ok(docx.length > 3000);
  assert.equal(docx.subarray(0, 2).toString(), 'PK');
});
