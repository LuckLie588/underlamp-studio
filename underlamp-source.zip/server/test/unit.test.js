import test from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import { countWords } from '../util.js';
import { parseFrontmatter, extractUpload } from '../extract.js';
import { buildGenerationContext, buildSummaryContext } from '../context.js';
import { normalizeBaseUrl, serializeProvider, assertSafeProviderUrl, buildProviderRequest } from '../providers.js';

test('Chinese and Latin word counts', () => {
  assert.equal(countWords('渡轮靠岸的时候，雾还没散。'), 11);
  assert.equal(countWords('hello world 你好'), 4);
  assert.equal(countWords(''), 0);
});

test('frontmatter parser handles names, descriptions and tags', () => {
  const { meta, body } = parseFrontmatter('---\nname: 开篇\ndescription: 让读者追下去\ntags: [结构, 开篇]\n---\n\n# 开篇\n\n正文');
  assert.equal(meta.name, '开篇');
  assert.equal(meta.description, '让读者追下去');
  assert.deepEqual(meta.tags, ['结构', '开篇']);
  assert.match(body, /# 开篇/);
});

test('zip skill packages fold references into one skill', async () => {
  const zip = new JSZip();
  zip.file('my-skill/SKILL.md', '---\nname: 测试技能\ndescription: 用于测试\n---\n# 测试技能\n\n## 要求\n\n- 写短句。');
  zip.file('my-skill/references/style.md', '# 语气\n\n短句，具体，不解释。');
  const buffer = await zip.generateAsync({ type: 'nodebuffer' });
  const docs = await extractUpload({ buffer, originalname: 'my-skill.zip', mimetype: 'application/zip' });
  assert.equal(docs.length, 1);
  assert.equal(docs[0].kind, 'skill');
  assert.equal(docs[0].name, '测试技能');
  assert.match(docs[0].content, /参考文件/);
  assert.match(docs[0].content, /短句，具体/);
});

test('base URL normalisation keeps OpenAI-compatible endpoints stable', () => {
  assert.equal(normalizeBaseUrl('https://api.deepseek.com/v1/', 'openai'), 'https://api.deepseek.com/v1');
  assert.equal(normalizeBaseUrl('api.deepseek.com/v1/chat/completions', 'openai'), 'https://api.deepseek.com/v1');
  assert.equal(normalizeBaseUrl('https://api.anthropic.com/v1/messages', 'anthropic'), 'https://api.anthropic.com');
});

test('SSRF guard rejects link-local metadata even when local providers are enabled', async () => {
  await assert.rejects(
    () => assertSafeProviderUrl('http://169.254.169.254/latest/meta-data'),
    /链路本地|云元数据/
  );
  await assert.doesNotReject(() => assertSafeProviderUrl('http://127.0.0.1:11434/v1'));
});

test('provider serialisation never exposes a key', () => {
  const row = {
    id: 'p1',
    label: 'DeepSeek',
    kind: 'openai',
    preset_id: 'deepseek',
    base_url: 'https://api.deepseek.com/v1',
    api_key_enc: 'encrypted',
    models: '["deepseek-flash","deepseek-chat"]',
    is_default: 1,
    key_hint: '',
    created_at: 1,
    updated_at: 2,
  };
  const serialized = serializeProvider(row, { keyHint: 'sk-••••1234' });
  assert.equal(serialized.models.length, 2);
  assert.equal(serialized.models[0].label, 'DeepSeek V4.1 Flash');
  assert.equal(serialized.hasKey, true);
  assert.equal(serialized.keyHint, 'sk-••••1234');
  assert.equal(JSON.stringify(serialized).includes('encrypted'), false);
});

test('DeepSeek official requests disable thinking so prose gets the token budget', () => {
  const official = buildProviderRequest({
    provider: { kind: 'openai', base_url: 'https://api.deepseek.com/v1' },
    apiKey: 'sk-test',
    model: 'deepseek-flash',
    system: '写小说',
    messages: [{ role: 'user', content: '继续' }],
    stream: true,
    maxTokens: 4096,
  });
  assert.deepEqual(official.body.thinking, { type: 'disabled' });

  const other = buildProviderRequest({
    provider: { kind: 'openai', base_url: 'https://api.openai.com/v1' },
    apiKey: 'sk-test',
    model: 'gpt-4.1',
    system: '写小说',
    messages: [{ role: 'user', content: '继续' }],
    stream: true,
    maxTokens: 4096,
  });
  assert.equal(other.body.thinking, undefined);
});

test('continuity action instructs an evidence-based audit, not a rewrite', () => {
  const built = buildGenerationContext({
    project: { title: '长篇测试', subtitle: '', genre: '', premise: '', style_guide: '' },
    bible: { world: '雾港。', characters: '沈砚。', outline: '', rules: '只写沈砚视角。', themes: '' },
    chapters: [{ id: 'c1', title: '当前章', sort: 0, summary: '她拿到照片。', content: '她把照片翻过来。' }],
    chapter: { id: 'c1', title: '当前章', sort: 0, summary: '她拿到照片。', content: '她把照片翻过来。' },
    skills: [],
    action: 'continuity',
  });
  assert.match(built.user, /连续性编辑/);
  assert.match(built.user, /位置 \| 问题类型 \| 依据 \| 建议/);
  assert.match(built.user, /不要为了凑数编造/);
});

test('generation context carries bible, skills, prior summaries and selection', () => {
  const project = { title: '雾港无信', subtitle: '', genre: '悬疑', premise: '一封信', style_guide: '冷静，短句。' };
  const bible = {
    world: '雾港，终年多雾。',
    characters: '沈砚，37 岁。',
    outline: '第一章发现信。',
    style: '短句，冷，不解释情绪。',
    rules: '只写沈砚视角。',
    themes: '记忆与证词。',
  };
  const chapters = [
    { id: 'c1', title: '潮痕', sort: 0, summary: '沈砚发现 241 封信。', content: '渡轮靠岸的时候，雾还没散。' },
    { id: 'c2', title: '空屋', sort: 1, summary: '照片出现。', content: '' },
  ];
  const chapter = { ...chapters[1], content: '她站在门口。' };
  const skill = { id: 's1', name: '去 AI 味', kind: 'skill', content: '删掉每段最后的升华。' };
  const built = buildGenerationContext({
    project,
    bible,
    chapters,
    chapter,
    skills: [skill],
    action: 'continue',
    instruction: '再冷一点。',
    selection: '',
  });
  assert.match(built.system, /雾港/);
  assert.match(built.system, /只写沈砚视角/);
  assert.match(built.system, /短句，冷，不解释情绪/);
  assert.match(built.system, /删掉每段最后的升华/);
  assert.match(built.system, /沈砚发现 241 封信/);
  assert.match(built.user, /她站在门口/);
  assert.match(built.user, /再冷一点/);
  assert.equal(built.stats.skills[0].name, '去 AI 味');
  assert.equal(built.messages.at(-1).role, 'user');
});

test('open foreshadowing is injected into context, resolved threads are not', () => {
  const built = buildGenerationContext({
    project: { title: '独魂', subtitle: '', genre: '玄幻', premise: '', style_guide: '' },
    bible: {
      world: '烬州。',
      characters: '闻人烬。',
      outline: '三章。',
      foreshadowing: '- [ ] 黑骨钉是谁磨的\n- [x] 老周遗言已兑现',
      rules: '只写闻人烬。',
      themes: '出身与代价。',
    },
    chapters: [{ id: 'c1', title: '凡骨', sort: 0, summary: '', content: '雪落在肩上。' }],
    chapter: { id: 'c1', title: '凡骨', sort: 0, summary: '', content: '雪落在肩上。' },
    skills: [],
    action: 'continue',
  });
  assert.match(built.system, /未回收伏笔/);
  assert.match(built.system, /黑骨钉是谁磨的/);
  assert.doesNotMatch(built.system, /老周遗言已兑现/);
});

test('Codex entries are injected with aliases and relationships', () => {
  const built = buildGenerationContext({
    project: { title: '独魂', subtitle: '', genre: '玄幻', premise: '', style_guide: '' },
    bible: { world: '烬州。', characters: '', outline: '', foreshadowing: '', rules: '', themes: '' },
    chapters: [{ id: 'c1', title: '凡骨', sort: 0, summary: '', content: '阿烬站在雪里。' }],
    chapter: { id: 'c1', title: '凡骨', sort: 0, summary: '', content: '阿烬站在雪里。' },
    skills: [],
    codex: [{
      id: 'x1',
      kind: 'character',
      name: '闻人烬',
      aliases: ['阿烬'],
      role: '主角',
      summary: '被判凡骨的少年。',
      desire: '活下去',
      fear: '被家族彻底抹掉',
      secret: '能听见死者遗言',
      voice: '短句',
      state: '左肩有旧伤',
      relationships: [{ name: '闻人铎', label: '族兄', note: '互相利用' }],
      pinned: true,
    }],
    action: 'continue',
  });
  assert.match(built.system, /Codex·人物：闻人烬/);
  assert.match(built.system, /别名：阿烬/);
  assert.match(built.system, /能听见死者遗言/);
  assert.equal(built.stats.codex[0].name, '闻人烬');
});

test('diagnose action audits craft without rewriting the chapter', () => {
  const built = buildGenerationContext({
    project: { title: '独魂', subtitle: '', genre: '玄幻', premise: '', style_guide: '' },
    bible: { world: '', characters: '', outline: '', foreshadowing: '', rules: '', themes: '' },
    chapters: [{ id: 'c1', title: '凡骨', sort: 0, summary: '', content: '雪落在肩上。' }],
    chapter: { id: 'c1', title: '凡骨', sort: 0, summary: '', content: '雪落在肩上。' },
    skills: [],
    action: 'diagnose',
  });
  assert.match(built.user, /只做体检，不改写正文/);
  assert.match(built.user, /章末钩子/);
  assert.match(built.user, /AI 腔/);
});

test('30-chapter context stays coherent under the character budget', () => {
  const chapters = Array.from({ length: 30 }, (_, index) => ({
    id: `c${index}`,
    title: `第${index + 1}章`,
    sort: index,
    summary: `第${index + 1}章，主角推进了一步，也失去了一点东西。`.repeat(3),
    content: `第${index + 1}章的正文。`.repeat(350),
  }));
  const built = buildGenerationContext({
    project: { title: '三十章压力测试', subtitle: '', genre: '玄幻', premise: '往上爬。', style_guide: '' },
    bible: { world: '烬州。', characters: '闻人烬。', outline: '', foreshadowing: '- [ ] 黑骨钉的来历', rules: '限知。', themes: '代价。' },
    chapters,
    chapter: chapters[29],
    skills: [],
    codex: [{ id: 'x', kind: 'character', name: '闻人烬', aliases: [], summary: '主角。', pinned: true }],
    genrePack: { name: '玄幻 · 凡人流', tagline: '靠准备翻盘。', laws: ['代价先于力量。'], bridges: ['被当众判死资质。'] },
    action: 'continue',
    maxChars: 60000,
  });
  assert.equal(built.stats.chaptersBefore, 29);
  assert.ok(built.stats.contextChars < 65000);
  assert.match(built.system, /类型包/);
  assert.match(built.system, /主角推进了一步/);
});

test('summary context is short and instructs a factual digest', () => {
  const built = buildSummaryContext({
    project: { title: '雾港无信' },
    chapter: { title: '潮痕', content: '渡轮靠岸的时候，雾还没散。' },
  });
  assert.match(built.system, /150–260 字/);
  assert.match(built.user, /渡轮靠岸/);
});

test('long chapters keep the ending for continuation and the previous chapter tail', () => {
  const previous = `PREV-BEGIN${'甲'.repeat(3000)}PREV-END`;
  const current = `CURRENT-BEGIN${'乙'.repeat(9000)}CURRENT-END`;
  const built = buildGenerationContext({
    project: { title: '长篇测试', subtitle: '', genre: '', premise: '', style_guide: '' },
    bible: { world: '', characters: '', outline: '', rules: '', themes: '' },
    chapters: [
      { id: 'c1', title: '上一章', sort: 0, summary: '上一章摘要', content: previous },
      { id: 'c2', title: '当前章', sort: 1, summary: '', content: current },
    ],
    chapter: { id: 'c2', title: '当前章', sort: 1, summary: '', content: current },
    skills: [],
    action: 'continue',
  });
  assert.match(built.user, /CURRENT-END/);
  assert.doesNotMatch(built.user, /CURRENT-BEGIN/);
  assert.match(built.system, /PREV-END/);
  assert.doesNotMatch(built.system, /PREV-BEGIN/);

  const continueWithSelection = buildGenerationContext({
    project: { title: '长篇测试', subtitle: '', genre: '', premise: '', style_guide: '' },
    bible: { world: '', characters: '', outline: '', rules: '', themes: '' },
    chapters: [{ id: 'c1', title: '当前章', sort: 0, summary: '', content: 'CURRENT-BEGIN 正文结尾。' }],
    chapter: { id: 'c1', title: '当前章', sort: 0, summary: '', content: 'CURRENT-BEGIN 正文结尾。' },
    skills: [],
    action: 'continue',
    selection: 'SHOULD-NOT-BE-USED',
  });
  assert.match(continueWithSelection.user, /正文结尾/);
  assert.doesNotMatch(continueWithSelection.user, /SHOULD-NOT-BE-USED/);

  const summary = buildSummaryContext({
    project: { title: '长篇测试' },
    chapter: { title: '当前章', content: `HEAD${'丙'.repeat(2000)}TAIL` },
    maxChars: 500,
  });
  assert.match(summary.user, /HEAD/);
  assert.match(summary.user, /TAIL/);
  assert.match(summary.user, /中间已截断/);
});
