import express from 'express';
import compression from 'compression';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { timingSafeEqual } from 'node:crypto';
import { config } from './config.js';
import { aiRouter } from './local-ai.js';
import { toolsRouter } from './local-tools.js';
import { HttpError } from './util.js';

export const app = express();
app.disable('x-powered-by');
app.set('trust proxy', config.trustProxy ? 1 : false);

const allowedOrigins = config.appOrigin
  ? config.appOrigin.split(',').map((s) => s.trim().replace(/\/$/, '')).filter(Boolean)
  : [];

function originAllowed(req, origin) {
  if (!origin) return true;
  if (allowedOrigins.includes(origin)) return true;
  const forwardedProto = req.get('x-forwarded-proto')?.split(',')[0]?.trim();
  const protocol = forwardedProto || req.protocol;
  if (origin === `${protocol}://${req.get('host')}`) return true;
  if (!config.isProduction) {
    try {
      const host = new URL(origin).hostname;
      return host === 'localhost' || host === '127.0.0.1' || host === '::1';
    } catch {
      return false;
    }
  }
  return false;
}

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  const isHttps = req.secure || req.get('x-forwarded-proto') === 'https';
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "img-src 'self' data: blob:",
      "font-src 'self' data:",
      "style-src 'self' 'unsafe-inline'",
      "script-src 'self'",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      isHttps ? 'upgrade-insecure-requests' : '',
    ]
      .filter(Boolean)
      .join('; '),
  );
  if (config.isProduction && isHttps) {
    res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  }
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    if (req.headers['x-requested-with'] !== 'underlamp') {
      return res.status(403).json({ error: '请求缺少安全标记，请刷新页面后重试' });
    }
    if (!originAllowed(req, req.headers.origin)) {
      return res.status(403).json({ error: '请求来源不受信任' });
    }
  }
  next();
});

if (config.appPassword) {
  app.use((req, res, next) => {
    if (req.path === '/api/health') return next();
    const header = String(req.headers.authorization || '');
    if (header.startsWith('Basic ')) {
      try {
        const [user, password = ''] = Buffer.from(header.slice(6), 'base64').toString('utf8').split(':');
        const userOk = user === config.appUser;
        const given = Buffer.from(password);
        const expected = Buffer.from(config.appPassword);
        const passOk = given.length === expected.length && timingSafeEqual(given, expected);
        if (userOk && passOk) return next();
      } catch {
        /* fall through */
      }
    }
    res.setHeader('WWW-Authenticate', 'Basic realm="Underlamp", charset="UTF-8"');
    return res.status(401).type('text/plain; charset=utf-8').send('需要访问密码');
  });
}

app.use(
  compression({
    filter: (req, res) =>
      String(res.getHeader('content-type') || '').includes('text/event-stream')
        ? false
        : compression.filter(req, res),
  }),
);
app.use(express.json({ limit: '8mb' }));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'underlamp',
    version: '2.25.0',
    mode: 'local-first',
    time: new Date().toISOString(),
  });
});

app.use('/api/ai', aiRouter);
app.use('/api/tools', toolsRouter);
app.use('/api', (_req, res) => {
  res.status(404).json({ error: '接口不存在' });
});

if (fs.existsSync(config.clientDist)) {
  app.use(
    express.static(config.clientDist, {
      index: false,
      maxAge: '1h',
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('/sw.js')) {
          res.setHeader('cache-control', 'no-cache, no-store, must-revalidate');
        } else if (filePath.endsWith('/index.html')) {
          res.setHeader('cache-control', 'no-cache');
        } else if (/\/assets\/.+-[A-Za-z0-9_-]+\.[a-z0-9]+$/.test(filePath)) {
          res.setHeader('cache-control', 'public, max-age=31536000, immutable');
        } else {
          res.setHeader('cache-control', 'public, max-age=3600');
        }
      },
    }),
  );
  app.use((req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (req.path.startsWith('/api/')) return next();
    res.setHeader('cache-control', 'no-cache');
    res.sendFile(path.join(config.clientDist, 'index.html'));
  });
} else {
  app.get('/', (_req, res) => {
    res.type('text/plain').send('Underlamp API is running. Run `pnpm build` or `pnpm dev` for the UI.');
  });
}

app.use((error, req, res, _next) => {
  if (res.headersSent) {
    try {
      res.end();
    } catch {
      /* ignore */
    }
    return;
  }
  if (error instanceof multer.MulterError) {
    const message = error.code === 'LIMIT_FILE_SIZE' ? '单个文件超过上传上限' : '文件上传失败';
    return res.status(400).json({ error: message });
  }
  if (error?.type === 'entity.too.large') {
    return res.status(413).json({ error: '请求内容过大' });
  }
  if (error instanceof SyntaxError && error.status === 400 && 'body' in error) {
    return res.status(400).json({ error: '请求格式不正确' });
  }
  if (error instanceof HttpError) {
    return res.status(error.status).json({ error: error.message });
  }
  console.error('[underlamp]', error);
  res.status(500).json({ error: '服务器出了一点问题，请稍后重试' });
});

const server = app.listen(config.port, config.host, () => {
  console.log(`\n  灯下 Underlamp · http://127.0.0.1:${config.port}`);
  console.log('  mode: local-first · data: browser IndexedDB · server: stateless proxy');
  console.log(`  client: ${config.clientDist}`);
  console.log('');
});

function shutdown(signal) {
  console.log(`\n[underlamp] ${signal}, closing...`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
